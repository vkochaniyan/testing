package com.bac.component;

import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.Cache;
import org.ehcache.spi.loaderwriter.CacheWritingException;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

import com.bac.cache.framework.WsdlCacheManager;



/**
 * @author ZKZBQ23 Lookup from ehCache
 *
 */
public class WsdlLookupFromCache implements Callable {

	private static final Logger logger = LogManager.getLogger();
	
	private WsdlCacheManager wsdlCacheManager;

	public void setWsdlCacheManager(WsdlCacheManager wsdlCacheManager) {
		this.wsdlCacheManager = wsdlCacheManager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.mule.api.lifecycle.Callable#onCall(org.mule.api.MuleEventContext)
	 */
	@Override
	public String onCall(MuleEventContext eventContext) throws Exception {

		logger.debug("onCall start");
		String wsdl = null;
				
		MuleMessage message = eventContext.getMessage();

		// Get a ReadLock on cache
		Cache<String, Object> ehCache = wsdlCacheManager.getWsdlCache();
		
		ReadWriteLock lock = new ReentrantReadWriteLock();
		
		try {
			lock.readLock().lock();
			
			String httpRequestPath = message.getInboundProperty("http.request.path");
			String serviceName = httpRequestPath.substring(httpRequestPath.lastIndexOf("/") + 1);
			message.setOutboundProperty("serviceName", serviceName);
			
			logger.debug("Service Name: "+serviceName);
			if(serviceName != null){
			wsdl = (String) ehCache.get(serviceName);
			}
			
			if(wsdl != null){
				logger.debug("WSDL got from Cache: " + wsdl);
			}else{
				logger.error("WSDL IS NOT AVAILABLE ON HTTP SERVER OR NOT AVAILABLE IN CACHE SO NO WSDL AS A RESPONSE TO THE CLIENT");
			}
		} catch (CacheWritingException exception) {
			logger.error("ERROR IN GETTING VALUES FROM EHCACHE:  " + exception);
			exception.printStackTrace();
			} 
		finally {
			lock.readLock().unlock();
		}
		return wsdl;
	
	}

}
