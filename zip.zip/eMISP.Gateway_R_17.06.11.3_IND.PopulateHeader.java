package com.mulesoft.mule.boa;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

public class PopulateHeader implements Callable {
	private static final Logger logger = LogManager.getLogger();
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		
		/**
		 * The following block handles the following high level scenarios as it relates to MTOM and regular Gateway Processing
		 * 1. MTOM requests with SessionSpecHeaderName returned & a cached value for session spec
		 * 2. MTOM requests with SessionSpecHeaderName returned & no cached value for session spec
		 * 3. Regular Gateway requests with no SessionSpecHeaderName returned
		 */
		MuleMessage message = eventContext.getMessage();
		String headerName = message.getInvocationProperty("SessionSpecHeaderName");
		message.setOutboundProperty(headerName, message.getPayload());
		logger.info("sessionspec header=" + headerName + ", value=" + message.getPayload());
		return eventContext.getMessage().getPayload();
	}
}
