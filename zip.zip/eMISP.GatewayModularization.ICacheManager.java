/**
 * 
 */
package com.bac.cache.framework;

/**
 * @author ZKWQBHO
 *
 */
public interface ICacheManager {

	public void loadCache() throws Exception;
	
	public void refreshCache() throws Exception;
}
