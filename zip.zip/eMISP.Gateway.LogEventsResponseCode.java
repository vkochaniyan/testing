package com.mulesoft.mule.boa.vo;

public class LogEventsResponseCode implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
