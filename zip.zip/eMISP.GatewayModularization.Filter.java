package com.bac.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "@dataType", "@contextVar", "@filterAction", "property" })
public class Filter {

	@JsonProperty("@dataType")
	private String dataType;
	@JsonProperty("@contextVar")
	private String contextVar;
	@JsonProperty("@filterAction")
	private String filterAction;
	@JsonProperty("property")
	private Property property;

	/**
	 * 
	 * @return The dataType
	 */
	@JsonProperty("@dataType")
	public String getDataType() {
		return dataType;
	}

	/**
	 * 
	 * @param dataType
	 *            The @dataType
	 */
	@JsonProperty("@dataType")
	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

	/**
	 * 
	 * @return The contextVar
	 */
	@JsonProperty("@contextVar")
	public String getContextVar() {
		return contextVar;
	}

	/**
	 * 
	 * @param contextVar
	 *            The @contextVar
	 */
	@JsonProperty("@contextVar")
	public void setContextVar(String contextVar) {
		this.contextVar = contextVar;
	}

	/**
	 * 
	 * @return The filterAction
	 */
	@JsonProperty("@filterAction")
	public String getFilterAction() {
		return filterAction;
	}

	/**
	 * 
	 * @param filterAction
	 *            The @filterAction
	 */
	@JsonProperty("@filterAction")
	public void setFilterAction(String filterAction) {
		this.filterAction = filterAction;
	}

	/**
	 * 
	 * @return The property
	 */
	@JsonProperty("property")
	public Property getProperty() {
		return property;
	}

	/**
	 * 
	 * @param property
	 *            The property
	 */
	@JsonProperty("property")
	public void setProperty(Property property) {
		this.property = property;
	}

}