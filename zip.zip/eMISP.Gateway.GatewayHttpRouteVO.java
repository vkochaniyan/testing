package com.mulesoft.mule.boa.vo;

public class GatewayHttpRouteVO extends GatewayRouteVO {
	
	
	private static final long serialVersionUID = -5043563554468151672L;
	
	private String domain;
	private String port;
	private String uri;
	private String targetNamespaceURI;
	private String httpUsage;
	private String contentType;
	
	
	private CredentialsVO credentialsVO = new CredentialsVO();
	
	public GatewayHttpRouteVO(){
		
	}
	
	
	public GatewayHttpRouteVO(String name,String protocol,String domain,String port,String uri){
		super(name, protocol);
		this.domain = domain;
		this.port = port;
		this.uri = uri;
	}
	
	public String getContentType() {
		return contentType;
	}


	public void setContentType(String contentType) {
		this.contentType = contentType;
	}


	public CredentialsVO getCredentialsVO() {
		return credentialsVO;
	}


	public void setCredentialsVO(CredentialsVO credentialsVO) {
		this.credentialsVO = credentialsVO;
	}

	public String getHttpUsage() {
		return httpUsage;
	}


	public void setHttpUsage(String httpUsage) {
		this.httpUsage = httpUsage;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getPort() {
		return port;
	}

	public void setPort(String port) {
		this.port = port;
	}

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

	public String getTargetNamespaceURI() {
		return targetNamespaceURI;
	}

	public void setTargetNamespaceURI(String targetNamespaceURI) {
		this.targetNamespaceURI = targetNamespaceURI;
	}

	
		
}
