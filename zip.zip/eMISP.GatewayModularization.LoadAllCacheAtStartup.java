/**
 * 
 */
package com.bac.cache.framework;

import java.net.URL;
import java.util.List;

import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

/**
 * @author ZKWQBHO
 *
 */
public class LoadAllCacheAtStartup implements Callable {
	
	final URL cacheUrl = this.getClass().getClassLoader().getResource("ehcache.xml");
	
	CacheManagerFactory cacheManagerFactory;
	
	
	
	public CacheManagerFactory getCacheManagerFactory() {
		return cacheManagerFactory;
	}



	public void setCacheManagerFactory(CacheManagerFactory cacheManagerFactory) {
		this.cacheManagerFactory = cacheManagerFactory;
	}



	public Object onCall(MuleEventContext eventContext) throws Exception {
        //creating memory
		List<ICacheManager> allCacheManagers = cacheManagerFactory.findAll(cacheUrl);
		//Fill the cache space created with Files
		LoadAllCache loadAllCache = new LoadAllCache(allCacheManagers);
		//For timestamp - performance time taken
		  //Object created
		CacheInvoker cacheInvoker = new CacheInvoker(loadAllCache);
		cacheInvoker.load();
		return eventContext;
	}
}
