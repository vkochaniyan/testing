package com.bac.vo;

import java.util.ArrayList;
import java.util.List;
import javax.annotation.Generated;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@Generated("org.jsonschema2pojo")
@JsonPropertyOrder({
"serviceName",
"token",
"logEvents",
"filter",
"HttpToMqHeaders"
})
public class PolicyActionService {

@JsonProperty("serviceName")
private List<String> serviceName = new ArrayList<String>();
@JsonProperty("token")
private Token token;
@JsonProperty("logEvents")
private LogEvents logEvents;
@JsonProperty("filter")
private Filter filter;
@JsonProperty("HttpToMqHeaders")
private HttpToMqHeaders httpToMqHeaders;

/**
* 
* @return
* The name
*/
@JsonProperty("serviceName")
public List<String> getServiceName() {
return serviceName;
}

/**
* 
* @param name
* The name
*/
@JsonProperty("serviceName")
public void setName(List<String> serviceName) {
this.serviceName = serviceName;
}

/**
* 
* @return
* The token
*/
@JsonProperty("token")
public Token getToken() {
return token;
}

/**
* 
* @param token
* The token
*/
@JsonProperty("token")
public void setToken(Token token) {
this.token = token;
}

/**
* 
* @return
* The logEvents
*/
@JsonProperty("logEvents")
public LogEvents getLogEvents() {
return logEvents;
}

/**
* 
* @param logEvents
* The logEvents
*/
@JsonProperty("logEvents")
public void setLogEvents(LogEvents logEvents) {
this.logEvents = logEvents;
}

/**
* 
* @return
* The filter
*/
@JsonProperty("filter")
public Filter getFilter() {
return filter;
}

/**
* 
* @param filter
* The filter
*/
@JsonProperty("filter")
public void setFilter(Filter filter) {
this.filter = filter;
}

/**
* 
* @return
* The httpToMqHeaders
*/
@JsonProperty("HttpToMqHeaders")
public HttpToMqHeaders getHttpToMqHeaders() {
return httpToMqHeaders;
}

/**
* 
* @param httpToMqHeaders
* The HttpToMqHeaders
*/
@JsonProperty("HttpToMqHeaders")
public void setHttpToMqHeaders(HttpToMqHeaders httpToMqHeaders) {
this.httpToMqHeaders = httpToMqHeaders;
}

}