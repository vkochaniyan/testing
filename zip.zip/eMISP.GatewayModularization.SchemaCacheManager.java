/**
 * 
 */
package com.bac.cache.framework;

import javax.xml.validation.Schema;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.Cache;
import org.ehcache.CacheManager;

/**
 * @author ZKWQBHO
 *
 */
public class SchemaCacheManager implements ICacheManager {

	private static final Logger logger = LogManager.getLogger();
	Cache<String, Schema> ehCache;
	CacheManager ehCacheMgr;
	SchemaObjectBuilder schemaObjectBuilder;

	String schemaPath;
	String schemaConfigPath;
	CacheSSLConnector cacheSSLConnector;
	
	public SchemaCacheManager() {
	}
	
	public CacheSSLConnector getCacheSSLConnector() {
		return cacheSSLConnector;
	}

	public void setCacheSSLConnector(CacheSSLConnector cacheSSLConnector) {
		this.cacheSSLConnector = cacheSSLConnector;
	}

	@SuppressWarnings("unused")
	private String getSchemaConfigPath() {
		return schemaConfigPath;
	}

	public void setSchemaConfigPath(String schemaConfigPath) {
		this.schemaConfigPath = schemaConfigPath;
	}

	public void setSchemaPath(String schemaPath) {
		this.schemaPath = schemaPath;
	}

	@SuppressWarnings("unused")
	private String getSchemaPath() {
		return schemaPath;
	}

	public CacheManager getEhCacheMgr() {
		return ehCacheMgr;
	}

	public void setEhCacheMgr(CacheManager ehCacheMgr) {
		this.ehCacheMgr = ehCacheMgr;
	}

	public SchemaObjectBuilder getSchemaObjectBuilder() {
		return schemaObjectBuilder;
	}

	public void setSchemaObjectBuilder(SchemaObjectBuilder schemaObjectBuilder) {
		this.schemaObjectBuilder = schemaObjectBuilder;
	}

	public Cache<String, Schema> getSchemaCache() {
		return ehCache;
	}

	public void setCache(Cache<String, Schema> schemaCache) {
		this.ehCache = schemaCache;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bac.cache.framework.CacheManager#loadCache()
	 */
	@Override
	public void loadCache() throws Exception {
		logger.debug(" In LoadCache() ");
		ehCache = ehCacheMgr.getCache("schemaCache", String.class, Schema.class);
	
		SchemaObjectBuilder schemaObjectBuilder = new SchemaObjectBuilder(schemaPath, schemaConfigPath, cacheSSLConnector);
		schemaObjectBuilder.build(ehCache);
		setCache(ehCache);
		logger.debug(" SCHEMA CACHE STATUS --> " + ehCacheMgr.getStatus().toString());
		logger.debug("NEW CACHE CREATED");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bac.cache.framework.CacheManager#refreshCache()
	 */
	@Override
	public void refreshCache() throws Exception {
		logger.debug(" In RefreshCache() ");
		ehCache = ehCacheMgr.getCache("schemaCache", String.class, Schema.class);

		SchemaObjectBuilder schemaObjectBuilder = new SchemaObjectBuilder(schemaPath, schemaConfigPath, cacheSSLConnector);
		schemaObjectBuilder.build(ehCache);

		logger.debug("RefreshCache() -> SCHEMA CACHE STATUS -> " + ehCacheMgr.getStatus().toString());
		logger.debug("CACHE REFRESHED !!");

	}

}
