/**
 * 
 */
package com.bac.cache.framework;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.Cache;
import org.ehcache.CacheManager;

/**
 * @author ZKZBQ23
 *
 */
public class ConfigCacheManager implements ICacheManager {

	private static final Logger logger = LogManager.getLogger();
	Cache<String, Object> ehCache;
	CacheManager ehCacheMgr;
	AuthorizationJsonObjectBuilder authorizationJsonObjectBuilder;
	ProviderRoutesJsonObjectBuilder providerRoutesJsonObjectBuilder;
	PolicyActionJsonObjectBuilder policyActionJsonObjectBuilder;
	CacheSSLConnector cacheSSLConnector;
	String jsonConfigPath;
	
	public ConfigCacheManager() {
	}

	public CacheSSLConnector getCacheSSLConnector() {
		return cacheSSLConnector;
	}

	public void setCacheSSLConnector(CacheSSLConnector cacheSSLConnector) {
		this.cacheSSLConnector = cacheSSLConnector;
	}
	
	@SuppressWarnings("unused")
	private String getJsonConfigPath() {
		return jsonConfigPath;
	}

	public void setJsonConfigPath(String jsonConfigPath) {
		this.jsonConfigPath = jsonConfigPath;
	}
	
	public CacheManager getEhCacheMgr() {
		return ehCacheMgr;
	}

	public void setEhCacheMgr(CacheManager ehCacheMgr) {
		this.ehCacheMgr = ehCacheMgr;
	}
	
	public AuthorizationJsonObjectBuilder getAuthorizeJsonObjectBuilder() {
		return authorizationJsonObjectBuilder;
	}

	public void setAuthorizeJsonObjectBuilder(AuthorizationJsonObjectBuilder authorizationJsonObjectBuilder) {
		this.authorizationJsonObjectBuilder = authorizationJsonObjectBuilder;
	}

	public ProviderRoutesJsonObjectBuilder getProviderRoutesJsonObjectBuilder() {
		return providerRoutesJsonObjectBuilder;
	}

	public void setProviderRoutesJsonObjectBuilder(ProviderRoutesJsonObjectBuilder providerRoutesJsonObjectBuilder) {
		this.providerRoutesJsonObjectBuilder = providerRoutesJsonObjectBuilder;
	}

	public PolicyActionJsonObjectBuilder getTokenCheckJsonObjectBuilder() {
		return policyActionJsonObjectBuilder;
	}

	public void setTokenCheckJsonObjectBuilder(PolicyActionJsonObjectBuilder policyActionJsonObjectBuilder) {
		this.policyActionJsonObjectBuilder = policyActionJsonObjectBuilder;
	}

	public Cache<String, Object> getConfigCache() {
		return ehCache;
	}

	public void setCache(Cache<String, Object> configCache) {
		this.ehCache = configCache;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bac.cache.framework.CacheManager#loadCache()
	 */
	@Override
	public void loadCache() throws Exception {
		logger.debug(" In LoadCache() start ");
		try {
			ehCache = ehCacheMgr.getCache("configCache", String.class, Object.class);
			
			if(ehCache != null){

                AuthorizationJsonObjectBuilder authorizationJsonObjectBuilder = new AuthorizationJsonObjectBuilder(jsonConfigPath, cacheSSLConnector);
                authorizationJsonObjectBuilder.build(ehCache);

                ProviderRoutesJsonObjectBuilder providerRoutesJsonObjectBuilder = new ProviderRoutesJsonObjectBuilder(jsonConfigPath, cacheSSLConnector);
                providerRoutesJsonObjectBuilder.build(ehCache);

                PolicyActionJsonObjectBuilder policyActionJsonObjectBuilder = new PolicyActionJsonObjectBuilder(jsonConfigPath, cacheSSLConnector);
                policyActionJsonObjectBuilder.build(ehCache);

                setCache(ehCache);
			}
			logger.debug(" JSON CACHE STATUS --> " + ehCacheMgr.getStatus().toString());
			logger.debug("NEW CACHE CREATED");
			
		} catch (Exception exc) {
			logger.error(
					"ERROR IN EHCACHE OR JSON FILES PATH FROM HTTP Server : ERROR -> " + exc.toString());
			exc.printStackTrace();
		}
		logger.debug(" In LoadCache() end ");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bac.cache.framework.CacheManager#refreshCache()
	 */
	@Override
	public void refreshCache() throws Exception {
		logger.debug(" In refreshCache() start");
		
			ehCache = ehCacheMgr.getCache("configCache", String.class, Object.class);

			if(ehCache != null){

                AuthorizationJsonObjectBuilder authorizationJsonObjectBuilder = new AuthorizationJsonObjectBuilder(jsonConfigPath, cacheSSLConnector);
                authorizationJsonObjectBuilder.build(ehCache);

                ProviderRoutesJsonObjectBuilder providerRoutesJsonObjectBuilder = new ProviderRoutesJsonObjectBuilder(jsonConfigPath, cacheSSLConnector);
                providerRoutesJsonObjectBuilder.build(ehCache);

                PolicyActionJsonObjectBuilder policyActionJsonObjectBuilder = new PolicyActionJsonObjectBuilder(jsonConfigPath, cacheSSLConnector);
                policyActionJsonObjectBuilder.build(ehCache);
                
			}
			logger.debug("RefreshCache() -> JSON CACHE STATUS -> " + ehCacheMgr.getStatus().toString());
			logger.debug("CACHE REFRESHED !!");
		
		logger.debug(" In refreshCache() end");
	}

}
