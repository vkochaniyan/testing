package com.bac.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "providerRoute" })
public class ProviderRouteCollection {

	@JsonProperty("providerRoute")
	private ProviderRoute providerRoute;

	/**
	 * 
	 * @return The providerRoute
	 */
	@JsonProperty("providerRoute")
	public ProviderRoute getProviderRoute() {
		return providerRoute;
	}

	/**
	 * 
	 * @param providerRoute
	 *            The providerRoute
	 */
	@JsonProperty("providerRoute")
	public void setProviderRoute(ProviderRoute providerRoute) {
		this.providerRoute = providerRoute;
	}

}