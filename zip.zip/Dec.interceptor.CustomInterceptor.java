package interceptor;

import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.context.MuleContextAware;
import org.mule.interceptor.AbstractEnvelopeInterceptor;
import org.mule.management.stats.ProcessingTime;

public class CustomInterceptor extends AbstractEnvelopeInterceptor {
	private String name;
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public MuleEvent before(MuleEvent event) throws MuleException {
		// TODO Auto-generated method stub
//		System.out.println("Before "+System.currentTimeMillis()+" "+this.name);
		return event;
	}

	@Override
	public MuleEvent after(MuleEvent event) throws MuleException {
		// TODO Auto-generated method stub
//		System.out.println("After "+System.currentTimeMillis()+" "+this.name);
		return event;
	}

	@Override
	public MuleEvent last(MuleEvent event, ProcessingTime time, long startTime, boolean exceptionWasThrown)
			throws MuleException {
		// TODO Auto-generated method stub
		System.out.println("Last "+startTime+" "+(System.currentTimeMillis()-startTime)+" "+this.name);
		return event;
	}

}
