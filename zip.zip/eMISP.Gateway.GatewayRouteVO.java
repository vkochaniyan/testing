package com.mulesoft.mule.boa.vo;

public class GatewayRouteVO implements java.io.Serializable{
	
	private static final long serialVersionUID = 5932881846458843390L;
	
	private String ait;
	private String name;
	private String protocol;
	
	public GatewayRouteVO(){
		
	}
	
	public GatewayRouteVO(String name,String protocol){
		this.name = name;
		this.protocol = protocol;
	}
	
	public String getAit() {
		return ait;
	}

	public void setAit(String ait) {
		this.ait = ait;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

}
