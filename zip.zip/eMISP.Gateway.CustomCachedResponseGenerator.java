package com.mulesoft.mule.boa;

import org.mule.api.MuleEvent;
import org.mule.api.MuleMessage;
import org.mule.api.transport.PropertyScope;

import java.util.Set;

import com.mulesoft.mule.cache.responsegenerator.ResponseGenerator;

public class CustomCachedResponseGenerator implements ResponseGenerator {

	@Override
	public MuleEvent create(MuleEvent request, MuleEvent cachedResponse) {
		// TODO Auto-generated method stub
		System.out.println("In Cached Response");
		MuleMessage cMessage = cachedResponse.getMessage();
		MuleMessage rMessage = request.getMessage();
		rMessage.setInvocationProperty("SessionSpecHeaderName", cMessage.getInvocationProperty("SessionSpecHeaderName"));
		rMessage.setInvocationProperty("sessionspec", cMessage.getInvocationProperty("sessionspec"));
		
		return request;
	}

}
