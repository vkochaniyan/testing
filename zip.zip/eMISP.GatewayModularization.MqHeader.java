package com.bac.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "headerName", "value" })
public class MqHeader {

	@JsonProperty("headerName")
	private String headerName;
	@JsonProperty("value")
	private String value;

	/**
	 * 
	 * @return The headerName
	 */
	@JsonProperty("headerName")
	public String getHeaderName() {
		return headerName;
	}

	/**
	 * 
	 * @param headerName
	 *            The headerName
	 */
	@JsonProperty("headerName")
	public void setHeaderName(String headerName) {
		this.headerName = headerName;
	}

	/**
	 * 
	 * @return The value
	 */
	@JsonProperty("value")
	public String getValue() {
		return value;
	}

	/**
	 * 
	 * @param value
	 *            The value
	 */
	@JsonProperty("value")
	public void setValue(String value) {
		this.value = value;
	}

}