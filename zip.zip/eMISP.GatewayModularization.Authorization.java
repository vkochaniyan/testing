package com.bac.vo;

import java.util.ArrayList;
import java.util.List;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang.builder.ToStringBuilder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "service" })
public class Authorization {

	@JsonProperty("service")
	private List<Service> service = new ArrayList<Service>();

	/**
	 * 
	 * @return The service
	 */
	@JsonProperty("service")
	public List<Service> getService() {
		return service;
	}

	/**
	 * 
	 * @param service
	 *            The service
	 */
	@JsonProperty("service")
	public void setService(List<Service> service) {
		this.service = service;
	}

	@Override
	public String toString() {
		System.out.println("In Authorization");
		return ToStringBuilder.reflectionToString(this);
	}

}