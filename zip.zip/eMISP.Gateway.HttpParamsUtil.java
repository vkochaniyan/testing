package com.mulesoft.mule.boa.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.Map;
import java.util.Iterator;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.module.http.internal.ParameterMap;
import org.mule.api.lifecycle.Callable;

public class HttpParamsUtil implements Callable {
	@Override
	public String onCall(MuleEventContext eventContext) throws Exception {
		MuleMessage message = eventContext.getMessage();		
		StringBuffer sb = new StringBuffer();
		System.out.println("http query params :::::::::::::::::: "+message.getInboundProperty("http.query.params"));
		ParameterMap params = message.getInboundProperty("http.query.params");
		if (params.size() >0) {
			sb.append("?");
		}
		int cnt =0;
		Iterator<Map.Entry<String,String>> iter = params.entrySet().iterator();
		while (iter.hasNext()) {
			System.out.println("http query params :::::::::::::::::: ");
			Map.Entry<String, String> pair = (Map.Entry<String, String>)iter.next();
			System.out.println(pair.getKey() + " = " + pair.getValue());
			if (cnt >= 1) {
				sb.append("&"+pair.getKey()+"="+pair.getValue());				
			} else {
				sb.append(pair.getKey()+"="+pair.getValue());
			}
			cnt++;
		}	
		System.out.println("http query params :::::::: "+sb.toString());
		return sb.toString();
	}

}
