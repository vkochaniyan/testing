package com.mulesoft.mule.boa;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.mule.api.MuleMessage;
import org.mule.api.routing.filter.Filter;

public class FilterWeaveResultNew implements Filter {

	@Override
	public boolean accept(MuleMessage message) {		
		
		String currentRoute = (String)message.getInvocationProperty("CurrentRoute");
		if(currentRoute!=null && currentRoute.equals("FindCNFromSubjectDN")){
			System.out.println("Route is FindCNFromSubjectDN "+((HashMap<?, ?>)message.getInvocationProperty("cMap")).get("DN"));
		}
		else if(currentRoute!=null && currentRoute.equals("MapOperationNameFromAuthorize")){
			System.out.println("Route is MapOperationNameFromAuthorize AIT "+((HashMap<?, ?>)message.getInvocationProperty("cMap")).get("AIT"));
			System.out.println("Route is MapOperationNameFromAuthorize operationName "+((HashMap<?, ?>)message.getInvocationProperty("cMap")).get("operationName"));
		}
			
		
		Object o = message.getPayload();		
		if(o instanceof LinkedHashMap){
			@SuppressWarnings("unchecked")
			LinkedHashMap<String,Object> map = (LinkedHashMap<String, Object>)o;
			if(map.containsKey("result")){
				Object value = map.get("result");
				if(value.toString().equals("Not found")){
					HashMap<String, String> cmap = message.getInvocationProperty("cMap");
					
					// Notes: TODO below is new code for merge gw/cbr routes, above will be cleaned up  
					if (currentRoute.equals("MapOperationNameFromAuthorize")) {
						cmap.put("IsNewRoute", "false");
					}
					// TODO add back throw new NullPointerException(cmap.get("ErrMsg"));
				} else {
					
					// Notes: TODO below is new code for merge gw/cbr routes, above will be cleaned up  
					if (currentRoute.equals("MapOperationNameFromAuthorize")) {
						HashMap<String, String> cmap = message.getInvocationProperty("cMap");
						cmap.put("IsNewRoute", "true");
					}
				}
			}
		}
		
		return true;
	}

}