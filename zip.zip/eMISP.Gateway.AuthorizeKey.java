package com.mulesoft.mule.boa.vo;

public class AuthorizeKey implements java.io.Serializable {
	
	private static final long serialVersionUID = 4708929749972172278L;
	
	private String aitNumber;
	private String resourceName;
	
	public AuthorizeKey(){
		
	}
	
	public AuthorizeKey(String aitNumber,String resourceName){
		this.aitNumber = aitNumber;
		this.resourceName = resourceName;
	}
	
	public String getAitNumber() {
		return aitNumber;
	}
	public void setAitNumber(String aitNumber) {
		this.aitNumber = aitNumber;
	}
	public String getResourceName() {
		return resourceName;
	}
	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((aitNumber == null) ? 0 : aitNumber.hashCode());
		result = prime * result
				+ ((resourceName == null) ? 0 : resourceName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AuthorizeKey other = (AuthorizeKey) obj;
		if (aitNumber == null) {
			if (other.aitNumber != null)
				return false;
		} else if (!aitNumber.equals(other.aitNumber))
			return false;
		if (resourceName == null) {
			if (other.resourceName != null)
				return false;
		} else if (!resourceName.equals(other.resourceName))
			return false;
		return true;
	}
	
	
}
