package com.bac.vo;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "@event", "header" })
public class LogEvents {

	@JsonProperty("@event")
	private String event;
	@JsonProperty("header")
	private List<LogEventsHeader> header = new ArrayList<LogEventsHeader>();

	/**
	 * 
	 * @return The event
	 */
	@JsonProperty("@event")
	public String getEvent() {
		return event;
	}

	/**
	 * 
	 * @param event
	 *            The @event
	 */
	@JsonProperty("@event")
	public void setEvent(String event) {
		this.event = event;
	}

	/**
	 * 
	 * @return The header
	 */
	@JsonProperty("header")
	public List<LogEventsHeader> getHeader() {
		return header;
	}

	/**
	 * 
	 * @param header
	 *            The header
	 */
	@JsonProperty("header")
	public void setHeader(List<LogEventsHeader> header) {
		this.header = header;
	}

}