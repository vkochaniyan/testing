package com.mulesoft.mule.boa.util;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.Iterator;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.xml.sax.ErrorHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

import com.mulesoft.mule.boa.exceptions.GatewayProcessingException;

public class DocumentBuilderUtil {
	
	private static boolean canReuseBuilders = false;
	
	private static final DocumentBuilderFactory BUILDER_FACTORY = DocumentBuilderFactory.newInstance();
	
	private static final ErrorHandler ERROR_HANDLER = new ErrorHandler(){
		public void error(SAXParseException exception) throws SAXException{
			throw exception;
		}
		
		public void warning(SAXParseException exception) throws SAXException{
			
		}
		
		public void fatalError(SAXParseException exception) throws SAXException{
			throw exception;
		}
	};
	
	private static final ThreadLocal<DocumentBuilder> REUSABLE_BUILDER = new ThreadLocal<DocumentBuilder>(){
		@Override
		protected DocumentBuilder initialValue(){
			try{
				return BUILDER_FACTORY.newDocumentBuilder();
			}
			catch(ParserConfigurationException e){
				throw new RuntimeException(e);
			}
		}
	};
	
	static{
		BUILDER_FACTORY.setNamespaceAware(true);
		BUILDER_FACTORY.setValidating(false);
		/**
		 * Can't disable doc types entirely because they're usually harmless. External entity
		 * resolution however is both expensive and insecure
		 */
		try{
			BUILDER_FACTORY.setAttribute("http://xml.org/sax/features/external-general-entities", false);
		}
		catch(IllegalArgumentException e){
			/** MESSAGE KEY ERROR_PARSING_EXTERNAL_PARAMETER_ENTITIES**/
		}
		
		try{
			BUILDER_FACTORY.setAttribute("http://apache.org/xml/features/nonvalidating/load-external-dtd",false);
		}
		catch(IllegalArgumentException e){
			/** MESSAGE KEY ERROR_PARSING_EXTERNAL_DTD**/
		}
		
		try{
			DocumentBuilder builder = BUILDER_FACTORY.newDocumentBuilder();
			builder.reset();
			canReuseBuilders = true;
		}
		catch(UnsupportedOperationException e){
			canReuseBuilders = false;
		}
		catch(ParserConfigurationException e){
			canReuseBuilders = false;
		}
	}
	
	public static DocumentBuilder getBuilder() throws ParserConfigurationException{
		
		DocumentBuilder builder;
		if(canReuseBuilders){
			builder = REUSABLE_BUILDER.get();
			builder.reset();
		}
		else{
			builder = BUILDER_FACTORY.newDocumentBuilder();
		}
		builder.setErrorHandler(ERROR_HANDLER);
		return builder;
	}
	
	public static String getSOAPResponseTag(String responseTag, String soapResponse) throws GatewayProcessingException{
		
		Document doc = null;
		String tagValue = "";
		StringWriter sw = new StringWriter();
		try{
			DocumentBuilder threadLocalDocDispenser = DocumentBuilderUtil.getBuilder();
			InputSource inputSource = new InputSource(new StringReader(soapResponse.trim()));
			doc = threadLocalDocDispenser.parse(inputSource);
			NodeList nodes = doc.getElementsByTagName(responseTag);
		    if(nodes!=null && nodes.getLength()>0){
		    	tagValue = nodes.item(0).getTextContent();
		    }
		}
		catch(SAXParseException saxpe){
			throw new GatewayProcessingException(saxpe);
		}
		catch(SAXException saxe){
			throw new GatewayProcessingException(saxe);
		}
		catch(ParserConfigurationException parsere){
			throw new GatewayProcessingException(parsere);
		}
		catch(IOException ioe){
			throw new GatewayProcessingException(ioe);
		}
		catch(Exception e){
			throw new GatewayProcessingException(e);
		}
		return tagValue;
	}
	
	public static String updateSOAPResponseTags(Map<String,String> responseTags, String soapResponse) throws GatewayProcessingException{
		
		Document doc = null;
		StringWriter sw = new StringWriter();
		try{
			DocumentBuilder threadLocalDocDispenser = DocumentBuilderUtil.getBuilder();
			InputSource inputSource = new InputSource(new StringReader(soapResponse.trim()));
			doc = threadLocalDocDispenser.parse(inputSource);
			Iterator iterator = responseTags.entrySet().iterator();
		    while (iterator.hasNext()) {
		        Map.Entry pair = (Map.Entry)iterator.next();
		        String responseTag = (String)pair.getKey();
		        NodeList nodes = doc.getElementsByTagName(responseTag);
		        if(nodes!=null && nodes.getLength()>0 && pair.getValue()!=null){
		            nodes.item(0).setTextContent(pair.getValue().toString());
				}
		    }
		    TransformerFactory tf = TransformerFactory.newInstance();
			Transformer trans = tf.newTransformer();
			trans.transform(new DOMSource(doc),new StreamResult(sw));
			trans.clearParameters();
		}
		catch(SAXParseException saxpe){
			saxpe.printStackTrace();
			throw new GatewayProcessingException(saxpe);
		}
		catch(SAXException saxe){
			throw new GatewayProcessingException(saxe);
		}
		catch(ParserConfigurationException parsere){
			throw new GatewayProcessingException(parsere);
		}
		catch(IOException ioe){
			throw new GatewayProcessingException(ioe);
		}
		catch(Exception e){
			throw new GatewayProcessingException(e);
		}
		return sw.toString();
	}
}
