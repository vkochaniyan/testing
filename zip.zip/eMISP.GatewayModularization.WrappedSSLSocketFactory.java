package com.bac.component;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.UnrecoverableKeyException;
import java.security.cert.CertificateException;

import javax.net.SocketFactory;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManagerFactory;

public class WrappedSSLSocketFactory extends SSLSocketFactory {
	
	private SSLSocketFactory sslSocketFactory = null;
	
	public WrappedSSLSocketFactory() {
		super();
	}
	
	public WrappedSSLSocketFactory(String keystoreLocation,String trustStoreLocation,String keystorePassword, String securityProviderClass) {
		
		KeyStore keyStore;
        KeyStore trustStore;
        try {
        	if (securityProviderClass == null) {
        		throw new IllegalArgumentException("SecurityProvider Class name is required");
        	}
        	if (keystorePassword == null) {
        		throw new IllegalArgumentException("Keystore password is required");
        	}
			//Class.forName("com.sun.net.ssl.internal.ssl.Provider");
        	Class.forName(securityProviderClass);
	        System.out.println("JSSE is installed correctly!"); 
	        String pass = keystorePassword;
	        char[] password = pass.toCharArray ();
	        keyStore = KeyStore.getInstance ( "JKS" );
	        
	        // JING START
	        InputStream fis = Thread.currentThread().getContextClassLoader().getResourceAsStream(keystoreLocation);
	
	    // JING    java.io.FileInputStream fis = new java.io.FileInputStream (keystoreLocation);
	
	        keyStore.load (fis, password);
	        System.out.println("Number of keys on JKS: " + Integer.toString(keyStore.size()));
	
	        
	        //java.io.FileInputStream fis1 = new java.io.FileInputStream (trustStoreLocation);
	        InputStream fis1 = Thread.currentThread().getContextClassLoader().getResourceAsStream(trustStoreLocation);
	        trustStore = KeyStore.getInstance ("JKS");
	        trustStore.load ( fis1,null );
	
	        // Create a default trust and key manager
	        TrustManagerFactory trustManagerFactory =
	          TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
	
	        KeyManagerFactory keyManagerFactory =
	            KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
	
	        // Initialise the managers
	        trustManagerFactory.init(trustStore);
	        keyManagerFactory.init(keyStore,password); 
	
	        // Get an SSL context.
	        // Note: not all providers support all CipherSuites. But the
	        // "SSL_RSA_WITH_3DES_EDE_CBC_SHA" CipherSuite is supported on both SunJSSE
	        // and IBMJSSE2 providers
	
	        // Accessing available algorithm/protocol in the SunJSSE provider
	        // see http://java.sun.com/javase/6/docs/technotes/guides/security/SunProviders.html 
	        SSLContext sslContext = SSLContext.getInstance("SSLv3"); 
	
	        System.out.println("SSLContext provider: " +sslContext.getProvider().toString()); 
	
	     // Initialise our SSL context from the key/trust managers
	        sslContext.init(keyManagerFactory.getKeyManagers(),trustManagerFactory.getTrustManagers(), null);
	
	        // Get an SSLSocketFactory to pass to WMQ
	        sslSocketFactory = sslContext.getSocketFactory(); 
	        fis.close();
	        fis1.close();
		} catch (KeyStoreException e ) {
			e.printStackTrace();
			
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			
		} catch (NoSuchAlgorithmException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (CertificateException e)  {
            // TODO Auto-generated catch block
            e.printStackTrace ();
        }
        catch (IOException e)  {
            // TODO Auto-generated catch block
            e.printStackTrace ();
        }
        catch (ClassNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (UnrecoverableKeyException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        catch (KeyManagementException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

	}
	
	public static SocketFactory getDefault ( ) {
        return new WrappedSSLSocketFactory();
    }

    public SSLSocketFactory getSslSocketFactory ( ) {
        return sslSocketFactory;
    }

    public void setSslSocketFactory (SSLSocketFactory sslSocketFactory) {
        this.sslSocketFactory = sslSocketFactory;
    }

    @Override
    public Socket createSocket() throws IOException {
    	Socket socket;
        try  {
            if ( sslSocketFactory == null ) {
                getDefault ( );
            }
            socket = sslSocketFactory.createSocket ( );
        }
        catch (SocketException soc) {
            socket = new Socket ( );
        }
        return socket;
    }

	@Override
	public Socket createSocket(Socket s, String host, int port, boolean autoClose)	throws IOException {
		// TODO Auto-generated method stub
		return sslSocketFactory.createSocket ( s, host, port, autoClose );
	}

	@Override
	public String[] getDefaultCipherSuites() {
		// TODO Auto-generated method stub
		return sslSocketFactory.getDefaultCipherSuites ( );
	}

	@Override
	public String[] getSupportedCipherSuites() {
		// TODO Auto-generated method stub
		return sslSocketFactory.getSupportedCipherSuites ( );
	}

	@Override
	public Socket createSocket(String arg0, int arg1) throws IOException, UnknownHostException {
		// TODO Auto-generated method stub
		return sslSocketFactory.createSocket ( arg0, arg1 );
	}

	@Override
	public Socket createSocket(InetAddress arg0, int arg1) throws IOException {
		// TODO Auto-generated method stub
		return sslSocketFactory.createSocket ( arg0, arg1 );
	}

	@Override
	public Socket createSocket(String arg0, int arg1, InetAddress arg2, int arg3)	throws IOException, UnknownHostException {
		// TODO Auto-generated method stub
		return sslSocketFactory.createSocket ( arg0, arg1, arg2, arg3 );
	}

	@Override
	public Socket createSocket(InetAddress arg0, int arg1, InetAddress arg2,int arg3) throws IOException {
		// TODO Auto-generated method stub
		return sslSocketFactory.createSocket ( arg0, arg1, arg2, arg3 );
	}

}

