package com.mulesoft.mule.boa.util;

import java.io.StringReader;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.mule.api.MuleMessage;
import org.mule.api.transformer.TransformerException;
import org.mule.api.transport.PropertyScope;
import org.mule.transformer.AbstractMessageTransformer;
import org.w3c.dom.Document;
import org.xml.sax.InputSource;

public class TraceIdReplacementTransformer extends AbstractMessageTransformer {

	@SuppressWarnings("unchecked")
	
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		
		String soapRequest = (String) message.getPayload();
		String traceId = (String) message.getProperty("traceId",PropertyScope.INVOCATION);
		
		if(traceId!=null){
			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
			String timeStamp = format.format(new Date());
			traceId = traceId +"_" + timeStamp;
			message.setProperty("traceId", traceId, PropertyScope.INVOCATION);
		}
		
		Document document = null;
		StringWriter sw = new StringWriter();
		StreamResult streamResult = new StreamResult(sw);
		String updatedResponse = updateTraceId(soapRequest,traceId);
		return updatedResponse;
	}
	
	private String updateTraceId(String soapRequest, String traceId){
		
		Document document = null;
		StringWriter sw = new StringWriter();
		StreamResult streamResult = new StreamResult(sw);
		String updatedResponse = null;
		
		try 
		{
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder threadLocalDocDispenser = DocumentBuilderUtil.getBuilder();
			InputSource inputSource = new InputSource(new StringReader(soapRequest.trim()));
			document = threadLocalDocDispenser.parse(inputSource);
			
			String traceIdString = DocumentBuilderUtil.getSOAPResponseTag("osa:TraceID",soapRequest);
			Map<String,String> requestTags = new HashMap<String,String>();
			requestTags.put("osa:TraceID", traceId);
			updatedResponse = DocumentBuilderUtil.updateSOAPResponseTags(requestTags,soapRequest);
			TransformerFactory tf = TransformerFactory.newInstance();
			Transformer trans = tf.newTransformer();
			trans.transform(new DOMSource(document), streamResult);
			trans.setOutputProperty(OutputKeys.INDENT, "yes");
			trans.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "2");
			trans.clearParameters();
		} 
		
		catch (Exception e) {
			e.printStackTrace();
		}
		return updatedResponse;
	}
}
