package com.bac.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "protocol", "headerName" })
public class Header {

	@JsonProperty("protocol")
	private String protocol;
	@JsonProperty("headerName")
	private String headerName;

	/**
	 * 
	 * @return The protocol
	 */
	@JsonProperty("protocol")
	public String getProtocol() {
		return protocol;
	}

	/**
	 * 
	 * @param protocol
	 *            The protocol
	 */
	@JsonProperty("protocol")
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	/**
	 * 
	 * @return The headerName
	 */
	@JsonProperty("headerName")
	public String getHeaderName() {
		return headerName;
	}

	/**
	 * 
	 * @param headerName
	 *            The headerName
	 */
	@JsonProperty("headerName")
	public void setHeaderName(String headerName) {
		this.headerName = headerName;
	}

}