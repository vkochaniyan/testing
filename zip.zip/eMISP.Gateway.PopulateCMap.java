package com.mulesoft.mule.boa;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

import com.mulesoft.mule.boa.util.PingSTSGetConfigValues;


public class PopulateCMap implements Callable {
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
    	
		MuleMessage message = eventContext.getMessage();
		Pattern ptn = Pattern.compile("(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})");
		String remoteAddress = (String)message.getInboundProperty("http.remote.address");
		String justIP="";
		Matcher mtch = ptn.matcher(remoteAddress);
		while(mtch.find()){
            justIP = mtch.group();
        }
		SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX");
		/**
		Commented out, observed intermittent parse exceptions in production.suspect multi threading issue
		instead using java.util.Calendar for date formatting
		Date parsedDate = inputDateFormat.parse(new org.mule.el.datetime.DateTime().toString());
		**/
		Calendar cal = Calendar.getInstance();
		String strDate = inputDateFormat.format(cal.getTime());	
		Date parsedDate = inputDateFormat.parse(strDate);
		SimpleDateFormat gmtDateFormat = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss Z");
		gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		String gmttimestamp = gmtDateFormat.format(parsedDate);
		
		Map<String,String> cMap = new HashMap<String,String>();
		String ClientIP = (String)message.getInboundProperty("http.remote.address");
		if(ClientIP.contains("/")){
			ClientIP = ClientIP.replace("/", "").trim();
		}
		if(ClientIP.contains(":")){
			ClientIP = ClientIP.substring(0,ClientIP.indexOf(":")-1);
		}
		cMap.put("ClientIP",ClientIP);
		cMap.put("justIP", justIP);
		cMap.put("gmttimestamp", gmttimestamp.toString());
		cMap.put("HttpMethod",(String)message.getInboundProperty("http.method"));
		cMap.put("X-BOA-Provider-Service",(String)message.getInboundProperty("X-BOA-Provider-Service"));
		cMap.put("X-BOA-Provider-Operation",(String)message.getInboundProperty("X-BOA-Provider-Operation"));
		cMap.put("X-BOA-Provider-ServiceName",(String)message.getInboundProperty("X-BOA-Provider-ServiceName"));
		cMap.put("MGS_PublishTopic",(String)message.getInboundProperty("MGS_PublishTopic"));
		cMap.put("Notification_Events",(String)message.getInboundProperty("Notification_Events"));
		cMap.put("MISP_PublishTopic",(String)message.getInboundProperty("MISP_PublishTopic"));
		cMap.put("CompositeRoute",(String)message.getInboundProperty("macewcfpath"));		
		cMap.put("ErrMsg","");
		cMap.put("ServiceID", PingSTSGetConfigValues.serviceID());
		message.setInvocationProperty("cMap",cMap);
		return eventContext.getMessage().getPayload();
	}
	
}