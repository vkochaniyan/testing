/**
 * 
 */
package com.bac.cache.framework;

/**
 * @author ZKWQBHO
 *
 */
public class CacheLoader implements ICommand {

	
	ICacheManager cacheManager;
	
	public CacheLoader(ICacheManager cacheMgr){
		cacheManager = cacheMgr;
	}
	/* (non-Javadoc)
	 * @see com.bac.cache.framework.Command#execute()
	 */
	@Override
	public void execute() throws Exception {
		cacheManager.loadCache();

	}

}
