/**
 * 
 */
package com.bac.cache.framework;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * @author ZKWQBHO
 *
 */
public class CacheInvoker {
	private SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	
	ICommand theCommand;
	private static final Logger logger = LogManager.getLogger();
	public CacheInvoker(ICommand newCommand){
		theCommand = newCommand;
	}
	
	public void load() throws Exception{
		String startTime  = inputDateFormat.format(Calendar.getInstance().getTime());
		logger.info("Cache Load started : " + startTime);
		theCommand.execute();
		String endTime  = inputDateFormat.format(Calendar.getInstance().getTime());
		logger.info("Cache Load ended : " + endTime);
		logResponseTime(startTime, endTime);
	}
	
	public void refresh() throws Exception{
		String startTime  = inputDateFormat.format(Calendar.getInstance().getTime());
		logger.info("Cache Refresh started : " + startTime);
		theCommand.execute();
		String endTime  = inputDateFormat.format(Calendar.getInstance().getTime());
		logger.info("Cache Refresh ended : " + endTime);
		logResponseTime(startTime, endTime);
	}
	
	
	private long logResponseTime(String RequestEntryTime, String ResponseEntryTime) throws ParseException {

        Date d1 = null;
        Date d2 = null;
  
		d1 = inputDateFormat.parse(RequestEntryTime);
		d2 = inputDateFormat.parse(ResponseEntryTime);
		long diff = d2.getTime() - d1.getTime();
		logger.debug("The Overall Response Time =>  " +diff + " milliseconds");
		return diff;
	}

}
