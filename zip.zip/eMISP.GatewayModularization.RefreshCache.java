/**
 * 
 */
package com.bac.cache.framework;

import java.util.List;

/**
 * @author ZKWQBHO
 *
 */
public class RefreshCache implements ICommand {

	List<ICacheManager> cacheManagers;
	
	public RefreshCache(List<ICacheManager> newCacheManagers){
		cacheManagers = newCacheManagers;
	}
	/* (non-Javadoc)
	 * @see com.bac.cache.framework.Command#execute()
	 */
	@Override
	public void execute() throws Exception {
		for(ICacheManager cacheMgr : cacheManagers){
			cacheMgr.refreshCache();
		}

	}
	
}
