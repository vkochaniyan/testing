package com.bac.component;

import java.io.IOException;
import java.io.StringReader;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;

import com.bac.exceptions.GatewayValidationException;
import com.pingidentity.sts.clientapi.STSClient;
import com.pingidentity.sts.clientapi.STSClientConfiguration;
import com.pingidentity.sts.clientapi.model.RequestSecurityTokenData;
import com.pingidentity.sts.clientapi.model.STSResponse;
import com.pingidentity.sts.clientapi.tokens.saml.Saml20Token;
import com.pingidentity.sts.clientapi.tokens.saml.SamlAttribute;
import com.pingidentity.sts.clientapi.tokens.saml.SamlToken;
import com.pingidentity.sts.clientapi.utils.StringUtils;
import com.sun.syndication.io.impl.Base64;

public class SAML2Validator implements Callable {
	
	private static final Logger logger = LogManager.getLogger();
	
	private static String PING_STS_ENDPOINT_URL = "PingSTSEndPointURL";
	private static String X_BOA_SECURITY_TOKEN = "X-BOA-Security-Token";
		
	/* (non-Javadoc)
	 * @see org.mule.api.lifecycle.Callable#onCall(org.mule.api.MuleEventContext)
	 */
	@Override
	public Object onCall(MuleEventContext eventContext) throws GatewayValidationException {
		
		MuleMessage message = null;
		StringUtils utils = new StringUtils();
		
		Boolean isSAMLTokenValid = Boolean.FALSE;
		String errorMsg = "";
		message = eventContext.getMessage();
		
		String pingEndpoint = message.getInvocationProperty(PING_STS_ENDPOINT_URL);
		String b64Token = message.getInboundProperty(X_BOA_SECURITY_TOKEN);
		String bdecodedToken = null;
		if(b64Token !=null && b64Token.trim() != "" ){
			bdecodedToken = Base64.decode(b64Token);
		}
		
		try {
			Element token = convertStringToDocument(bdecodedToken);
			logger.info(utils.prettyPrint(token));
			SamlToken samltoken = new Saml20Token(token);
			// 1- way : Create validate request
			STSClientConfiguration stsValidateConfig = getConfig(pingEndpoint);
			STSClient provider = new STSClient(stsValidateConfig);
			RequestSecurityTokenData data = provider.createValidateData();
			data.setTokenType(samltoken.getTokenType());
			
			STSResponse stsResponse;
			try {
				logger.info(utils.prettyPrint(samltoken.getRoot()));
				stsResponse = provider.makeRequest(data, samltoken.getRoot(), null, samltoken.getTokenType(), false);
				if (null != stsResponse.getRstr()) {
					isSAMLTokenValid = stsResponse.getRstr().isValidateStatusOk();
					if(isSAMLTokenValid){
						//Fetching the value of ait
						SamlAttribute attrib =  (SamlAttribute) samltoken.getAttributes().get(0);
						String sAIT = attrib.getValue();
						if(sAIT.equalsIgnoreCase("000000")){
						sAIT = "69820";	
						}
			            logger.info(attrib.getValue());			            
			            message.setInvocationProperty("ait", sAIT);
			  		}
					logger.info(utils.prettyPrint(stsResponse.getRstr().getRstrElement()));
				}
				if (null != stsResponse.getSoapFault()){
					errorMsg =  stsResponse.getSoapFault().getFaultString()+ "~"
							+ stsResponse.getSoapFault().getFaultCode();
					throw new GatewayValidationException(errorMsg);
					
				}
			} catch (IOException e) {
				e.printStackTrace();
				throw new GatewayValidationException(e.getMessage()+"~STSClientException");
			}

			// 2- way : Just SAML token validation
		} catch (Exception e) {
			e.printStackTrace();
			try {
				throw new GatewayValidationException(e.getMessage()+"~Exception");
			} catch (GatewayValidationException e1) {
				
				e1.printStackTrace();
			}
		}
		logger.info("Is SAML Token Valid: "+isSAMLTokenValid);
		logger.error(errorMsg);
		message.setInvocationProperty("IS_SAML_VALID", isSAMLTokenValid.toString().toLowerCase());

		return eventContext.getMessage().getPayload();
	}
	
	/**
	 * @param xmlStr String
	 * @return
	 * @throws GatewayValidationException Exception
	 */
	private static Element convertStringToDocument(String xmlStr) throws GatewayValidationException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder;
		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlStr)));
			return doc.getDocumentElement();
		} catch (Exception e) {
			e.printStackTrace();
			throw new GatewayValidationException(e.getMessage()+"~SAML Assertion String to DOM Failed: ");
		}
	}

	/**
	 * @param pingendpoint String
	 * @return stsWSP STSClientConfiguration
	 */
	private static STSClientConfiguration getConfig(String pingendpoint) {

		STSClientConfiguration stsWSP = new STSClientConfiguration();
		stsWSP.setStsEndpoint(pingendpoint);
     	stsWSP.setIgnoreSSLTrustErrors(true);
    	return stsWSP;
	}
}
