package com.mulesoft.mule.boa.util;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.mule.api.context.notification.ConnectorMessageNotificationListener;
import org.mule.context.notification.ConnectorMessageNotification;

import com.mulesoft.mule.boa.RouteFileCacheSingleton;

public class HttpTimestampGet implements ConnectorMessageNotificationListener<ConnectorMessageNotification> {
	
	RouteFileCacheSingleton routingSingleton;
	
	public RouteFileCacheSingleton getRoutingSingleton() {
		return routingSingleton;
	}

	public void setRoutingSingleton(RouteFileCacheSingleton routingSingleton) {
		this.routingSingleton = routingSingleton;
	}
	
	@Override
	public void onNotification(ConnectorMessageNotification notification) {
		// TODO Auto-generated method stub
        if(notification.getAction() == org.mule.context.notification.BaseConnectorMessageNotification.MESSAGE_RECEIVED){
        	//Register timestamp in Map using MuleMessage UniqueID as key
        	Date date = new Date(notification.getTimestamp());
            Format format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
            routingSingleton.updateTimestamp(notification.getSource().getUniqueId(),format.format(date));
        }
	}
}
