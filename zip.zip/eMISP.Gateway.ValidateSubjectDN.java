package com.mulesoft.mule.boa;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;

import org.mule.api.MuleMessage;
import org.mule.api.routing.filter.Filter;

public class ValidateSubjectDN implements Filter {

	@Override
	public boolean accept(MuleMessage message) {		
		
		HashMap<String, String> map = message.getInvocationProperty("cMap");
		if(!map.containsKey("DN") || map.get("DN") == null || map.get("DN").isEmpty()){
			map.put("ErrMsg", "Subject DN Information is missing in Client Certificate");
			throw new NullPointerException("Subject DN Information is missing in Client Certificate");
		}
		else{			
			//String delimiters = map.get("DN");
			

			//String strSplit[] = StringUtils.splitAndTrim(map.get("DN"),delimiters);
			String strSplit[] = map.get("DN").split(",\\s");
			List<String> list = Arrays.asList(strSplit);
			Collections.reverse(list);
			String joiner = "/" + org.apache.commons.lang.StringUtils.join(list, '/');
			groovy.json.StringEscapeUtils.escapeJava(joiner);
			joiner = groovy.json.StringEscapeUtils.escapeJava(joiner);
			
			map.put("DN", joiner);
		
		}
		return true;
	}

}
