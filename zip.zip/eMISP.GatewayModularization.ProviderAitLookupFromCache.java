package com.bac.component;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.Cache;
import org.ehcache.spi.loaderwriter.CacheWritingException;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

import com.bac.cache.framework.ConfigCacheManager;

/**
 * @author ZKZBQ23 Lookup from ehCache
 *
 */
public class ProviderAitLookupFromCache implements Callable {

	private static final Logger logger = LogManager.getLogger();

	private static String HIPHEN_AUTHORIZATION_DOT_JSON = "-authorization.json";
	private static String SERVICE_NAME = "serviceName";
	private static String OPERATION_NAME = "operationName";
	private static String PROVIDER_AIT = "providerAIT";
	private static String ACCESS = "access";
	private static String GRANT = "grant";
	private static String VALIDATE_FOR_GEN4HEADERS = "validateforGen4Headers";
	private static String TARGET_SVC_NAMESPACE_BASEURI = "targetSvcNamespaceBaseUri";
	private static String SOURCE_APPLICATION_ID = "sourceApplicationId";

	private ConfigCacheManager configCacheManager;
	private String authorizationConfiguartionMissing = null;
	private String authorizationFailed = null;
	String resource = null;
	private String serviceName = null;
	private String operationName = null;
	
	/**
	 * @param authorizationConfiguartionMissing
	 *            String
	 * @param authorizationFailed
	 *            String
	 * @param resource
	 *            String
	 */
	public ProviderAitLookupFromCache(String authorizationConfiguartionMissing, String authorizationFailed,
			String resource) {
		this.authorizationConfiguartionMissing = authorizationConfiguartionMissing;
		this.authorizationFailed = authorizationFailed;
		this.resource = resource;
	}

	/**
	 * @param configCacheManager
	 *            ConfigCacheManager
	 */
	public void setConfigCacheManager(ConfigCacheManager configCacheManager) {
		this.configCacheManager = configCacheManager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.mule.api.lifecycle.Callable#onCall(org.mule.api.MuleEventContext)
	 */
	@Override
	public String onCall(MuleEventContext eventContext) throws Exception {

		logger.debug("onCall start");

		String providerAIT = null;
		String validateForGen4Headers = null;
		String ait = null;

		MuleMessage message = eventContext.getMessage();

		// Get a ReadLock on cache
		Cache<String, Object> ehCache = configCacheManager.getConfigCache();

		ReadWriteLock lock = new ReentrantReadWriteLock();
		List<Map<String, String>> authorizeServiceList = null;
		try {
			lock.readLock().lock();
			ait = message.getInvocationProperty("ait");
			String fileName = ait + HIPHEN_AUTHORIZATION_DOT_JSON;

			logger.debug("ait:" + ait);
			logger.debug("fileName: " + fileName);

			authorizeServiceList = (List<Map<String, String>>) ehCache.get(fileName);

			if (authorizeServiceList != null) {
				logger.debug("authorizeServiceList from Cache: " + authorizeServiceList);
			} else {
				logger.error(
						"Authorization JSON file is not on HTTP server or is not available in Cache for the consumerAIT: "
								+ ait);
				throw new Exception(authorizationConfiguartionMissing + ait);
			}

		} catch (CacheWritingException exception) {
			logger.error("ERROR IN GETTING VALUES FROM EHCACHE:  " + exception);
			exception.printStackTrace();
		} finally {
			lock.readLock().unlock();
		}

		serviceName = message.getOutboundProperty(SERVICE_NAME);
		logger.debug("Incoming request service Name: " + serviceName);

		
		operationName = message.getOutboundProperty(OPERATION_NAME);
		logger.debug("Incoming request operation Name: " + operationName);
		
		
		Object[] opt = null;
		
		if (operationName.equals("POST") || operationName.equals("GET") || operationName.equals("PUT")
				|| operationName.equals("PATCH") || operationName.equals("DELETE")) {
			opt = authorizeServiceList.stream().filter(s -> (s.get(SERVICE_NAME).equals(serviceName))
					&& s.get(OPERATION_NAME).equals(operationName) && s.get(ACCESS).equals(GRANT)).toArray();
		} else {
			opt = authorizeServiceList.stream().filter(s -> (s.get(SERVICE_NAME).equals(serviceName))
					&& s.get(OPERATION_NAME).equals(operationName) && s.get(ACCESS).equals(GRANT)).toArray();
		}
	
		if (opt != null && opt.length != 0) {
			logger.debug("ServiceName, operationName matched and access is granted");
		} else {
			logger.error("ServiceName, operationName didnot match or access is not granted");
			throw new Exception(
					authorizationFailed + ":" + ait + " " + resource + ":" + serviceName + "," + operationName);
		}

		Map<String, String> optMap = null;
		
		for (int i = 0; i <= opt.length; i++) {
			optMap = (Map<String, String>) opt[i];

			// Routing to different providers based on source Application Id
			// If Source Application ID is present in Soap Request
			if (StringUtils.isNotEmpty(message.getOutboundProperty(SOURCE_APPLICATION_ID))
					&& StringUtils.isNotBlank(optMap.get(SOURCE_APPLICATION_ID))) {
				String sourceApplicationId = message.getOutboundProperty(SOURCE_APPLICATION_ID);
				
				if (optMap.get(SOURCE_APPLICATION_ID).equals(sourceApplicationId)) {
					providerAIT = getProviderAIT(ait, optMap);
				}
				if (optMap.get(SOURCE_APPLICATION_ID).equals(message.getOutboundProperty(SOURCE_APPLICATION_ID))) {
					break;
				}
			}
			
			else {
				if(!optMap.containsKey(SOURCE_APPLICATION_ID)){
				providerAIT = getProviderAIT(ait, optMap);
				}
				if (StringUtils.isNotBlank(providerAIT)) {
					break;
				}
			}

		} // End of for loop
	
		// If Gen4Header validation is required
		if (optMap.containsKey(VALIDATE_FOR_GEN4HEADERS)) {
			validateForGen4Headers = optMap.get(VALIDATE_FOR_GEN4HEADERS);
			logger.debug("Is Gen4Header Validation required: " + validateForGen4Headers);
			message.setOutboundProperty("validateForGen4Headers", validateForGen4Headers);
		} else {
			logger.debug("Gen4Header validation is not required");
		}

		// If target namespaceuri replacement is required
		if (optMap.containsKey(TARGET_SVC_NAMESPACE_BASEURI)) {
			String targetNamespaceUri = optMap.get(TARGET_SVC_NAMESPACE_BASEURI);
			logger.debug("targetSvcNamespacebaseUri: " + targetNamespaceUri);
			message.setOutboundProperty("targetNamespaceUri", targetNamespaceUri);
		}
		
		logger.debug("onCall end");
		return providerAIT;
	}

	/**
	 * @param ait String
	 * @param optMap Map<String, String>
	 * @return providerAIT String
	 * @throws Exception java.lang.Exception
	 */
	private String getProviderAIT(String ait, Map<String, String> optMap) throws Exception {
		String providerAIT = null;
		
		if (optMap.containsKey(PROVIDER_AIT)) {
			providerAIT = optMap.get(PROVIDER_AIT);
			if (StringUtils.isNotBlank(providerAIT)) {
				logger.debug("Fetched provider AIT");
			} else {
				logger.error("ServiceName,OperationName matched and access is granted but Provider AIT is null or empty");
				throw new Exception(authorizationFailed + ":" + ait + " " + resource + ":" + serviceName);
			}
		} else {
			logger.error("Provider AIT key is missing on HTTP server or in Cache for the service name: "
					+ serviceName);
		}
	
		
		return providerAIT;
	}

}
