package com.bac.audit;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.mule.DefaultMuleMessage;
import org.mule.api.MuleMessage;
import org.mule.api.context.MuleContextAware;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class TransactionTracingPayload extends AbstractMessageTransformer implements MuleContextAware{

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException{
		DefaultMuleMessage muleMessage = null;
		StringBuffer buffer = new StringBuffer();
		
		Pattern ptn = Pattern.compile("(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})");
		String remoteAddress = (String)message.getInvocationProperty("ClientIP");
		String justIP="";
		Matcher mtch = ptn.matcher(remoteAddress);
		while(mtch.find()){
            justIP = mtch.group();
        }
		buffer.append((justIP!=null?justIP:"-")+" ");
		buffer.append((message.getInvocationProperty("userName")!=null?message.getInvocationProperty("userName"):"-")+" ");
		
		SimpleDateFormat gmtDateFormat = new SimpleDateFormat("dd/MMM/yyyy:HH:mm:ss Z");
		gmtDateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
		String gmttimestamp = gmtDateFormat.format(Calendar.getInstance().getTime());
		buffer.append("["+(gmttimestamp!=null?gmttimestamp:"-")+"] ");
		
		String request = message.getInvocationProperty("http.method")+" "+message.getInvocationProperty("EntityURI").toString()+message.getInvocationProperty("httpRelativePath");
		buffer.append((request!=null?('"'+request+'"'):"-")+" ");
		
		buffer.append((message.getInboundProperty("http.status")!=null?message.getInboundProperty("http.status"):"-")+" ");
		buffer.append((message.getInvocationProperty("response-content-length")!=null?message.getInvocationProperty("response-content-length"):"-")+" ");
		buffer.append((message.getInvocationProperty("responseTime")!=null?message.getInvocationProperty("responseTime"):"-")+" ");
		buffer.append((message.getInvocationProperty("traceId")!=null?message.getInvocationProperty("traceId"):"-")+" ");
		buffer.append("- ");
		buffer.append("- ");
		buffer.append("- ");
		buffer.append(message.getInvocationProperty("serviceName")+"_"+message.getInvocationProperty("operationName")+"="+message.getInvocationProperty("backendEpochTime")+":"+message.getInvocationProperty("backendResponseTime")+((message.getInboundProperty("http.status").toString()).equalsIgnoreCase("200")?"":"e"));
		
		muleMessage = new DefaultMuleMessage(null, muleContext);
		muleMessage.setPayload(buffer);
		return muleMessage;
		}
	
}
