package com.mulesoft.mule.boa.vo;

@SuppressWarnings("serial")
public class SmSessionVO implements java.io.Serializable {
		
	private String smSession = "";

	public String getSmSession() {
		return smSession;
	}

	public void setSmSession(String smSession) {
		this.smSession = smSession;
	}
	
	
	
	
}
