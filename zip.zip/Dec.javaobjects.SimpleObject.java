package com.bac.hli.ddis;

public class SimpleObject {
	private String msg;

	public String getMsg() {
		System.out.println("Gettor");
		return msg;
	}

	public void setMsg(String msg) {
		System.out.println("Settor"+this);
		this.msg = msg;
	}

	public SimpleObject() {
		System.out.println("Creator:empty"+this);
		msg = "Hello world";
	}

	public SimpleObject(String msg) {
		System.out.println("Creator:string"+this);
		this.msg = msg;
	}

	public void sayMsg() {
		System.out.println(msg.toUpperCase()+this);
	}
}
