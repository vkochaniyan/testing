package com.bac.hli.ddis;

import java.util.Calendar;
import org.apache.log4j.Logger;

public class SplunkReporter {
	public static SplunkReportObject start(String sourceIP, String appID, String traceId) {
		SplunkReportObject sro = new SplunkReportObject(sourceIP, appID, traceId);
		return sro;
	}
	
	public static void end(SplunkReportObject sro, int HTTPstatusCode, int responseLength) {
		sro.end(HTTPstatusCode, responseLength);
		Logger logger = Logger.getLogger(SplunkReporter.class);
		logger.info(sro);
	}
	
	public static void startSysPerf(SplunkReportObject sro, String service, String operation) {
		sro.startSysPerf(service, operation);
	}

	public static void endSysPerf(SplunkReportObject sro, String service, String operation) {
		sro.endSysPerf(service, operation);
	}

	public static void setSysPerf(SplunkReportObject sro, String service, String operation, long startTime, int duration) {
		Calendar cal = Calendar.getInstance();
		cal.setTimeInMillis(startTime);
		sro.setSysPerf(service, operation, cal, duration);
	}

	public static void setSysPerf(SplunkReportObject sro, String service, String operation, Long startTime, Long duration) {
		setSysPerf(sro, service, operation, startTime.longValue(), duration.intValue());
	}
}
