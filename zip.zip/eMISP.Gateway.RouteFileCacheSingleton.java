package com.mulesoft.mule.boa;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.lang.reflect.Field;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

import com.mulesoft.mule.boa.vo.AuthorizeVO;
import com.mulesoft.mule.boa.vo.CBRLookupDataVO;
import com.mulesoft.mule.boa.vo.CBRLookupKey;
import com.mulesoft.mule.boa.vo.CredentialsVO;
import com.mulesoft.mule.boa.vo.GatewayHttpRouteVO;
import com.mulesoft.mule.boa.vo.GatewayMqRouteVO;
import com.mulesoft.mule.boa.vo.GatewayProcessingPolicy;
import com.mulesoft.mule.boa.vo.GatewayRouteVO;
import com.mulesoft.mule.boa.vo.HttpToMqVO;
import com.mulesoft.mule.boa.vo.IdentityVO;
import com.mulesoft.mule.boa.vo.LogEventsToMq;
import com.mulesoft.mule.boa.vo.LoggingRouteKeyVO;
import com.mulesoft.mule.boa.vo.MasterSorRecurrenceVO;
import com.mulesoft.mule.boa.vo.PolicyActionVO;
import com.mulesoft.mule.boa.vo.ProviderPolicyActionVO;
import com.mulesoft.mule.boa.vo.RouteKeyVO;
import com.mulesoft.mule.boa.vo.SorRecurrenceVO;
import com.mulesoft.mule.boa.vo.ValidationPolicyVO;

public class RouteFileCacheSingleton {
	
	/** Cache hosting processing policies for dynamic flow injection **/
	private Map<String,GatewayProcessingPolicy> injectionApplicationPropertiesCache = new HashMap<String,GatewayProcessingPolicy>();
	
	/** Cache hosting Subject DN and corresponding identity information **/
	private Map<String,IdentityVO> identityFileCache = new HashMap<String,IdentityVO>();
	
	/** Cache hosting unique authorization key and whether the user is authorized for this action **/
	private Map<String,Map<String,AuthorizeVO>> authorizeFileMasterCache = new HashMap<String,Map<String,AuthorizeVO>>();
	
	/** Cache hosting unique route string and corresponding CBR Lookup key **/
	private Map<String,Map<CBRLookupKey,CBRLookupDataVO>> cbrLookupKeyMasterFileCache = new HashMap<String,Map<CBRLookupKey,CBRLookupDataVO>>();
	
	/** Cache hosting unique Gateway route key and corresponding Gateway Route Details **/
	private Map<String,Map<String,GatewayRouteVO>> routeFileMasterCache = new HashMap<String,Map<String,GatewayRouteVO>>();
	
	/** Cache hosting unique operation name key and corresponding policy action details **/
	private Map<String,Map<String,PolicyActionVO>> policyActionMasterCache = new HashMap<String,Map<String,PolicyActionVO>>();
	
	/** Cache hosting unique operation name key and corresponding validation policy details **/
	private Map<String,Map<String,ValidationPolicyVO>> validationPolicyMasterCache = new HashMap<String,Map<String,ValidationPolicyVO>>();
	
	/** Cache hosting route key overrides used by Gateway to replace existing route entries at runtime **/
	private Map<String,Map<String,RouteKeyVO>> providerRouteFileMasterCache = new HashMap<String,Map<String,RouteKeyVO>>();
	
	private ConcurrentHashMap<String,String> mapTimestamps = new ConcurrentHashMap<String,String>();
	
	/** Cache hosting unique time allocation for BKSP service **/
	//private Map<String,Map<String,MasterSorRecurrenceVO>> timeSwitchPolicyFileMasterCache = new HashMap<String,Map<String,MasterSorRecurrenceVO>>();
	private Map<String, Map<String, ProviderPolicyActionVO>> providerPolicyActionMasterCache = new HashMap<String, Map<String, ProviderPolicyActionVO>>();
	private Map<String, MasterSorRecurrenceVO> masterRecurrencesCache = new HashMap<String, MasterSorRecurrenceVO>();
	private Map<String, String> masterSvcOpRecurrencesPolicyCache = new HashMap<String, String>();
	private Map<String,Map<String,String>> consumersSvcOpRecurrencesPolicyCache = new HashMap<String,Map<String,String>>();
	private String mspTransformationTemplate = "";
	private Map<String, Map<String,LoggingRouteKeyVO>> loggingRoutesCache = new HashMap<String, Map<String,LoggingRouteKeyVO>>();
	private static final Logger logger = LogManager.getLogger();
	private Properties config = null;
	
	public void updateTimestamp(String messageId, String timestamp){
		mapTimestamps.putIfAbsent(messageId, timestamp);
	}
	
	public String getTimestamp(String messageId){
		String timestamp = "";
		if(mapTimestamps.get(messageId)!=null){
			timestamp = mapTimestamps.get(messageId);
		}
		return timestamp;
	}
	
	public RouteFileCacheSingleton() throws IOException {
		InputStream cacheStream = null;
		
		try{
			
			String environment = System.getProperty("env");
			config = new Properties();
			String gatewayFile = "igateway."+environment+".properties";
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(gatewayFile);
			config.load(cacheStream);	
			
			// load So rMaste rTraffic Director Policy
			loadSorMasterTrafficDirectorPolicy();
			loadMspTransformationTemplate();
			
			/** Load environment configurations - determine which files to load **/
			List<String> clientAITs = getAITs("routing");
			for(String ait:clientAITs){
				authorizeFileMasterCache.put(ait, loadAuthorizeFile("authorization/"+ait+"-authorize.json"));
				consumersSvcOpRecurrencesPolicyCache.put(ait, loadSorTrafficDirectorPolicy("policy/"+ait+"-SOR-SvcOp-Policy.json"));
				cbrLookupKeyMasterFileCache.put(ait, loadCBRLookupTableFile("routing/"+ait+"-lookup-table.json"));
				routeFileMasterCache.put(ait, loadGatewayRouteFile("routing/"+ait+"-routes.json"));
				policyActionMasterCache.put(ait, loadPolicyActionFile("policy/"+ait+"-Policy-Action.json"));
				validationPolicyMasterCache.put(ait, loadValidationPolicyFile("policy/"+ait+"-Validation-Policy.json"));
				providerPolicyActionMasterCache.put(ait, loadProviderPolicyActionFile("policy/provider/" + ait + "-Policy-Action.json"));
			}
			
			// load provider route cache
			List<String> providerAITs = getAITs("routing/provider");
			for(String providerAIT:providerAITs){
				providerRouteFileMasterCache.put(providerAIT, loadProviderRoutes(environment, "routing/provider/"+providerAIT+"-provider-routes.json"));
			}
			
			loadIdentityFile(environment);
			loadProcessingPolicies();
			loggingRoutesCache.put("logging", loadLoggingRoutes(environment, "logging/logging-routes.json"));
		}
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			try{
				if(cacheStream!=null){
					cacheStream.close();
				}
			}
			catch(IOException ioe){
				throw new IOException(ioe);
			}
		}

	}
	
	/**
	 * Loads environment file entries of the following format and caches them for usage at runtime.
	 * Depending on environment being accessed, these properties will be overriden in lieu of existing entries
	 * at runtime during gateway processing.
	 * 
	 * "env": "ata1",
	 * "protocol": "https",
	 * "domain": "psa-sit1.bankofamerica.com",
	 * "port": "443"
	 * 
	 * @param fileName
	 * @return
	 * @throws IOException
	 */
	
	private Map<String,RouteKeyVO> loadProviderRoutes(String env, String fileName) throws IOException {
		Map<String,RouteKeyVO> providerRoutes = new HashMap<String,RouteKeyVO>();
		InputStream cacheStream = null;
		
		try{
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
			if(cacheStream!=null){
				JSONObject providerRouteMaster = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				JSONArray collection = providerRouteMaster.getJSONArray("collection");
				for(int counter=0;counter<collection.length();counter++){
					JSONObject entry = collection.getJSONObject(counter);
					JSONObject providerRouteMasterKey = entry.getJSONObject("providerRouteMasterKey");
					JSONArray keys = providerRouteMasterKey.getJSONArray("keys");
					JSONArray route = providerRouteMasterKey.getJSONArray("route");
					
				//	List<RouteKeyVO> routeKeysList = new ArrayList<RouteKeyVO>();
					RouteKeyVO providerRoute = new RouteKeyVO();
					for(int index=0;index<route.length();index++){
						JSONObject routeEntry = route.getJSONObject(index);
						String tmpEnv = routeEntry.getString("env");
						if (tmpEnv.equalsIgnoreCase(env)) {
							String protocol = routeEntry.getString("protocol");
							String domain = routeEntry.getString("domain");
							String port = routeEntry.getString("port");
							//If the provider routes entry have uri details for each environment
							String uri="";
							if(!routeEntry.isNull("uri")){
							uri = routeEntry.getString("uri");
							}
							providerRoute = new RouteKeyVO(protocol, domain, port, uri);
							break;
						}
					}
				
					
					for(int keyCounter=0;keyCounter<keys.length();keyCounter++){
	                    JSONObject baseObj = keys.getJSONObject(keyCounter);
	                    String keyName = baseObj.getString("name");
	                    providerRoutes.put(keyName, providerRoute);
	                    
					}
				}
			}	
		}
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			if(cacheStream!=null){
				cacheStream.close();
			}
		}	
		return providerRoutes;
	}
	


	
	public PolicyActionVO getTokenName(String operationName, String aitNumber){
		PolicyActionVO policyActionVO = new PolicyActionVO();
		if(policyActionMasterCache.get(aitNumber)!=null){
			Map<String,PolicyActionVO> policyCache = (Map<String,PolicyActionVO>)policyActionMasterCache.get(aitNumber);
			if(policyCache.get(operationName) != null){
				policyActionVO = (PolicyActionVO)policyCache.get(operationName);
			}
		}
		return policyActionVO;
	}
	
	
	
	public ValidationPolicyVO getValidationPolicy(String operationName, String aitNumber){
		ValidationPolicyVO validationPolicyVO = new ValidationPolicyVO();
		if(validationPolicyMasterCache.get(aitNumber)!=null){
			Map<String,ValidationPolicyVO> validationCache = (Map<String,ValidationPolicyVO>)validationPolicyMasterCache.get(aitNumber);
			if(validationCache.get(operationName) != null){
				validationPolicyVO = (ValidationPolicyVO)validationCache.get(operationName);
			}
		}
		return validationPolicyVO;
	}
	
	private Map<String,PolicyActionVO> loadPolicyActionFile(String fileName) throws IOException {
		
		Map<String,PolicyActionVO> policyActionFileCache = new HashMap<String,PolicyActionVO>();
		InputStream cacheStream = null;
		
		try{
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
			if(cacheStream!=null){
				
				JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				JSONObject policyActions = jsonObject.getJSONObject("policyActions");
				JSONArray svcOperation = policyActions.getJSONArray("svcOperation");
				
				for(int counter=0;counter<svcOperation.length();counter++){
					
					JSONObject baseObj = svcOperation.getJSONObject(counter);
					
					String operationKey = baseObj.getString("value");
					PolicyActionVO policyActionVO = new PolicyActionVO();
					
					if (!baseObj.isNull("ServiceTokens")) {
					    JSONObject serviceTokens = baseObj.getJSONObject("ServiceTokens");
					    JSONObject token = serviceTokens.getJSONObject("Token");
					    String name = token.getString("name");
					    JSONObject inject = token.getJSONObject("inject");
					    String method = inject.getString("method");
				    	JSONObject header = inject.getJSONObject("header");
					
					    String protocol = header.getString("protocol");
					    String type = header.getString("type");
					    JSONObject properties = header.getJSONObject("Properties");
					    JSONObject property = properties.getJSONObject("Property");
					    String sessionSpecHeaderName = property.getString("name");
					
					    policyActionVO.setValueKey(operationKey);
				    	policyActionVO.setTokenName(name);
					    policyActionVO.setInjectMethod(method);
					    policyActionVO.setInjectHeaderProtocol(protocol);
					    policyActionVO.setInjectHeaderType(type);
					    policyActionVO.setInjectHeaderProperty(sessionSpecHeaderName);
					} else if (!baseObj.isNull("HttpToMqHeaders")) {
						JSONObject httpToMqHeaders = baseObj.getJSONObject("HttpToMqHeaders");
						JSONArray mqHeader = httpToMqHeaders.getJSONArray("header");
						HttpToMqVO httpToMqVo = new HttpToMqVO();
						Map<String, String> mqHeaders = new HashMap<String, String>();
						httpToMqVo.setMqHeaders(mqHeaders);
						for(int headerIndex=0;headerIndex<mqHeader.length();headerIndex++){
							
							JSONObject headerObj = mqHeader.getJSONObject(headerIndex);
							String name = headerObj.getString("name");
							String value = headerObj.getString("value");
							mqHeaders.put(name, value);
						}
						policyActionVO.setHttpToMqVO(httpToMqVo);
					}
					
					
					else if (!baseObj.isNull("HttpToMqTopicHeaders")) {
						JSONObject httpToMqHeaders = baseObj.getJSONObject("HttpToMqTopicHeaders");
						JSONArray mqHeaderArray = httpToMqHeaders.getJSONArray("header");
						HttpToMqVO httpToMqVo = new HttpToMqVO();
						
						Map<String, String> mqHeaders = new HashMap<String, String>();
						httpToMqVo.setMqHeaders(mqHeaders);
						String mqTopic="";
						String emitTimeStamp="";
						for (int index = 0; index < mqHeaderArray.length(); index++) {
							JSONObject topicEntry = mqHeaderArray.getJSONObject(index);
							String tmpEnv = topicEntry.getString("env");
							String environment = System.getProperty("env");
								
								if (tmpEnv.equalsIgnoreCase(environment)) {
									mqTopic = topicEntry.getString("topic");
									mqHeaders.put("topic", mqTopic);
									emitTimeStamp = topicEntry.getString("emitTimeStamp");
									mqHeaders.put("emitTimeStamp", emitTimeStamp);
									break;
									}
								
							    }
						policyActionVO.setHttpToMqVO(httpToMqVo);
					}
					
					if (!baseObj.isNull("logEvents")) {
						LogEventsToMq logEventsToMq = new LogEventsToMq();
						JSONObject logEvents = baseObj.getJSONObject("logEvents");
						JSONObject log = logEvents.getJSONObject("log");
						// JSONObject event = log.getJSONObject("event");
						String eventName = log.getString("event");
						logEventsToMq.setEventName(eventName);
						JSONObject eventHeaders = log.getJSONObject("headers");
						JSONArray eventHeader = eventHeaders.getJSONArray("header");

						Map<String, String> evtHdrs = new HashMap<String, String>();

						for (int headerIndex = 0; headerIndex < eventHeader.length(); headerIndex++) {

							JSONObject headerObj = eventHeader.getJSONObject(headerIndex);
							String name = headerObj.getString("name");
							String value = headerObj.getString("text");
							evtHdrs.put(name, value);
						}
						logEventsToMq.setEventHeaders(evtHdrs);
						if (!log.isNull("responseCodes")) {
							JSONObject respCodes = log.getJSONObject("responseCodes");
							JSONArray respCode = respCodes.getJSONArray("responseCode");
							Map<String, String> evtRespCode = new HashMap<String, String>();
							for (int rspCodeIndex = 0; rspCodeIndex < respCode.length(); rspCodeIndex++) {

								JSONObject headerObj = respCode.getJSONObject(rspCodeIndex);
								String value = headerObj.getString("value");
								evtRespCode.put(value, value);
							}
							logEventsToMq.setEventResponseCodes(evtRespCode);
						}

						policyActionVO.setLogEventsToMq(logEventsToMq);

					}
					policyActionFileCache.put(operationKey, policyActionVO);
				}
			}	
		}		
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			if(cacheStream!=null){
				cacheStream.close();
			}
		}	
		return policyActionFileCache;
	}
	
	public GatewayRouteVO getGatewayRoute(String aitNumber, String providerAIT, String routeName){
		GatewayRouteVO routeDataVO = new GatewayRouteVO();
		if(routeFileMasterCache.get(aitNumber)!=null){
			Map<String,GatewayRouteVO> gatewayRouteTableFileCache = (Map<String,GatewayRouteVO>)routeFileMasterCache.get(aitNumber);
			
			if(routeName!=null){
				routeName = routeName.trim();
			}
			
			if(gatewayRouteTableFileCache.get(routeName) == null){
				logger.error(" No matching Gateway Route record found for AIT "+aitNumber+" and route name "+routeName);
				throw new NullPointerException(" No matching Gateway Route record found for AIT "+aitNumber+" and route name "+routeName);
			}
			routeDataVO = (GatewayRouteVO)gatewayRouteTableFileCache.get(routeName);
			
			// check provider route
			if (providerAIT != null && providerAIT.length() > 0) {
				Map<String,RouteKeyVO> providerRoutesCache = providerRouteFileMasterCache.get(providerAIT);
				if (providerRoutesCache != null) {
					RouteKeyVO providerRouteDataVO = providerRoutesCache.get(routeName);
					if (routeDataVO.getProtocol().startsWith("http")) {
						GatewayHttpRouteVO httpRouteDataVO = (GatewayHttpRouteVO) routeDataVO;
						httpRouteDataVO.setProtocol(providerRouteDataVO.getProtocol());
						httpRouteDataVO.setDomain(providerRouteDataVO.getDomain());
						httpRouteDataVO.setPort(providerRouteDataVO.getPort());
						//Pick uri from consumer routes when it is provided else to be picked from provider routes
						if(providerRouteDataVO.getUri().length() > 0)
						httpRouteDataVO.setUri(providerRouteDataVO.getUri());
					}
				} else {
					// TODO JING, it will throw exception once migrate all client routes
					logger.error("Didn't find provider " + providerAIT + " route configuration for " + routeName);
				}
				
			} else {
				logger.error("consumer AIT " + aitNumber + " has not configured  provider AIT# for " + routeName);
			}
		}
		return routeDataVO;
	}
	
	// JING will delete

	public GatewayRouteVO getGatewayRoute(String aitNumber, String routeName){
		GatewayRouteVO routeDataVO = new GatewayRouteVO();
		if(routeFileMasterCache.get(aitNumber)!=null){
			Map<String,GatewayRouteVO> gatewayRouteTableFileCache = (Map<String,GatewayRouteVO>)routeFileMasterCache.get(aitNumber);
			
			if(routeName!=null){
				routeName = routeName.trim();
			}
			
			if(gatewayRouteTableFileCache.get(routeName) == null){
				logger.error(" No matching Gateway Route record found for AIT "+aitNumber+" and route name "+routeName);
				throw new NullPointerException(" No matching Gateway Route record found for AIT "+aitNumber+" and route name "+routeName);
			}
			routeDataVO = (GatewayRouteVO)gatewayRouteTableFileCache.get(routeName);
		}
		return routeDataVO;
	}

	
	private Map<String,GatewayRouteVO> loadGatewayRouteFile(String fileName) throws IOException {
		
		Map<String,GatewayRouteVO> gatewayRouteFileCache = new HashMap<String,GatewayRouteVO>();
		InputStream cacheStream = null;
		
		try{
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
			if(cacheStream!=null){
				
				JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				JSONObject runtimeRouting = jsonObject.getJSONObject("runtimeRoutingInstructions");
				JSONArray service = runtimeRouting.getJSONArray("service");
				
				for(int counter=0;counter<service.length();counter++){
					
					JSONObject baseObj = service.getJSONObject(counter);
					JSONObject routeObj = baseObj.getJSONObject("route");
					String name = routeObj.getString("name");
					
					String protocol = "http";  // default
					if (!routeObj.isNull("protocol")) {
						protocol = routeObj.getString("protocol");
				    }
					
					if (protocol.startsWith("http")) {
						//uri to be picked from consumer routes only if there is an entry
						String uri="";
						if(!routeObj.isNull("uri")){
							uri = routeObj.getString("uri");
							}
						
					    //String uri = routeObj.getString("uri");
					    // protocol, domain and port will be set in provider route
					    GatewayHttpRouteVO routeVO = new GatewayHttpRouteVO(name,protocol,"","",uri);
					    
					    if (!routeObj.isNull("content-type")) {
					    	routeVO.setContentType(routeObj.getString("content-type"));
					    }
					    
					    if (!routeObj.isNull("httpUsage")) {
					    	routeVO.setHttpUsage(routeObj.getString("httpUsage"));
					    }
					    
					    if (!routeObj.isNull("targetNamespaceURI")) {
					    	routeVO.setTargetNamespaceURI(routeObj.getString("targetNamespaceURI"));
					    }
					    
					    JSONObject credentials = null;
					    if (!routeObj.isNull("credentials")) {
					    	credentials = routeObj.getJSONObject("credentials");;
					    }
					    
					    if (credentials != null) {
					    	CredentialsVO credentialsVO = new CredentialsVO();
					    	if (!credentials.isNull("password")) {
					    		credentialsVO.setCredentialsPassword(credentials.getString("password"));
						    }
					    	if (!credentials.isNull("type")) {
					    		credentialsVO.setCredentialsType(credentials.getString("type"));
						    }
					    	if (!credentials.isNull("user")) {
					    		credentialsVO.setCredentialsUser(credentials.getString("user"));
						    }
					    	routeVO.setCredentialsVO(credentialsVO);
					    }
					
					    gatewayRouteFileCache.put(name, routeVO);
					}
					else if (protocol.startsWith("mq")) {
						String queueManagerGroupSet = routeObj.getString("queueManagerGroupSet");
					    String mqMsgType = routeObj.getString("mqMsgType");
					    String timeout = routeObj.getString("timeout");
					    //To pick the topic details based on the environment
						String mqTopic="";
					    if(routeObj.optJSONArray("MQPublishTopic") != null && routeObj.optJSONArray("MQPublishTopic").length()>0)
					    {
					    JSONArray mqTopicArray = routeObj.optJSONArray("MQPublishTopic");
					    
					    for (int index = 0; index < mqTopicArray.length(); index++) {
							JSONObject topicEntry = mqTopicArray.getJSONObject(index);
							String tmpEnv = topicEntry.getString("env");
							String environment = System.getProperty("env");
							
							if (tmpEnv.equalsIgnoreCase(environment)) {
								mqTopic = topicEntry.getString("publishTopic");
								break;
							}
					    }
					    }
					    else{
					    	mqTopic = routeObj.getString("mqTopic");
					    }
					
					    GatewayMqRouteVO routeVO = new GatewayMqRouteVO(name,protocol,queueManagerGroupSet,mqMsgType,timeout,mqTopic);
					    gatewayRouteFileCache.put(name, routeVO);
						
					} else {
						System.out.println("protocol " + protocol + " is not supported!");
					}
				}
			}	
		}		
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			if(cacheStream!=null){
				cacheStream.close();
			}
		}	
		return gatewayRouteFileCache;
	}
	
	
	public CBRLookupDataVO getCBRLookupData(String serviceName, String operationName, String aitNumber){
		CBRLookupKey key = new CBRLookupKey(serviceName,operationName);
		CBRLookupDataVO lookupDataVO = new CBRLookupDataVO();
		if(cbrLookupKeyMasterFileCache.get(aitNumber)!=null){
			Map<CBRLookupKey,CBRLookupDataVO> cbrLookupTableFileCache = (Map<CBRLookupKey,CBRLookupDataVO>)cbrLookupKeyMasterFileCache.get(aitNumber);
			if(cbrLookupTableFileCache.get(key) == null){
				throw new NullPointerException(" No matching CBR Lookup record found for service "+serviceName+" and operation "+operationName);
			}
			lookupDataVO = (CBRLookupDataVO)cbrLookupTableFileCache.get(key);
		}
		return lookupDataVO;
	}
	
	public CBRLookupDataVO getCBRLookupData(String serviceName, String operationName, String aitNumber, String sourceApplicationId){
		CBRLookupKey key = new CBRLookupKey(serviceName,operationName,sourceApplicationId);
		CBRLookupDataVO lookupDataVO = new CBRLookupDataVO();
		if(cbrLookupKeyMasterFileCache.get(aitNumber)!=null){
			Map<CBRLookupKey,CBRLookupDataVO> cbrLookupTableFileCache = (Map<CBRLookupKey,CBRLookupDataVO>)cbrLookupKeyMasterFileCache.get(aitNumber);
			if(cbrLookupTableFileCache.get(key) == null){
				throw new NullPointerException(" No matching CBR Lookup record found for service "+serviceName+" and operation "+operationName);
			}
			lookupDataVO = (CBRLookupDataVO)cbrLookupTableFileCache.get(key);
		}
		return lookupDataVO;
	}
	
	private Map<CBRLookupKey,CBRLookupDataVO> loadCBRLookupTableFile(String fileName) throws IOException {
		
		Map<CBRLookupKey,CBRLookupDataVO> cbrLookupTableFileCache = new HashMap<CBRLookupKey,CBRLookupDataVO>();
		InputStream cacheStream = null;
		
		try{
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
			if(cacheStream!=null){
				JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				JSONObject serviceRouting = jsonObject.getJSONObject("serviceRoutingInstructions");
				JSONArray serviceArray = serviceRouting.getJSONArray("service");
				
				String contentType = "";
				for(int counter=0;counter<serviceArray.length();counter++){
					JSONObject baseObj = serviceArray.getJSONObject(counter);
					String serviceName = baseObj.getString("value");
					
					if(!baseObj.isNull("content-type")){
						contentType = baseObj.getString("content-type");
					}
					
					JSONObject operationObj = baseObj.getJSONObject("operation");
					String operation = operationObj.getString("value");
					
					//sourceApplicationId
					String sourceApplicationId = operationObj.optString("sourceApplicationId");

					JSONObject serviceDetails = operationObj.getJSONObject("serviceDetails");
					String route = serviceDetails.getString("route");
					
					String orchestrationHeader = "";
					String targetNamespaceURI = "";
					if (!serviceDetails.isNull("orchestrationHeader")) {
						orchestrationHeader = serviceDetails.getString("orchestrationHeader");
				    }
					
					if (!serviceDetails.isNull("virtualizationInfo")) {
						JSONObject virtualizationInfo = serviceDetails.getJSONObject("virtualizationInfo");
						if (virtualizationInfo != null) {
							if (!serviceDetails.isNull("virtualizationInfo")) {
								targetNamespaceURI = virtualizationInfo.getString("targetNamespaceURI");
						    }
						}
				    }
					CBRLookupKey key;
					
					if(sourceApplicationId != null && sourceApplicationId.trim().length() > 0)
					{
						key = new CBRLookupKey(serviceName,operation,sourceApplicationId);
					}
					else{
						key = new CBRLookupKey(serviceName,operation);
					}
					CBRLookupDataVO lookupDataVO = new CBRLookupDataVO(targetNamespaceURI, route, orchestrationHeader);
					lookupDataVO.setContentType(contentType);
					cbrLookupTableFileCache.put(key, lookupDataVO);
				}
			}	
		}		
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			if(cacheStream!=null){
				cacheStream.close();
			}
		}	
		return cbrLookupTableFileCache;
	}
	
	public AuthorizeVO getAuthorize(String resourceName,String aitNumber){
		
		AuthorizeVO authorize = new AuthorizeVO();
		if(authorizeFileMasterCache.get(aitNumber)!=null){
			Map<String,AuthorizeVO> authorizeCache = (Map<String,AuthorizeVO>)authorizeFileMasterCache.get(aitNumber);
			
			if(resourceName!=null){
				resourceName = resourceName.trim();
			}
			
			if(authorizeCache.get(resourceName) == null){
				throw new NullPointerException("No matching authorization resource found in route "+resourceName+" for this AIT "+aitNumber);
			}
			authorize = (AuthorizeVO)authorizeCache.get(resourceName);
		}
		return authorize;
	}
	
	private Map<String,AuthorizeVO> loadAuthorizeFile(String fileName) throws IOException {
		
		Map<String,AuthorizeVO> authorizeFileCache = new HashMap<String,AuthorizeVO>();
		InputStream cacheStream = null;
		
		try{
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
			if(cacheStream!=null){
				JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				JSONObject authorization = jsonObject.getJSONObject("authorization");
				JSONArray svcOperation = authorization.getJSONArray("SvcOperation");
				for(int counter=0;counter<svcOperation.length();counter++){
					JSONObject entry = svcOperation.getJSONObject(counter);//Access,AllowUnfilteredResponse
					AuthorizeVO authorizeVO = new AuthorizeVO();
					authorizeVO.setAccess((String)entry.getString("Access"));
					authorizeVO.setAllowUnfilteredResponse((String)entry.getString("AllowUnfilteredResponse"));
					if(!entry.isNull("ProviderAIT")){
						authorizeVO.setProviderAIT((String)entry.getString("ProviderAIT"));
					}
					if(entry.getString("value")!=null){
						authorizeVO.setValue((String)entry.getString("value").trim());
					}
					authorizeFileCache.put(authorizeVO.getValue(), authorizeVO);
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			if(cacheStream!=null){
				cacheStream.close();
			}
		}	
		return authorizeFileCache;
	}
	
	public IdentityVO getIdentity(String identity){
		if(identityFileCache.get(identity) == null){
			throw new NullPointerException("No matching entry found for "+identity);
		}
		return identityFileCache.get(identity);
	}
	
	private void loadIdentityFile(String env) throws IOException {
		InputStream cacheStream = null;
		try{
			if (env.toLowerCase().contains("prod")) {
			    cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("gw-identity-prod.json");
			} else {
				cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("gw-identity-lle.json");
			}
			if(cacheStream!=null){
				JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				JSONObject gwIdentify = jsonObject.getJSONObject("gw-identify");
				JSONArray httpIdentify = gwIdentify.getJSONArray("http-identity");
				for(int counter=0;counter<httpIdentify.length();counter++){
					JSONObject entry = httpIdentify.getJSONObject(counter);
					String subjectDN = entry.getString("subjectDN").trim();
					IdentityVO identityVO = new IdentityVO();
					Class<?> clazz = identityVO.getClass();
					Set<String> keySet = entry.keySet();
					Iterator<String> keySetIterator = keySet.iterator();
					while(keySetIterator.hasNext()){
						String fieldName = (String)keySetIterator.next();
						Field field = clazz.getDeclaredField(fieldName);
						field.setAccessible(true);
						field.set(identityVO, entry.getString(fieldName).trim());
					}
					identityFileCache.put(subjectDN, identityVO);
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			try{
				if(cacheStream!=null){
					cacheStream.close();
				}
			}
			catch(IOException e){
				e.printStackTrace();
			}
		}
	}
	
	public GatewayProcessingPolicy getInjectionProperties(String uri){
		return injectionApplicationPropertiesCache.get(uri);
	}
	
	private void loadProcessingPolicies() throws IOException {
		InputStream cacheStream = null;
		try{
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream("policies/processingPolicies.json");
			if(cacheStream!=null){
				JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				JSONObject processingPolicy = jsonObject.getJSONObject("gateway-processing-policies");
				JSONArray policySet = processingPolicy.getJSONArray("processing-policy-set");
				for(int counter=0;counter<policySet.length();counter++){
					JSONObject entry = policySet.getJSONObject(counter);
					JSONObject input = entry.getJSONObject("input");
					JSONObject preprocessing = entry.getJSONObject("preprocessing");
					String flows = preprocessing.getString("flows");
					String matchType = input.getString("match-type");
					String matchValue = input.getString("match-value");
					GatewayProcessingPolicy policy = new GatewayProcessingPolicy();
					policy.setPreprocessing(flows);
					policy.setUri(matchValue);
					injectionApplicationPropertiesCache.put(matchValue, policy);
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			if(cacheStream!=null){
				cacheStream.close();
			}
		}
	}
	
    private Map<String,ValidationPolicyVO> loadValidationPolicyFile(String fileName) throws IOException {
		
		Map<String,ValidationPolicyVO> validationPolicyFileCache = new HashMap<String,ValidationPolicyVO>();
		InputStream cacheStream = null;
		
		try{
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
			if(cacheStream!=null){
				
				JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				JSONObject policyActions = jsonObject.getJSONObject("validationPolicy");
				JSONArray svcOperation = policyActions.getJSONArray("svcOperation");
				
				for(int counter=0;counter<svcOperation.length();counter++){
					
					JSONObject baseObj = svcOperation.getJSONObject(counter);
					
					String operationKey = baseObj.getString("value");					
					String validateforGen4Header = baseObj.getString("validateforGen4Headers");			
					
					ValidationPolicyVO validationPolicyVO = new ValidationPolicyVO();
					validationPolicyVO.setValueKey(operationKey);
					validationPolicyVO.setIsGen4Validation(validateforGen4Header);					
					validationPolicyFileCache.put(operationKey, validationPolicyVO);					
				}
			
			}	
		}		
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			if(cacheStream!=null){
				cacheStream.close();
			}
		}	
		return validationPolicyFileCache;
	}
	

	private List<String> getAITs(String path) {
		List<String> aits = new ArrayList<String>();
		String jarPath = this.getClass().getProtectionDomain().getCodeSource().getLocation().getPath();
		logger.error("Info jarpath=" + jarPath);
		File[] routeFiles = new File(jarPath + path).listFiles();
		for (File file : routeFiles) {
		    if (file.isFile()) {
		    	String fileName = file.getName();
		    	if (fileName.contains("routes")) {
		    		int index = fileName.indexOf('-');
		    		aits.add(fileName.substring(0, index));
		    	}
		       
		    }
		}
		
		return aits;
	}
	public String getPingSTSEndPoint(){
		System.out.println("Loading pinsgts sp end point");
		return config.getProperty("PingSts.SPEndPoint");
	}
	
  
    private void loadSorMasterTrafficDirectorPolicy() throws IOException {
    	
    	String Master_SOR_Recurrences_File = "policy/Master-SOR-Recurrences.json";
    	String Master_SOR_SvcOp_Policy_File =  "policy/Master-SOR-SvcOp-Policy.json";
		
		InputStream cacheStream = null;
		
		try{
			// step 1: load Master-SOR-Recurrences.json
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(Master_SOR_Recurrences_File);
			if(cacheStream!=null){
				JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				
				JSONArray recurrenceArray = jsonObject.getJSONArray("masterSorRecurrences");
				for(int counter=0;counter<recurrenceArray.length();counter++){
					JSONObject entry = recurrenceArray.getJSONObject(counter);
					
					List<SorRecurrenceVO> recurrenceVOList = new ArrayList<SorRecurrenceVO>();
					String recurrenceName = entry.getString("recurrenceName").trim();
					String defaultSor = entry.getString("defaultSor").trim();
					MasterSorRecurrenceVO masterSorRecurrenceVO = new MasterSorRecurrenceVO(recurrenceName, defaultSor, recurrenceVOList);
					
					if (!entry.isNull("recurrence")) {
						JSONArray recurrenceList = entry.getJSONArray("recurrence");
						for (int dtCounter = 0; dtCounter < recurrenceList.length(); dtCounter++) {
							JSONObject dtEntry = recurrenceList.getJSONObject(dtCounter);
							String typeStr = dtEntry.getString("type");
							int type = SorRecurrenceVO.DAILY;
							if (typeStr.equalsIgnoreCase("Weekly")) {
								type = SorRecurrenceVO.WEEKLY;
							}

							String weeksStr = "";
							if (!dtEntry.isNull("weeks")) {
								weeksStr = dtEntry.getString("weeks").trim();
							}
							List<Integer> weeks = weeksStringToList(weeksStr);
							String sor = dtEntry.getString("sor");
							String startTimeInGMT = dtEntry.getString("startTimeInGMT").trim();
							String endTimeInGMT = dtEntry.getString("endTimeInGMT").trim();
							String startDate = dtEntry.getString("startDate").trim();
							String endDate = dtEntry.getString("endDate").trim();

							SorRecurrenceVO recurrenceVO = new SorRecurrenceVO(type, startTimeInGMT, endTimeInGMT, startDate, endDate, sor, weeks);
							recurrenceVOList.add(recurrenceVO);
						}
					}
					masterRecurrencesCache.put(recurrenceName, masterSorRecurrenceVO);
				}
			}
			
			// step 2: load Master_SOR_SvcOp_Policy_File
			masterSvcOpRecurrencesPolicyCache = loadSorTrafficDirectorPolicy(Master_SOR_SvcOp_Policy_File);
		}
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			if(cacheStream!=null){
				cacheStream.close();
			}
		}	
	}
    
    private Map<String, String> loadSorTrafficDirectorPolicy(String SOR_SvcOp_Policy_File) throws IOException {
    	
    	Map<String, String> svcOpRecurrencesPolicies = new HashMap<String, String>();
		InputStream cacheStream = null;
		
		try{
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(SOR_SvcOp_Policy_File);
			if (cacheStream != null) {
				JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				JSONArray sorSvcOpPolicyArray = jsonObject.getJSONArray("sorSvcOpPolicy");
				for (int counter = 0; counter < sorSvcOpPolicyArray.length(); counter++) {
					JSONObject entry = sorSvcOpPolicyArray.getJSONObject(counter);
					String recurrenceName = entry.getString("recurrenceName").trim();
					JSONArray svcOperationList = entry.getJSONArray("svcOperation");
					for (int dtCounter = 0; dtCounter < svcOperationList.length(); dtCounter++) {
						String scvOp = svcOperationList.getString(dtCounter);
						svcOpRecurrencesPolicies.put(scvOp, recurrenceName);
					}
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			if(cacheStream!=null){
				cacheStream.close();
			}
		}	
		return svcOpRecurrencesPolicies;
	}
    
    private void loadMspTransformationTemplate() throws IOException {
    	String TEMPLATE_File = "dataWeaveCode/mspTransformationTemplate.dwl";
		InputStream cacheStream = null;
		try{
			// step 1: load Master-SOR-Recurrences.json
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(TEMPLATE_File);
			if(cacheStream!=null){
				mspTransformationTemplate = IOUtils.toString(cacheStream, StandardCharsets.UTF_8);
			} else {
				String errorMsg = "Failed to load mspTransformationTemplate.dwl";
				System.out.println(errorMsg);
				throw new IOException(errorMsg);
			}
		}
		catch(Exception e){
			e.printStackTrace();
			throw new IOException(e);
		}
		finally{
			if(cacheStream!=null){
				cacheStream.close();
			}
		}	
	}
    
    public String getMspTransformationScript(String operationName){
		String placeHolder = "GSOPERATIONPLACEHOLDERGS";
		return mspTransformationTemplate.replace(placeHolder, operationName);
	}

    private int dateStringToInt(String date) {
    	
    	if (date.equalsIgnoreCase("MONDAY")) {
    		return Calendar.MONDAY;
    	}
    	if (date.equalsIgnoreCase("TUESDAY")) {
    		return Calendar.TUESDAY;
    	}
    	if (date.equalsIgnoreCase("WEDNESDAY")) {
    		return Calendar.WEDNESDAY;
    	}
    	if (date.equalsIgnoreCase("THURSDAY")) {
    		return Calendar.THURSDAY;
    	}
    	if (date.equalsIgnoreCase("FRIDAY")) {
    		return Calendar.FRIDAY;
    	}
    	if (date.equalsIgnoreCase("SATURDAY")) {
    		return Calendar.SATURDAY;
    	}
    	if (date.equalsIgnoreCase("SUNDAY")) {
    		return Calendar.SUNDAY;
    	}
    	
    	throw new RuntimeException("dateStringToInt: date is incorrect - " + date);
    }
    
    private List<Integer> weeksStringToList(String weeksStr) {
    	String weeks [] = weeksStr.split(",");
    	List<Integer> weekList = new ArrayList<Integer>();
    	for (String w : weeks) {
    		String week = w.trim();
    		if (week.isEmpty()) {
    			continue;
    		}
    		weekList.add(dateStringToInt(week));
    	}
    	return weekList;
    }
    
   
    public String getSorTrafficDirector(String resourceName,String aitNumber, String providerAIT){
    	System.out.println("in getSorTrafficDirector ---, resourceName=" + resourceName + ", aitNumber=" + aitNumber + ", providerAIT=" + providerAIT);
    	if (!providerAIT.equals("orchestration")) {
    		return "";
    	}
    	// Step 1 check client SOR policy
    	Map<String,String> clientScheduleMap = consumersSvcOpRecurrencesPolicyCache.get(aitNumber);
    	if (clientScheduleMap != null) {
    		String recurrenceName = clientScheduleMap.get(resourceName);
    		if (recurrenceName != null) {
    			MasterSorRecurrenceVO clientMasterRecurrence = masterRecurrencesCache.get(recurrenceName);
    			if (clientMasterRecurrence != null) {
    				System.out.println("Info: find " + resourceName + " in Consumer " + aitNumber + "  SvcOp Recurrences Policy Cache.");
    				return getSORByMasterRecurrence(clientMasterRecurrence);
    			}
    		}
    	}
    	
    	// check master SOR policy
    	String masterRecurrenceName = masterSvcOpRecurrencesPolicyCache.get(resourceName);
    	if (masterRecurrenceName == null) {
    		System.out.println("Info: cannot find " + resourceName + " in master SvcOp Recurrences Policy Cache.");
    		return "";
    	}
    	
    	MasterSorRecurrenceVO masterRecurrence = masterRecurrencesCache.get(masterRecurrenceName);
    	if (masterRecurrence == null) {
    		System.out.println("Info: cannot find " + masterRecurrenceName + " in maste rRecurrences Cache.");
    		return "";
    	}
    	return getSORByMasterRecurrence(masterRecurrence);
	}
    
    private String getSORByMasterRecurrence(MasterSorRecurrenceVO masterRecurrence){
    	System.out.println("in getSORByMasterRecurrence ---");
    	
        SimpleDateFormat dateFormatter = new SimpleDateFormat("MM/dd/yyyy");
        SimpleDateFormat timeFormatter = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
        timeFormatter.setTimeZone(TimeZone.getTimeZone("GMT"));
        Date currDate = new Date();
        String currDateStr = dateFormatter.format(currDate);
        
        // which day
        Calendar cal = Calendar.getInstance();
        cal.setTime(currDate);
        int currDay = cal.get(Calendar.DAY_OF_WEEK);
       
		try {
			// check Daily schedule first
			for (SorRecurrenceVO recurrence : masterRecurrence.getRecurrenceList()) {
				System.out.println(recurrence.toString());
				if (recurrence.getType() == SorRecurrenceVO.WEEKLY) {
					// check if current day is in schedule
					boolean isCurrDayInSchedule = false;
					for (Integer day : recurrence.getWeeks()) {
						if (day.intValue() == currDay) {
							isCurrDayInSchedule = true;
							break;
						}
					}
					if (isCurrDayInSchedule == false) {
						continue;
					}
				}

				// check daily schedule
				try {
					Date startDate = dateFormatter.parse(recurrence.getStartDate());
					Date endDate = dateFormatter.parse(recurrence.getEndDate());

					if (currDate.after(startDate) && currDate.before(endDate)) {
						// date is in range. will check time range

						String startTimeStr = currDateStr + " " + recurrence.getStartTimeInGMT();
						Date startTime = timeFormatter.parse(startTimeStr);
						String endTimeStr = currDateStr + " " + recurrence.getEndTimeInGMT();
						Date endTime = timeFormatter.parse(endTimeStr);
					
						if (currDate.after(startTime) && currDate.before(endTime)) {
							System.out.println("match found (GMT): " + startTimeStr + ", " + endTimeStr);
							return recurrence.getSor();
						}
					}
				} catch (Exception e1) {
					System.out.println("getSORByMasterRecurrence catch exception: " + recurrence.toString() + ", " + e1.getMessage());
				}
			}
		} catch (Exception e2) {
			System.out.println("getSORByMasterRecurrence catch exception at out loop: " + e2.getMessage());
		}
		return masterRecurrence.getDefaultSor();
	}
    
    private Map<String, LoggingRouteKeyVO> loadLoggingRoutes(String env, String fileName) throws IOException {
		Map<String, LoggingRouteKeyVO> loggingRoutes = new HashMap<String, LoggingRouteKeyVO>();
		InputStream cacheStream = null;

		try {
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
			if (cacheStream != null) {
				JSONObject providerRouteMaster = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				JSONArray collection = providerRouteMaster.getJSONArray("collection");
				for (int counter = 0; counter < collection.length(); counter++) {
					JSONObject entry = collection.getJSONObject(counter);
					JSONObject providerRouteMasterKey = entry.getJSONObject("loggingRoutesKey");
					JSONArray keys = providerRouteMasterKey.getJSONArray("keys");
					JSONArray route = providerRouteMasterKey.getJSONArray("route");

					// List<RouteKeyVO> routeKeysList = new
					// ArrayList<RouteKeyVO>();
					LoggingRouteKeyVO providerRoute = new LoggingRouteKeyVO();
					for (int index = 0; index < route.length(); index++) {
						JSONObject routeEntry = route.getJSONObject(index);
						String tmpEnv = routeEntry.getString("env");
						if (tmpEnv.equalsIgnoreCase(env)) {
							String protocol = routeEntry.getString("publishTopic");							
							providerRoute = new LoggingRouteKeyVO(protocol);
							break;
						}
					}

					for (int keyCounter = 0; keyCounter < keys.length(); keyCounter++) {
						JSONObject baseObj = keys.getJSONObject(keyCounter);
						String keyName = baseObj.getString("name");
						loggingRoutes.put(keyName, providerRoute);

					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw new IOException(e);
		} finally {
			if (cacheStream != null) {
				cacheStream.close();
			}
		}
		return loggingRoutes;
	}

    public LogEventsToMq GetLogEvents(String operationName, String clientAitNumber, String providerAitNumber) {
		//PolicyActionVO policyActionVO = new PolicyActionVO();
		LogEventsToMq logEventsToMq = null;
		if (policyActionMasterCache.get(clientAitNumber) != null) {
			Map<String, PolicyActionVO> policyCache = (Map<String, PolicyActionVO>) policyActionMasterCache
					.get(clientAitNumber);
			if (policyCache.get(operationName) != null) {
				PolicyActionVO policyActionVO = (PolicyActionVO) policyCache.get(operationName);
				if(policyActionVO != null && policyActionVO.getLogEventsToMq() != null)
					logEventsToMq = policyActionVO.getLogEventsToMq();
			}
		}
		if (logEventsToMq == null && providerPolicyActionMasterCache.get(providerAitNumber) != null) {
			Map<String, ProviderPolicyActionVO> policyCache = (Map<String, ProviderPolicyActionVO>) providerPolicyActionMasterCache
					.get(providerAitNumber);
			if (policyCache.get(operationName) != null) {
				ProviderPolicyActionVO policyActionVO = (ProviderPolicyActionVO) policyCache.get(operationName);
				if(policyActionVO != null && policyActionVO.getLogEventsToMq() != null)
					logEventsToMq = policyActionVO.getLogEventsToMq();
			}
		}
		
		return logEventsToMq;
	}
    private Map<String, ProviderPolicyActionVO> loadProviderPolicyActionFile(String fileName) throws IOException {

		Map<String, ProviderPolicyActionVO> providerPolicyActionFileCache = new HashMap<String, ProviderPolicyActionVO>();
		InputStream cacheStream = null;

		try {
			cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(fileName);
			if (cacheStream != null) {

				JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				JSONObject policyActions = jsonObject.getJSONObject("policyActions");
				JSONArray svcOperation = policyActions.getJSONArray("svcOperation");

				for (int counter = 0; counter < svcOperation.length(); counter++) {

					JSONObject baseObj = svcOperation.getJSONObject(counter);

					String operationKey = baseObj.getString("value");
					ProviderPolicyActionVO providerPolicyActionVO = new ProviderPolicyActionVO();

					if (!baseObj.isNull("ServiceTokens")) {
						JSONObject serviceTokens = baseObj.getJSONObject("ServiceTokens");
						JSONObject token = serviceTokens.getJSONObject("Token");
						String name = token.getString("name");
						JSONObject inject = token.getJSONObject("inject");
						String method = inject.getString("method");
						JSONObject header = inject.getJSONObject("header");

						String protocol = header.getString("protocol");
						String type = header.getString("type");
						JSONObject properties = header.getJSONObject("Properties");
						JSONObject property = properties.getJSONObject("Property");
						String sessionSpecHeaderName = property.getString("name");

						providerPolicyActionVO.setValueKey(operationKey);
						providerPolicyActionVO.setTokenName(name);
						providerPolicyActionVO.setInjectMethod(method);
						providerPolicyActionVO.setInjectHeaderProtocol(protocol);
						providerPolicyActionVO.setInjectHeaderType(type);
						providerPolicyActionVO.setInjectHeaderProperty(sessionSpecHeaderName);
					} else if (!baseObj.isNull("HttpToMqHeaders")) {
						JSONObject httpToMqHeaders = baseObj.getJSONObject("HttpToMqHeaders");
						JSONArray mqHeader = httpToMqHeaders.getJSONArray("header");
						HttpToMqVO httpToMqVo = new HttpToMqVO();
						Map<String, String> mqHeaders = new HashMap<String, String>();
						httpToMqVo.setMqHeaders(mqHeaders);
						for (int headerIndex = 0; headerIndex < mqHeader.length(); headerIndex++) {

							JSONObject headerObj = mqHeader.getJSONObject(headerIndex);
							String name = headerObj.getString("name");
							String value = headerObj.getString("value");
							mqHeaders.put(name, value);
						}
						providerPolicyActionVO.setHttpToMqVO(httpToMqVo);
					}
					if (!baseObj.isNull("logEvents")) {
						LogEventsToMq logEventsToMq = new LogEventsToMq();
						JSONObject logEvents = baseObj.getJSONObject("logEvents");
						JSONObject log = logEvents.getJSONObject("log");
						// JSONObject event = log.getJSONObject("event");
						String eventName = log.getString("event");
						logEventsToMq.setEventName(eventName);
						JSONObject eventHeaders = log.getJSONObject("headers");
						JSONArray eventHeader = eventHeaders.getJSONArray("header");

						Map<String, String> evtHdrs = new HashMap<String, String>();

						for (int headerIndex = 0; headerIndex < eventHeader.length(); headerIndex++) {

							JSONObject headerObj = eventHeader.getJSONObject(headerIndex);
							String name = headerObj.getString("name");
							String value = headerObj.getString("text");
							evtHdrs.put(name, value);
						}
						logEventsToMq.setEventHeaders(evtHdrs);
						if (!log.isNull("responseCodes")) {
							JSONObject respCodes = log.getJSONObject("responseCodes");
							JSONArray respCode = respCodes.getJSONArray("responseCode");
							Map<String, String> evtRespCode = new HashMap<String, String>();
							for (int rspCodeIndex = 0; rspCodeIndex < respCode.length(); rspCodeIndex++) {

								JSONObject headerObj = respCode.getJSONObject(rspCodeIndex);
								String value = headerObj.getString("value");
								evtRespCode.put(value, value);
							}
							logEventsToMq.setEventResponseCodes(evtRespCode);
						}

						providerPolicyActionVO.setLogEventsToMq(logEventsToMq);

					}
					providerPolicyActionFileCache.put(operationKey, providerPolicyActionVO);
				}
			}
		} catch (Exception e) {
			System.out.println("filename = " + fileName);
			e.printStackTrace();
			throw new IOException(e);
		} finally {
			if (cacheStream != null) {
				cacheStream.close();
			}
		}
		return providerPolicyActionFileCache;
	}
    
    public LoggingRouteKeyVO getLoggingPolicy(String operationName) {
		String aitNumber = "logging";
		LoggingRouteKeyVO loggingRouteVO = new LoggingRouteKeyVO();
		if (loggingRoutesCache.get(aitNumber) != null) {
			Map<String, LoggingRouteKeyVO> loggingRouteCache = (Map<String, LoggingRouteKeyVO>) loggingRoutesCache
					.get(aitNumber);
			if (loggingRouteCache.get(operationName) != null) {
				loggingRouteVO = (LoggingRouteKeyVO) loggingRouteCache.get(operationName);
			}
		}
		return loggingRouteVO;
	}
		
}
