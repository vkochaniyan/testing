package com.bac.cache.framework;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.Cache;
import org.ehcache.spi.loaderwriter.CacheWritingException;
import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author ZKZBQ23 AuthorizeJsonObjectBuilder class will get authorize JSON file
 *         from HTTP Server converts that into Java objects and puts key which
 *         is a unique filename and objects which are values into ehCache
 *
 */
public class AuthorizationJsonObjectBuilder {

	private static final Logger logger = LogManager.getLogger();

	private static String SERVICE = "service";
	private static String INDEX_JSON = "index.json";
	private static String INDEX = "index";
	private static String AUTHORIZATION_DOT_JSON = "-authorization.json";

	private String jsonConfigPath = null;
	private CacheSSLConnector cacheSSLConnector = null;

	/**
	 * @param jsonConfigPath
	 * @param cacheSSLConnector
	 */
	public AuthorizationJsonObjectBuilder(String jsonConfigPath, CacheSSLConnector cacheSSLConnector) {
		this.jsonConfigPath = jsonConfigPath;
		this.cacheSSLConnector = cacheSSLConnector;
	}

	/**
	 * @param ehCache
	 * @throws IOException
	 * @throws URISyntaxException
	 */
	public void build(Cache<String, Object> ehCache) throws IOException, URISyntaxException {
		logger.debug("build() start");
		InputStream cacheStream = null;
		ReadWriteLock lock = new ReentrantReadWriteLock();

		try {

			// For reading files from HTTP Server
			String indexFileName = INDEX_JSON;
			String indexJsonFilePath = jsonConfigPath + indexFileName;
			cacheStream = cacheSSLConnector.readUrl(indexJsonFilePath);

			if (cacheStream != null) {
				try {

					JSONObject indexJsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));

					JSONArray indexArray = null;

					if (indexJsonObject != null && indexJsonObject.has(INDEX)) {
						indexArray = indexJsonObject.getJSONArray(INDEX);
					}else{
						logger.error("Misisng Index key in: "+indexFileName);
					}
					if (indexArray != null) {
						for (int counter = 0; counter < indexArray.length(); counter++) {

							String filePathAndName = (String) indexArray.get(counter);

							String fileName = filePathAndName.substring(filePathAndName.lastIndexOf("/") + 1);

							logger.debug("fileName: " + fileName);

							if (fileName.contains(AUTHORIZATION_DOT_JSON)) {

								String jsonFilePath = jsonConfigPath + filePathAndName;
								cacheStream = cacheSSLConnector.readUrl(jsonFilePath);

								JSONObject jsonObject = new JSONObject(
										IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
								logger.debug("jsonObject: " + jsonObject);

								// JSON object to Java
								ObjectMapper mapper = new ObjectMapper();
								Map<String, List> authorizationMap = null;

								List<Map> serviceList = null;
								try {
									authorizationMap = mapper.readValue(jsonObject.toString(), HashMap.class);
									if (authorizationMap.containsKey(SERVICE)) {
										serviceList = authorizationMap.get(SERVICE);
									} else {
										logger.error("Misisng service key for the fileName: "+fileName);
									}

								} catch (JsonGenerationException jsonGenerationEx) {
									jsonGenerationEx.printStackTrace();
									logger.error("Json Generation Exception: " + jsonGenerationEx);
								} catch (JsonMappingException jsonMappingExc) {
									jsonMappingExc.printStackTrace();
									logger.error("JSON Mapping Exception: " + jsonMappingExc);
								} catch (IOException ioExc) {
									ioExc.printStackTrace();
									logger.error("IOException: " + ioExc);
								}

								if (serviceList != null && StringUtils.isNotBlank(fileName)) {
									try {
										lock.writeLock().lock();
										ehCache.put(fileName, serviceList);
										logger.debug(
												"AuthorizeAndGen4HeaderJSONObjectBuilder->  LOADED AUTHORIZEANDGEN4HEADER JSON FILE INTO CACHE ");

									} catch (CacheWritingException cwe) {
										logger.error("  Exception in inserting record key:" + fileName + "value: "
												+ serviceList + "in Cache, retrying ");
										try {
											ehCache.remove(fileName);
											ehCache.put(fileName, serviceList);
										} catch (Exception exc) {
											logger.error("  Exception in inserting record after retrying, key:"
													+ fileName + "value: " + serviceList + "in Cache	");
										}
									} finally {
										lock.writeLock().unlock();
									}

								}
								logger.debug("AuthorizeAndGen4Header JSON ====>  key: " + fileName + ", value:"
										+ ehCache.get(fileName));
							}
						}
					}
				} catch (Exception exc) {
					logger.error(
							"AuthorizeAndGen4HeaderObjectBuilder-> CANNOT LOAD AUTHORIZEANDGEN4HEADER JSON FILE : ERROR -> "
									+ exc.toString());
					exc.printStackTrace();
				}
			}
		} catch (

		Exception exception) {
			logger.debug("ERROR:  " + exception);
			exception.printStackTrace();
			throw new IOException(exception);
		} finally {
			if (cacheStream != null) {
				cacheStream.close();
			}
		}
		logger.debug("build() end");
	}
}