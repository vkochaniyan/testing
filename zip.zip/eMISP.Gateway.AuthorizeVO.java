package com.mulesoft.mule.boa.vo;

public class AuthorizeVO implements java.io.Serializable {

	private static final long serialVersionUID = 6070853244138596164L;
	private String ait;
	private String value;
	private String access;
	private String allowUnfilteredResponse;
	private String providerAIT;
	
	public AuthorizeVO() {

	}

	public String getProviderAIT() {
		return providerAIT;
	}

	public void setProviderAIT(String providerAIT) {
		this.providerAIT = providerAIT;
	}

	public String getAit() {
		return ait;
	}

	public void setAit(String ait) {
		this.ait = ait;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getAccess() {
		return access;
	}

	public void setAccess(String access) {
		this.access = access;
	}

	public String getAllowUnfilteredResponse() {
		return allowUnfilteredResponse;
	}

	public void setAllowUnfilteredResponse(String allowUnfilteredResponse) {
		this.allowUnfilteredResponse = allowUnfilteredResponse;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((access == null) ? 0 : access.hashCode());
		result = prime * result + ((ait == null) ? 0 : ait.hashCode());
		result = prime
				* result
				+ ((allowUnfilteredResponse == null) ? 0
						: allowUnfilteredResponse.hashCode());
		result = prime * result + ((value == null) ? 0 : value.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AuthorizeVO other = (AuthorizeVO) obj;
		if (access == null) {
			if (other.access != null)
				return false;
		} else if (!access.equals(other.access))
			return false;
		if (ait == null) {
			if (other.ait != null)
				return false;
		} else if (!ait.equals(other.ait))
			return false;
		if (allowUnfilteredResponse == null) {
			if (other.allowUnfilteredResponse != null)
				return false;
		} else if (!allowUnfilteredResponse
				.equals(other.allowUnfilteredResponse))
			return false;
		if (value == null) {
			if (other.value != null)
				return false;
		} else if (!value.equals(other.value))
			return false;
		return true;
	}

}
