package com.mulesoft.mule.boa.util;


import java.util.HashMap;

import org.mule.api.MuleEvent;

import org.mule.api.MuleException;
import org.mule.api.MuleMessage;

import org.mule.api.processor.MessageProcessor;

public class InitSideCallEnumerations implements MessageProcessor {
	

	@Override
	public MuleEvent process(MuleEvent event) throws MuleException {
		//MuleMessage mulMsg = event.getMessage();
		HashMap<String, String> sCMap = event.getFlowVariable("cSideCallMap");		
		Boolean IsGen4 = event.getFlowVariable("IsGen4") != null ? Boolean.parseBoolean(event.getFlowVariable("IsGen4").toString()):false;
		Boolean IsGen2Osa = event.getFlowVariable("IsGen2Osa") != null ? Boolean.parseBoolean(event.getFlowVariable("IsGen2Osa").toString()):false;
		Boolean IsReqSOAP = sCMap.get("RequestParams").substring(sCMap.get("RequestParams").indexOf(':')+1,sCMap.get("RequestParams").indexOf(':')+9).equalsIgnoreCase("Envelope") ? true:false;
		Boolean IsRespSOAP = sCMap.get("ResponseParams").substring(sCMap.get("ResponseParams").indexOf(':')+1,sCMap.get("ResponseParams").indexOf(':')+9).equalsIgnoreCase("Envelope") ? true:false;
		//flowVars.cSideCallMap['ContentType'] = 'SOAP_SOAP';['ResponseParams'].substring#[flowVars.cSideCallMap['RequestParams'].substring(flowVars.cSideCallMap['RequestParams'].indexOf(':')+1,flowVars.cSideCallMap['RequestParams'].indexOf(':')+9) == "Envelope"]
		if(IsGen4) sCMap.put("UserID", event.getFlowVariable("Gen4UserId")!=null? event.getFlowVariable("Gen4UserId").toString() : "N/A");
		if(IsGen2Osa) sCMap.put("UserID", event.getFlowVariable("cltUserId")!=null?event.getFlowVariable("Gen4UserId").toString():"N/A");	
		
		if(IsReqSOAP && IsRespSOAP) sCMap.put("ContentType", "SOAP_SOAP");
		if(!IsReqSOAP && IsRespSOAP) sCMap.put("ContentType", "XML_SOAP");
		if(IsReqSOAP && !IsRespSOAP) sCMap.put("ContentType", "SOAP_XML");
		if(!IsReqSOAP && !IsRespSOAP) sCMap.put("ContentType", "XML_XML");
		return event;
	}

}
