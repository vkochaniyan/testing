package com.bac.cache.framework;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.URL;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;

public class RefreshAllCache implements Callable {
	private static final Logger logger = LogManager.getLogger();
	final URL cacheUrl = this.getClass().getClassLoader().getResource("ehcache.xml");
	CacheManagerFactory cacheManagerFactory;

	public CacheManagerFactory getCacheManagerFactory() {
		return cacheManagerFactory;
	}

	public void setCacheManagerFactory(CacheManagerFactory cacheManagerFactory) {
		this.cacheManagerFactory = cacheManagerFactory;
	}

	public String onCall(MuleEventContext eventContext) throws Exception {
		logger.debug("In RefreshAllCache class oncall() method");
		String status = null;
		try {
			List<ICacheManager> allCacheManagers = cacheManagerFactory.refreshCache();
			RefreshCache loadAllCache = new RefreshCache(allCacheManagers);
			CacheInvoker cacheInvoker = new CacheInvoker(loadAllCache);
			cacheInvoker.refresh();
			logger.info("CACHE REFRESH SUCCESS");
			status = "CACHE REFRESHED SUCCESSFULLY";
			logger.info("STATUS: " + status);
			
		} catch (Exception exc) {

			logger.error("ERROR IN REFRESH CACHE");
			exc.printStackTrace();

			StringWriter errors = new StringWriter();
			exc.printStackTrace(new PrintWriter(errors));

			String errorStackTrace = errors.toString();

			status = "CACHE IS NOT REFRESHED, ERROR IN REFRESH CACHE  " + errorStackTrace;

			logger.info("STATUS: " + status);

		}
		return status;
	}
}
