package com.bac.vo;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "header" })
public class HttpToMqHeaders {

	@JsonProperty("header")
	private List<MqHeader> header = new ArrayList<MqHeader>();

	/**
	 * 
	 * @return The header
	 */
	@JsonProperty("header")
	public List<MqHeader> getHeader() {
		return header;
	}

	/**
	 * 
	 * @param header
	 *            The header
	 */
	@JsonProperty("header")
	public void setHeader(List<MqHeader> header) {
		this.header = header;
	}

}