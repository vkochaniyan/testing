package com.bac.component;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Calendar;

import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.processor.MessageProcessor;

public class HashWssePassword implements MessageProcessor {

	/* (non-Javadoc)
	 * @see org.mule.api.processor.MessageProcessor#process(org.mule.api.MuleEvent)
	 */
	@Override
	public MuleEvent process(MuleEvent event) throws MuleException {
		try {
			// initialize
			String wsseCreated = "";
			String nonceEncoded = "";
			String wssePasswordEncoded = "";
			
			String wssePwType = event.getFlowVariable("wssePwType");
			
			if (wssePwType != null && wssePwType.equals("Digest")) {
			
			    // 2014-06-21T12:43:21.791Z
			    wsseCreated = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'").format(Calendar.getInstance().getTime());
			    String nonce = java.util.UUID.randomUUID().toString().substring(0, 15);
			    nonceEncoded = new sun.misc.BASE64Encoder().encode(nonce.getBytes());
			
			    String password = event.getFlowVariable("wssePasswordDecoded");
				
			    String password3 = nonce + wsseCreated + password;
			    MessageDigest digest = MessageDigest.getInstance("SHA-256");
			
			    byte[] wssePassword = digest.digest(password3.getBytes(StandardCharsets.UTF_8));
		      	wssePasswordEncoded = new sun.misc.BASE64Encoder().encode(wssePassword);
			
			} else if (wssePwType == null){
				event.setFlowVariable("wssePwType", "");
			}
			event.setFlowVariable("wsseCreated", wsseCreated);
		    event.setFlowVariable("nonceEncoded", nonceEncoded);
		    event.setFlowVariable("wssePasswordEncoded", wssePasswordEncoded);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return event;

	}

}