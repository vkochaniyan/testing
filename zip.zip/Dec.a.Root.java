package com.a;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name="root")
public class Root {
	@XmlElement(name="itm")
	private Item item;

	public Item getItem() {
		return item;
	}

	public void setItem(Item i) {
		this.item = i;
	}
}
