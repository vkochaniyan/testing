package com.a;

public class Svc {
	public static Root doSomething(Root r) {
		Item i = r.getItem();
		i.setId("123");
		return r;
	}
}
