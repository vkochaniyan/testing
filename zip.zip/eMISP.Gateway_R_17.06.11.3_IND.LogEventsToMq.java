package com.mulesoft.mule.boa.vo;

import java.util.Map;

public class LogEventsToMq implements java.io.Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	

	private Map<String, String> eventHeaders;
	private Map<String, String> eventResponseCodes;
	private String eventName;

	public LogEventsToMq() {

	}

	

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}



	public Map<String, String> getEventHeaders() {
		return eventHeaders;
	}



	public void setEventHeaders(Map<String, String> eventHeaders) {
		this.eventHeaders = eventHeaders;
	}



	public Map<String, String> getEventResponseCodes() {
		return eventResponseCodes;
	}



	public void setEventResponseCodes(Map<String, String> eventResponseCode) {
		this.eventResponseCodes = eventResponseCode;
	}


	
}
