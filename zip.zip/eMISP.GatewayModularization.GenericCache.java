/**
 * 
 */
package com.bac.cache.framework;

import javax.xml.validation.Schema;
import org.ehcache.Cache;
import org.ehcache.CacheManager;

/**
 * @author ZKWQBHO
 *
 */
public class GenericCache implements ICacheManager {
	
	private Cache<String,Schema> sCache;
	private CacheManager ehCacheMgr;
	
	public GenericCache(CacheManager ehCacheManager) {
		ehCacheMgr = ehCacheManager;
	}
	
	public Cache<String, Schema> getCache() {
		return sCache;
	}
	
	public void setCache(Cache<String,Schema> schemaCache){
		this.sCache = schemaCache;
	}

	/* (non-Javadoc)
	 * @see com.bac.cache.framework.CacheManager#loadCache()
	 */
	@Override
	public void loadCache() {
		// TODO Auto-generated method stub

	}

	/* (non-Javadoc)
	 * @see com.bac.cache.framework.CacheManager#refreshCache()
	 */
	@Override
	public void refreshCache() {
		// TODO Auto-generated method stub

	}

}
