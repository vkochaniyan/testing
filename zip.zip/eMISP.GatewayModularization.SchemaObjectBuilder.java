package com.bac.cache.framework;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import javax.xml.XMLConstants;
import javax.xml.transform.Source;
import javax.xml.transform.stream.StreamSource;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;
import org.apache.commons.io.IOUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.Cache;
import org.ehcache.spi.loaderwriter.CacheWritingException;
import org.json.JSONArray;
import org.json.JSONObject;


public class SchemaObjectBuilder{

	private static String SCHEMA_HTTP_PATH = "schemaHttpPath";
	private static String SERVICE_RESOURCES = "ServiceResources";
	private static String SERVICE_URI = "serviceUri";
	private String schemaPath =null;
	private String schemaIndexPath =null;
	private CacheSSLConnector cacheSSLConnector =null;
	private static final Logger logger = LogManager.getLogger();
	
	public SchemaObjectBuilder(String schemaPath, String schemaConfigPath, CacheSSLConnector cacheSSLConnector) {
		this.schemaPath =schemaPath;
		this.schemaIndexPath = schemaConfigPath;
		this.cacheSSLConnector = cacheSSLConnector;
	}

	public void build(Cache<String,Schema> ehCache) throws IOException, URISyntaxException{
		InputStream cacheStream = null;
		ReadWriteLock lock = new ReentrantReadWriteLock();
		
		try{
				
			    cacheStream = cacheSSLConnector.readUrl(schemaIndexPath);
			 
				if(cacheStream!=null){
					JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
					
					JSONArray serviceArray = null;
					if(jsonObject.has(SERVICE_RESOURCES)){
					serviceArray = jsonObject.getJSONArray(SERVICE_RESOURCES);
					}
					else{
						logger.error("Missing ServiceResources key on HTTP server on : "+schemaIndexPath);
					}
					for(int counter=0;counter<serviceArray.length();counter++){
						try {
							JSONObject baseObj = serviceArray.getJSONObject(counter);
							String serviceName = null;
							if(baseObj.has(SERVICE_URI)){
							serviceName = baseObj.getString(SERVICE_URI);
							logger.debug("SERVICE URL ====> "+ serviceName);
						}
						else{
							logger.error("Missing ServiceResources key on: "+schemaIndexPath);
						}
							
							JSONArray schemaHttpPathArray = null;
							if(baseObj.has(SCHEMA_HTTP_PATH)){
							schemaHttpPathArray = baseObj.getJSONArray(SCHEMA_HTTP_PATH);
							}
							
							Schema schema = null;
							if(schemaHttpPathArray != null){
							schema = loadSchemas(schemaHttpPathArray,baseObj);
							}
							//store the values in cache
							if(schema!=null){
								logger.debug("  SchemaObjectBuilder->	SCHEMA IS NOT NULL	");
								
								try {
									lock.writeLock().lock();
									ehCache.put(serviceName, schema);
								} catch (CacheWritingException e) {
									logger.error("  Exception in inserting same record in Cache, Doing the Refresh recrod in Cache!	");
									try {
										ehCache.remove(serviceName);
										ehCache.put(serviceName, schema);
									} catch (CacheWritingException e1) {
										logger.error("Error in refreshing Cache for following service "+ serviceName);
									}
									finally {
										lock.writeLock().unlock();
									}
								}
							}
						} catch (Exception e) {
							logger.error("SchemaObjectBuilder-> - CANNOT LOAD SCHEMA FILE : ERROR -> " + e.toString());
							e.printStackTrace();
						}
					}
					
				}	
			}		
			catch(Exception e){
				logger.debug("ERROR  "+ e);
				e.printStackTrace();
				throw new IOException(e);
			}
			finally{
				if(cacheStream!=null){
					cacheStream.close();
				}
			}	
		logger.debug("SchemaObjectBuilder-> - SCHEMA FILES LOADED IN CACHE -> " + ehCache.toString());

	}


	public Schema loadSchemas(JSONArray schemaHttpPathArray,JSONObject baseObj) throws Exception {
		SchemaFactory factory = SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		
		Source[] sources = new Source[schemaHttpPathArray.length()];
		for (int count = 0; count < schemaHttpPathArray.length(); count++) {
			String schemaHttpPath = schemaHttpPathArray.getString(count);
			logger.debug("schemaHttpPath: "+schemaHttpPath);
			String schemaFullPath = schemaPath + schemaHttpPath;
			logger.debug("Loading XSD FILE ====> " + schemaFullPath);
			
			URL schemaURL = new URL(schemaFullPath);
			InputStream inputStream = cacheSSLConnector.readUrl(schemaFullPath);
			StreamSource srt = new StreamSource(inputStream);
			srt.setSystemId(schemaURL.toString());
			sources[count] = srt;
		}

		return factory.newSchema(sources);
	}

}