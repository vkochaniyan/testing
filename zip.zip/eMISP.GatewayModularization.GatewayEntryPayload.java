package com.bac.audit;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.mule.DefaultMuleMessage;
import org.mule.api.MuleMessage;
import org.mule.api.context.MuleContextAware;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class GatewayEntryPayload extends AbstractMessageTransformer implements MuleContextAware{

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException{
		DefaultMuleMessage muleMessage = null;
		StringBuffer buffer = new StringBuffer();
		
		String ClientIP = (String)message.getInvocationProperty("ClientIP");
		if(ClientIP.contains("/")){
			ClientIP = ClientIP.replace("/", "").trim();
		}
		if(ClientIP.contains(":")){
			ClientIP = ClientIP.substring(0,ClientIP.indexOf(":"));
		}
		
		String clientName = "";
		try {
			InetAddress inetAddress = InetAddress.getByName(ClientIP);
			clientName = inetAddress.getHostName();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		
		buffer.append(message.getInvocationProperty("startTime").toString().trim()+"|");
		buffer.append("STEP2a|");
		buffer.append("Gateway Round Trip Time|");
		buffer.append(message.getInvocationProperty("traceId")+"|");
		buffer.append(message.getInvocationProperty("userName")+"|");
		buffer.append(clientName+"|");
		buffer.append(message.getInvocationProperty("hostName")+"|");
		buffer.append("WS|");
		buffer.append(message.getInvocationProperty("serviceName")+"|");
		buffer.append(message.getInvocationProperty("operationName")+"|");
		buffer.append((message.getInvocationProperty("ResponseStatus")!=null?message.getInvocationProperty("ResponseStatus"):"")+"|");
		buffer.append((message.getInvocationProperty("ResponseFaultCode")!=null?message.getInvocationProperty("ResponseFaultCode"):"")+"|");
		buffer.append((message.getInvocationProperty("ResponseFaultErrorMsg")!=null?message.getInvocationProperty("ResponseFaultErrorMsg"):"")+"|");
		buffer.append(message.getInvocationProperty("responseTime")+"|");
		buffer.append((message.getInvocationProperty("request-content-length")!=null?message.getInvocationProperty("request-content-length"):"")+"|");
		buffer.append((message.getInvocationProperty("response-content-length")!=null?message.getInvocationProperty("response-content-length"):"")+"|");
		buffer.append(message.getInvocationProperty("endTime").toString().trim()+"|");
		buffer.append((message.getInvocationProperty("ait")!=null?message.getInvocationProperty("ait"):"")+"|");
		buffer.append(ClientIP+"|");
		buffer.append(message.getInvocationProperty("appName")+"|");
		buffer.append(message.getInvocationProperty("EntityURI").toString());
		buffer.append(message.getInvocationProperty("httpRelativePath")+"|");
		buffer.append("CS&OT|");
		buffer.append((message.getInvocationProperty("cbrAttribSet")!=null?message.getInvocationProperty("cbrAttribSet"):"")+"|");
		buffer.append((message.getInvocationProperty("orgTargetNamespace")!=null?message.getInvocationProperty("orgTargetNamespace"):"")+"|");
		buffer.append("|");
		
		muleMessage = new DefaultMuleMessage(null, muleContext);
		muleMessage.setPayload(buffer);
		return muleMessage;
		}
	
}
