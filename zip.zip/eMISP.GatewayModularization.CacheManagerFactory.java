/**
 * 
 */
package com.bac.cache.framework;

import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.CacheManager;
import org.ehcache.config.builders.CacheManagerBuilder;
import org.ehcache.xml.XmlConfiguration;

/**
 * @author ZKWQBHO
 *
 */
public class CacheManagerFactory {
	
	private static final Logger logger = LogManager.getLogger();
	private SchemaCacheManager schemaCacheManager;
	private WsdlCacheManager wsdlCacheManager;	
	private ConfigCacheManager configCacheManager;

	/**
	 * @return the jsonCacheManager
	 */
	public ConfigCacheManager getConfigCacheManager() {
		return configCacheManager;
	}

	/**
	 * @param jsonCacheManager the jsonCacheManager to set
	 */
	public void setConfigCacheManager(ConfigCacheManager jsonCacheManager) {
		this.configCacheManager = jsonCacheManager;
	}

	/**
	 * @return schemaCacheManager SchemaCacheManager
	 */
	public SchemaCacheManager getSchemaCacheManager() {
		return schemaCacheManager;
	}

	/**
	 * @param schemaCacheManager SchemaCacheManager
	 */
	public void setSchemaCacheManager(SchemaCacheManager schemaCacheManager) {
		this.schemaCacheManager = schemaCacheManager;
	}
	
	/**
	 * @return wsdlCacheManager WsdlCacheManager
	 */
	public WsdlCacheManager getWsdlCacheManager() {
		return wsdlCacheManager;
	}

	/**
	 * @param wsdlCacheManager WsdlCacheManager
	 */
	public void setWsdlCacheManager(WsdlCacheManager wsdlCacheManager) {
		this.wsdlCacheManager = wsdlCacheManager;
	}

	// This will be called at Startup
	public List<ICacheManager> findAll(URL cacheUrl) {
		// Initialize
		CacheManager ehCacheManager = initialize(cacheUrl);
		List<ICacheManager> allCacheMgr = new ArrayList<ICacheManager>();
		schemaCacheManager.setEhCacheMgr(ehCacheManager);
		wsdlCacheManager.setEhCacheMgr(ehCacheManager);
		configCacheManager.setEhCacheMgr(ehCacheManager);
		allCacheMgr.add(schemaCacheManager);
		allCacheMgr.add(wsdlCacheManager);
		allCacheMgr.add(configCacheManager);
		return allCacheMgr;
	}

	private static CacheManager initialize(URL cacheUrl) {
		XmlConfiguration cacheConfig = new XmlConfiguration(cacheUrl);
		CacheManager ehCacheManager = CacheManagerBuilder.newCacheManager(cacheConfig);
		ehCacheManager.init();
		return ehCacheManager;
	}

	public List<ICacheManager> refreshCache() {
		logger.debug("In CacheManagerFactory refreshCache() ");
		List<ICacheManager> allCacheMgr = new ArrayList<ICacheManager>();
		allCacheMgr.add(getSchemaCacheManager());
		allCacheMgr.add(getWsdlCacheManager());
		allCacheMgr.add(getConfigCacheManager());
		return allCacheMgr;
	}

}
