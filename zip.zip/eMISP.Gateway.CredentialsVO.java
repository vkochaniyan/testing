package com.mulesoft.mule.boa.vo;

public class CredentialsVO {
	
	private String credentialsType;
	private String credentialsUser;
	private String credentialsPassword;
	
	public CredentialsVO(){
		
	}

	public String getCredentialsType() {
		return credentialsType;
	}

	public void setCredentialsType(String credentialsType) {
		this.credentialsType = credentialsType;
	}

	public String getCredentialsUser() {
		return credentialsUser;
	}

	public void setCredentialsUser(String credentialsUser) {
		this.credentialsUser = credentialsUser;
	}

	public String getCredentialsPassword() {
		return credentialsPassword;
	}

	public void setCredentialsPassword(String credentialsPassword) {
		this.credentialsPassword = credentialsPassword;
	}
	
	
}
