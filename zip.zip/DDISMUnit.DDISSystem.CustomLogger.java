package com.bac.hli.ddis;

import org.mule.api.MuleEventContext;
import org.mule.api.lifecycle.Callable;
import org.apache.log4j.Logger;
import org.mule.api.MuleMessage;

public class CustomLogger implements Callable {

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {

		Logger logger = Logger.getLogger(CustomLogger.class);
		MuleMessage m = eventContext.getMessage();
		logger.info(m.getInvocationProperty("rawRequest"));

		return m;
	}

}
