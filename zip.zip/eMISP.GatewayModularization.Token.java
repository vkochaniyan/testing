package com.bac.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "tokenName", "header" })
public class Token {

	@JsonProperty("tokenName")
	private String tokenName;
	@JsonProperty("header")
	private Header header;

	/**
	 * 
	 * @return The tokenName
	 */
	@JsonProperty("tokenName")
	public String getTokenName() {
		return tokenName;
	}

	/**
	 * 
	 * @param tokenName
	 *            The tokenName
	 */
	@JsonProperty("tokenName")
	public void setTokenName(String tokenName) {
		this.tokenName = tokenName;
	}

	/**
	 * 
	 * @return The header
	 */
	@JsonProperty("header")
	public Header getHeader() {
		return header;
	}

	/**
	 * 
	 * @param header
	 *            The header
	 */
	@JsonProperty("header")
	public void setHeader(Header header) {
		this.header = header;
	}

}
