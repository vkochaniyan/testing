package com.bac.cache.framework;

import java.io.InputStream;
import java.net.URL;
import java.security.KeyStore;

import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;

public class CacheSSLConnector {

	private String keyStore;
	private String trustStore;
	private String keyStorePassword;
	private String trustStorePassword;

	public CacheSSLConnector(String keyStore, String trustStore, String keyStorePassword, String trustStorePassword) {
		this.keyStore = keyStore;
		this.trustStore = trustStore;
		this.keyStorePassword = keyStorePassword;
		this.trustStorePassword = trustStorePassword;
	}

	public String getKeyStore() {
		return keyStore;
	}

	public void setKeyStore(String keyStore) {
		this.keyStore = keyStore;
	}

	public String getTrustStore() {
		return trustStore;
	}

	public void setTrustStore(String trustStore) {
		this.trustStore = trustStore;
	}

	public String getKeyStorePassword() {
		return keyStorePassword;
	}

	public void setKeyStorePassword(String keyStorePassword) {
		this.keyStorePassword = keyStorePassword;
	}

	public String getTrustStorePassword() {
		return trustStorePassword;
	}

	public void setTrustStorePassword(String trustStorePassword) {
		this.trustStorePassword = trustStorePassword;
	}

	public InputStream readUrl(String url) throws Exception {
		InputStream cacheStream = null;

		System.setProperty("javax.net.ssl.keyStoreType", "jks");
		System.setProperty("javax.net.ssl.trustStoreType", "jks");
		System.setProperty("javax.net.ssl.keyStore", keyStore);
		System.setProperty("javax.net.ssl.trustStore", trustStore);
		System.setProperty("javax.net.debug", "ssl");
		System.setProperty("javax.net.ssl.keyStorePassword", keyStorePassword);
		System.setProperty("javax.net.ssl.trustStorePassword", trustStorePassword);

		char[] keyPassArray = keyStorePassword.toCharArray();
		char[] trustPassArray = trustStorePassword.toCharArray();

		KeyStore keyStore = KeyStore.getInstance("JKS");
		KeyStore trustStore = KeyStore.getInstance("JKS");

		InputStream fis1 = Thread.currentThread().getContextClassLoader().getResourceAsStream(this.keyStore);
		keyStore.load(fis1, keyPassArray);
		InputStream fis2 = Thread.currentThread().getContextClassLoader().getResourceAsStream(this.trustStore);
		trustStore.load(fis2, trustPassArray);
		TrustManagerFactory trustManagerFactory = TrustManagerFactory
				.getInstance(TrustManagerFactory.getDefaultAlgorithm());

		KeyManagerFactory keyManagerFactory = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
		URL schemaURL = new URL(url);

		trustManagerFactory.init(trustStore);
		keyManagerFactory.init(keyStore, keyPassArray);

		SSLContext sslContext = SSLContext.getInstance("SSLv3");
		sslContext.init(keyManagerFactory.getKeyManagers(), trustManagerFactory.getTrustManagers(), null);
		SSLSocketFactory sslsocketfactory = sslContext.getSocketFactory();
		HttpsURLConnection conn = (HttpsURLConnection) schemaURL.openConnection();
		conn.setSSLSocketFactory(sslsocketfactory);
		cacheStream = conn.getInputStream();
		
		fis1.close();
	    fis2.close();

		return cacheStream;

	}

}
