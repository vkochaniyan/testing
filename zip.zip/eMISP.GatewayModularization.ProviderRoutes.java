package com.bac.vo;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "providerRouteCollection" })
public class ProviderRoutes {

	@JsonProperty("providerRouteCollection")
	private List<ProviderRouteCollection> providerRouteCollection = new ArrayList<ProviderRouteCollection>();

	/**
	 * 
	 * @return The providerRouteCollection
	 */
	@JsonProperty("providerRouteCollection")
	public List<ProviderRouteCollection> getProviderRouteCollection() {
		return providerRouteCollection;
	}

	/**
	 * 
	 * @param providerRouteCollection
	 *            The providerRouteCollection
	 */
	@JsonProperty("providerRouteCollection")
	public void setProviderRouteCollection(List<ProviderRouteCollection> providerRouteCollection) {
		this.providerRouteCollection = providerRouteCollection;
	}

}
