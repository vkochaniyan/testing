/**
 * 
 */
package com.bac.cache.framework;

import java.util.List;

/**
 * @author ZKWQBHO
 *
 */
public class LoadAllCache implements ICommand {

	List<ICacheManager> cacheManagers;
	
	public LoadAllCache(List<ICacheManager> newCacheManagers){
		cacheManagers = newCacheManagers;
	}
	/* (non-Javadoc)
	 * @see com.bac.cache.framework.Command#execute()
	 */
	@Override
	public void execute() throws Exception {

		for(ICacheManager cacheMgr : cacheManagers){
			cacheMgr.loadCache();
		}

	}


}
