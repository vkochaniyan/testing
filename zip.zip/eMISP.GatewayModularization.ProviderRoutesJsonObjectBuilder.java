package com.bac.cache.framework;

import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.Cache;
import org.ehcache.spi.loaderwriter.CacheWritingException;
import org.json.JSONArray;
import org.json.JSONObject;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author ZKZBQ23 ProviderRoutesJsonObjectBuilder class will get provider
 *         routes JSON file from HTTP Server converts into Java objects and puts
 *         key which is a unique filename and objects which are values into
 *         ehCache
 *
 */
public class ProviderRoutesJsonObjectBuilder {

	private static final Logger logger = LogManager.getLogger();

	private static String PROVIDER_ROUTE_COLLECTION = "providerRouteCollection";
	private static String INDEX_JSON = "index.json";
	private static String INDEX = "index";
	private static String PROVIDER_ROUTES_JSON = "provider-routes.json";

	private String jsonConfigPath = null;
	private CacheSSLConnector cacheSSLConnector = null;

	/**
	 * @param jsonConfigPath
	 *            String
	 */
	public ProviderRoutesJsonObjectBuilder(String jsonConfigPath, CacheSSLConnector cacheSSLConnector) {
		this.jsonConfigPath = jsonConfigPath;
		this.cacheSSLConnector = cacheSSLConnector;
	}

	/**
	 * @param ehCache
	 * @throws IOException
	 * @throws URISyntaxException
	 */
	public void build(Cache<String, Object> ehCache) throws IOException, URISyntaxException {
		logger.debug("build() start");
		InputStream cacheStream = null;
		ReadWriteLock lock = new ReentrantReadWriteLock();

		try {

			// For reading files from HTTP Server
			String indexFileName = INDEX_JSON;
			String indexJsonFilePath = jsonConfigPath + indexFileName;
			cacheStream = cacheSSLConnector.readUrl(indexJsonFilePath);

			if (cacheStream != null) {
				try {

					JSONObject indexJsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));

					JSONArray indexArray = null;

					if (indexJsonObject != null && indexJsonObject.has(INDEX)) {
						indexArray = indexJsonObject.getJSONArray(INDEX);
					}else{
						logger.error("Misisng Index key in: "+indexFileName);
					}
					if (indexArray != null) {
						for (int counter = 0; counter < indexArray.length(); counter++) {

							String filePathAndName = (String) indexArray.get(counter);

							String fileName = filePathAndName.substring(filePathAndName.lastIndexOf("/") + 1);

							logger.debug("fileName: " + fileName);

							if (fileName.contains(PROVIDER_ROUTES_JSON)) {

								String jsonFilePath = jsonConfigPath + filePathAndName;
								cacheStream = cacheSSLConnector.readUrl(jsonFilePath);

								JSONObject jsonObject = new JSONObject(
										IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
								logger.debug("jsonObject: " + jsonObject);

								// JSON object to Java
								ObjectMapper mapper = new ObjectMapper();
								Map<String, List> providerRoutesMap = null;

								List<Map> providerRouteCollection = null;
								try {
									providerRoutesMap = mapper.readValue(jsonObject.toString(), HashMap.class);
									if (providerRoutesMap.containsKey(PROVIDER_ROUTE_COLLECTION)) {
										providerRouteCollection = providerRoutesMap.get(PROVIDER_ROUTE_COLLECTION);
									} else {
										logger.error(
												"Misisng providerRouteCollection key on HTTP server for the fileName: "
														+ fileName);
									}

								} catch (JsonGenerationException jsonGenerationEx) {
									jsonGenerationEx.printStackTrace();
									logger.error("Json Generation Exception: " + jsonGenerationEx);
								} catch (JsonMappingException jsonMappingExc) {
									jsonMappingExc.printStackTrace();
									logger.error("JSON Mapping Exception: " + jsonMappingExc);
								} catch (IOException ioExc) {
									ioExc.printStackTrace();
									logger.error("IOException: " + ioExc);
								}

								if (providerRouteCollection != null && StringUtils.isNotBlank(fileName)) {
									try {
										lock.writeLock().lock();
										ehCache.put(fileName, providerRouteCollection);
										logger.debug(
												"Provider Routes ObjectBuilder->  LOADED PROVIDER ROUTES JSON FILE INTO CACHE ");

									} catch (CacheWritingException cwe) {
										logger.error("  Exception in inserting record key:" + fileName + "value: "
												+ providerRouteCollection + "in Cache, retrying ");
										try {
											ehCache.remove(fileName);
											ehCache.put(fileName, providerRouteCollection);
										} catch (Exception exc) {
											logger.error("  Exception in inserting record after retrying, key:"
													+ fileName + "value: " + providerRouteCollection + "in Cache	");
										}
									} finally {
										lock.writeLock().unlock();
									}

								}
								logger.debug("PROVIDER ROUTES JSON ====>  key: " + fileName + ", value:"
										+ ehCache.get(fileName));
							}
						}
					}
				} catch (Exception exc) {
					logger.error("PRovider Routes ObjectBuilder-> CANNOT LOAD PROVIDER ROUTES JSON FILE : ERROR -> "
							+ exc.toString());
					exc.printStackTrace();
				}
			}
		} catch (

		Exception exception) {
			logger.debug("ERROR:  " + exception);
			exception.printStackTrace();
			throw new IOException(exception);
		} finally {
			if (cacheStream != null) {
				cacheStream.close();
			}
		}
		logger.debug("build() end");
	}
}