package com.mulesoft.mule.boa;

import java.util.HashMap;
import java.util.LinkedHashMap;

import org.mule.api.MuleMessage;
import org.mule.api.routing.filter.Filter;

public class ValidateAuthorizationAccess implements Filter {

	@Override
	public boolean accept(MuleMessage message) {		
		HashMap<String, String> cmap = message.getInvocationProperty("cMap");
		Object o = message.getPayload();
		
		if(o instanceof LinkedHashMap){
			@SuppressWarnings("unchecked")
			LinkedHashMap<String,Object> map = (LinkedHashMap<String, Object>)o;
			if(map.containsKey("result")){
				Object value = map.get("result");				
				@SuppressWarnings("unchecked")
				LinkedHashMap<String,Object> innerMap = (LinkedHashMap<String, Object>)value;
				if(innerMap.containsKey("Access")){
					Object inValue = innerMap.get("Access");
					if(inValue.toString().toLowerCase().equals("rejected")){
						cmap.put("ErrMsg", "Request not authorized to access the resource");
						throw new NullPointerException("Request not authorized to access the resource");
					}
				}
			}
		}
		
		return true;
	}

}