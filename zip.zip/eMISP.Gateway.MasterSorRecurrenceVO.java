package com.mulesoft.mule.boa.vo;

import java.util.List;



public class MasterSorRecurrenceVO implements java.io.Serializable {

	
	private static final long serialVersionUID = -1969420662759259777L;
	
	private String recurrenceName;
	private String defaultSor;
	private List<SorRecurrenceVO> recurrenceList;
	
	public MasterSorRecurrenceVO() {
	}
	
	public MasterSorRecurrenceVO(String svcOpValue, String defaultSor, List<SorRecurrenceVO> recurrenceList) {
		this.recurrenceName = svcOpValue;
		this.defaultSor = defaultSor;
		this.recurrenceList = recurrenceList;
	}

	public String getRecurrenceName() {
		return recurrenceName;
	}

	public void setRecurrenceName(String recurrenceName) {
		this.recurrenceName = recurrenceName;
	}

	public String getDefaultSor() {
		return defaultSor;
	}

	public void setDefaultSor(String defaultSor) {
		this.defaultSor = defaultSor;
	}

	public List<SorRecurrenceVO> getRecurrenceList() {
		return recurrenceList;
	}

	public void setRecurrenceList(List<SorRecurrenceVO> recurrenceList) {
		this.recurrenceList = recurrenceList;
	}
	
	
}
