package com.mulesoft.mule.boa;
import java.io.IOException;
import java.io.StringReader;
import java.util.Base64;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.xml.sax.InputSource;
import com.mulesoft.mule.boa.exceptions.GatewayValidationException;
import com.pingidentity.sts.clientapi.STSClient;
import com.pingidentity.sts.clientapi.STSClientConfiguration;
import com.pingidentity.sts.clientapi.model.RequestSecurityTokenData;
import com.pingidentity.sts.clientapi.model.STSResponse;
import com.pingidentity.sts.clientapi.tokens.saml.Saml20Token;
import com.pingidentity.sts.clientapi.tokens.saml.SamlAttribute;
import com.pingidentity.sts.clientapi.tokens.saml.SamlToken;
import com.pingidentity.sts.clientapi.utils.StringUtils;


public class SAML2Validator implements Callable {

	StringUtils utils = new StringUtils();	

	private static Element convertStringToDocument(String xmlStr) throws GatewayValidationException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		factory.setNamespaceAware(true);
		DocumentBuilder builder;
		try {
			builder = factory.newDocumentBuilder();
			Document doc = builder.parse(new InputSource(new StringReader(xmlStr)));
			return doc.getDocumentElement();
		} catch (Exception e) {
			e.printStackTrace();
			throw new GatewayValidationException("SAML Assertion String to DOM Failed~" + e.getMessage());
		}
	}

	private static STSClientConfiguration getConfig(String pingendpoint) {

		STSClientConfiguration stsWSP = new STSClientConfiguration();       
		stsWSP.setStsEndpoint(pingendpoint);		
		stsWSP.setIgnoreSSLTrustErrors(true);
		return stsWSP;
	}
	MuleMessage mulmsg = null;
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		
		Boolean valid = Boolean.FALSE;
		String errorMsg = "";
		mulmsg = eventContext.getMessage();
		String pingEndpoint = mulmsg.getInvocationProperty("PingSTSEndPointURL");
		String b64Token = mulmsg.getInboundProperty("EIB_Credential");
		String IsSamlToken = mulmsg.getInvocationProperty("IsSamlToken")!=null?mulmsg.getInvocationProperty("IsSamlToken").toString():"false";
		String IsInlineSamlAssertion = mulmsg.getInvocationProperty("IsInlineSamlAssertion")!=null?mulmsg.getInvocationProperty("IsInlineSamlAssertion").toString():"false";
		String bdecodedToken = null;
		String payload = null;
		if(b64Token !=null && b64Token.trim() != "" ){
			byte[] asBytes = Base64.getDecoder().decode(b64Token);
			bdecodedToken = new String(asBytes, "utf-8" );
		}
		
		try {
			Element token = null;
			if(IsSamlToken.equalsIgnoreCase("true")){
			 token = convertStringToDocument(bdecodedToken);
			}
			if(IsInlineSamlAssertion.equalsIgnoreCase("true")){	
				 payload = mulmsg.getPayloadAsString();
				 token = (Element) convertStringToDocument(payload).getElementsByTagNameNS("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd", "Security").item(0).getFirstChild();				 
			}
			System.out.println(utils.prettyPrint(token));
			SamlToken samltoken = new Saml20Token(token);
			// 1- way : Create validate request
			STSClientConfiguration stsValidateConfig = getConfig(pingEndpoint);
			STSClient provider = new STSClient(stsValidateConfig);
			RequestSecurityTokenData data = provider.createValidateData();
			data.setTokenType(samltoken.getTokenType());			
			STSResponse stsResponse;
			try {
				System.out.println(utils.prettyPrint(samltoken.getRoot()));
				stsResponse = provider.makeRequest(data, samltoken.getRoot(), null, samltoken.getTokenType(), false);
				if (null != stsResponse.getRstr()) {
					valid = stsResponse.getRstr().isValidateStatusOk();
					if(valid){
						SamlAttribute attrib =  (SamlAttribute) samltoken.getAttributes().get(0);
						String sAIT = attrib.getValue();
						if(sAIT.equalsIgnoreCase("000000"))
							sAIT = "69820";			            
			            System.out.println(attrib.getValue());			            
			            mulmsg.setInvocationProperty("AIT_FRM_SAML_TKN", sAIT);
					}
					System.out.println(utils.prettyPrint(stsResponse.getRstr().getRstrElement()));
				}
				if (null != stsResponse.getSoapFault()){
					errorMsg = stsResponse.getSoapFault().getFaultCode() + "~"
							+ stsResponse.getSoapFault().getFaultString();
					throw new GatewayValidationException(errorMsg);
					
				}
			} catch (IOException e) {
				e.printStackTrace();
				throw new GatewayValidationException("STSClientException~" + e.getMessage());
				
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			try {
				throw new GatewayValidationException("Exception~" + e.getMessage());
			} catch (GatewayValidationException e1) {
				
				e1.printStackTrace();
			}
		}
		System.out.println(valid);
		System.out.println(errorMsg);
		 mulmsg.setInvocationProperty("IS_SAML_VALID", valid.toString().toLowerCase());
		 System.out.println(mulmsg.getPayloadAsString());
		 
		 return mulmsg.getPayloadAsString();
	}
}
