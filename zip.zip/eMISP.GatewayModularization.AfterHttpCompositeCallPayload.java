package com.bac.audit;

import java.net.InetAddress;
import java.net.UnknownHostException;

import org.mule.DefaultMuleMessage;
import org.mule.api.MuleMessage;
import org.mule.api.context.MuleContextAware;
import org.mule.api.transformer.TransformerException;
import org.mule.transformer.AbstractMessageTransformer;

public class AfterHttpCompositeCallPayload  extends AbstractMessageTransformer implements MuleContextAware{

	@Override
	public Object transformMessage(MuleMessage message, String outputEncoding) throws TransformerException {
		DefaultMuleMessage muleMessage = null;
		StringBuffer buffer = new StringBuffer();
		
		String ClientIP = (String)message.getInvocationProperty("ClientIP");
		if(ClientIP.contains("/")){
			ClientIP = ClientIP.replace("/", "").trim();
		}
		if(ClientIP.contains(":")){
			ClientIP = ClientIP.substring(0,ClientIP.indexOf(":"));
		}
		
		String clientName = "";
		try {
			InetAddress inetAddress = InetAddress.getByName(ClientIP);
			clientName = inetAddress.getHostName();
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}
		
		buffer.append(message.getInvocationProperty("startTime").toString().trim()+"|");
		buffer.append("STEP5b|");
		buffer.append("Composite to Gateway Round Trip|");
		buffer.append(message.getInvocationProperty("traceId")+"|");
		buffer.append(message.getInvocationProperty("userName")+"|");
		buffer.append(clientName+"|");
		buffer.append(message.getInvocationProperty("hostName")+"|");
		buffer.append("WS|");
		String cltServiceName = message.getInvocationProperty("serviceName");
		String ServiceNameLogger = cltServiceName;
		if(cltServiceName!=null&&cltServiceName.contains("http")){
			ServiceNameLogger = cltServiceName.substring(cltServiceName.lastIndexOf('/')+1, cltServiceName.length());
		}
		buffer.append(ServiceNameLogger+"|");
		buffer.append(message.getInvocationProperty("operationName")+"|");
		String errMsg = (message.getInvocationProperty("ErrMsg"));
		buffer.append(((errMsg==null||errMsg.equals(""))?"Success":"Failure")+"|");
		buffer.append(((errMsg==null||errMsg.equals(""))?"200":"500")+"|");	
		buffer.append(((errMsg==null||errMsg.equals(""))?"":errMsg)+"|");
		buffer.append(message.getInvocationProperty("responseTime")+"|");
		buffer.append((message.getInvocationProperty("request-content-length")!=null?message.getInvocationProperty("request-content-length"):"")+"|");
		buffer.append((message.getInvocationProperty("response-content-length")!=null?message.getInvocationProperty("response-content-length"):"")+"|");
		buffer.append(message.getInvocationProperty("endTime").toString().trim()+"|");
		buffer.append((message.getInvocationProperty("ait")!=null?message.getInvocationProperty("ait"):"")+"|");
		buffer.append(ClientIP+"|");
		buffer.append(message.getInvocationProperty("appName")+"|");
		buffer.append((message.getInvocationProperty("OutBoundRoute")!=null?message.getInvocationProperty("OutBoundRoute"):"")+"|");
		buffer.append("CS&OT|");
		buffer.append("|");
		buffer.append((message.getInvocationProperty("orgTargetNamespace")!=null?message.getInvocationProperty("orgTargetNamespace"):"")+"|");
		buffer.append("|");
		
		muleMessage = new DefaultMuleMessage(null, muleContext);
		muleMessage.setPayload(buffer);
		return muleMessage;
		}

}
