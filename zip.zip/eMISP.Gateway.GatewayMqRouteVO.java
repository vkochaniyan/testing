package com.mulesoft.mule.boa.vo;

public class GatewayMqRouteVO extends GatewayRouteVO {
	
	private static final long serialVersionUID = 4346566807698446547L;
	
	private String queueManagerGroupSet;
	private String mqMsgType;
	private String timeout;
	private String mqTopic;

	
	public GatewayMqRouteVO(){
		
	}
	
	
	public GatewayMqRouteVO(String name,String protocol,String queueManagerGroupSet,String mqMsgType,String timeout, String mqTopic){
		super(name, protocol);
		this.queueManagerGroupSet = queueManagerGroupSet;
		this.mqMsgType = mqMsgType;
		this.timeout = timeout;
		this.mqTopic = mqTopic;
	}
	
	public String getQueueManagerGroupSet() {
		return queueManagerGroupSet;
	}


	public void setQueueManagerGroupSet(String queueManagerGroupSet) {
		this.queueManagerGroupSet = queueManagerGroupSet;
	}


	public String getMqMsgType() {
		return mqMsgType;
	}


	public void setMqMsgType(String mqMsgType) {
		this.mqMsgType = mqMsgType;
	}


	public String getTimeout() {
		return timeout;
	}


	public void setTimeout(String timeout) {
		this.timeout = timeout;
	}


	public String getMqTopic() {
		return mqTopic;
	}


	public void setMqTopic(String mqTopic) {
		this.mqTopic = mqTopic;
	}
		
}
