package com.bac.vo;

import org.apache.commons.lang.builder.ToStringBuilder;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "serviceserviceName", "operationName", "access", "allowUnfilteredResponse", "SourceApplicationId", "providerAIT",
		"validateforGen4Headers","targetSvcNamespaceBaseUri", "methodName" })
public class Service {

	@JsonProperty("serviceName")
	private String serviceName;
	
	@JsonProperty("operationName")
	private String operationName;
	
	@JsonProperty("access")
	private String access;
	
	@JsonProperty("allowUnfilteredResponse")
	private String allowUnfilteredResponse;
	
	@JsonProperty("sourceApplicationId")
	private String sourceApplicationId;
	
	@JsonProperty("providerAIT")
	private String providerAIT;
	
	@JsonProperty("validateforGen4Headers")
	private String validateforGen4Headers;
	
	@JsonProperty("targetSvcNamespaceBaseUri")
	private String targetSvcNamespaceBaseUri;
	
	@JsonProperty("methodName")
	private String methodName;
	
	/**
	 * 
	 * @return The serviceName
	 */
	@JsonProperty("serviceName")
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * 
	 * @param serviceName
	 *            The serviceName
	 */
	@JsonProperty("serviceName")
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
	
	/**
	 * 
	 * @return The operationName
	 */
	@JsonProperty("operationName")
	public String getOperationName() {
		return operationName;
	}

	/**
	 * 
	 * @param operationName
	 *            The operationName
	 */
	@JsonProperty("operationName")
	public void setOperationName(String operationName) {
		this.operationName = operationName;
	}

	/**
	 * 
	 * @return The access
	 */
	@JsonProperty("access")
	public String getAccess() {
		return access;
	}

	/**
	 * 
	 * @param access
	 *            The access
	 */
	@JsonProperty("access")
	public void setAccess(String access) {
		this.access = access;
	}

	/**
	 * 
	 * @return The allowUnfilteredResponse
	 */
	@JsonProperty("allowUnfilteredResponse")
	public String getAllowUnfilteredResponse() {
		return allowUnfilteredResponse;
	}

	/**
	 * 
	 * @param allowUnfilteredResponse
	 *            The allowUnfilteredResponse
	 */
	@JsonProperty("allowUnfilteredResponse")
	public void setAllowUnfilteredResponse(String allowUnfilteredResponse) {
		this.allowUnfilteredResponse = allowUnfilteredResponse;
	}

	/**
	 * @return the validateforGen4Headers
	 */
	@JsonProperty("validateforGen4Headers")
	public String getValidateforGen4Headers() {
		return validateforGen4Headers;
	}

	/**
	 * @param validateforGen4Headers the validateforGen4Headers to set
	 */
	@JsonProperty("validateforGen4Headers")
	public void setValidateforGen4Headers(String validateforGen4Headers) {
		this.validateforGen4Headers = validateforGen4Headers;
	}

	/**
	 * @return the sourceApplicationId
	 */
	@JsonProperty("sourceApplicationId")
	public String getSourceApplicationId() {
		return sourceApplicationId;
	}

	/**
	 * @param sourceApplicationId the sourceApplicationId to set
	 */
	@JsonProperty("sourceApplicationId")
	public void setSourceApplicationId(String sourceApplicationId) {
		this.sourceApplicationId = sourceApplicationId;
	}

	/**
	 * 
	 * @return The providerAIT
	 */
	@JsonProperty("providerAIT")
	public String getProviderAIT() {
		return providerAIT;
	}

	/**
	 * 
	 * @param providerAIT
	 *            The providerAIT
	 */
	@JsonProperty("providerAIT")
	public void setProviderAIT(String providerAIT) {
		this.providerAIT = providerAIT;
	}

	/**
	 * @return the targetSvcNamespaceBaseUri
	 */
	@JsonProperty("targetSvcNamespaceBaseUri")
	public String getTargetSvcNamespaceBaseUri() {
		return targetSvcNamespaceBaseUri;
	}

	/**
	 * @param targetSvcNamespaceBaseUri the targetSvcNamespaceBaseUri to set
	 */
	@JsonProperty("targetSvcNamespaceBaseUri")
	public void setTargetSvcNamespaceBaseUri(String targetSvcNamespaceBaseUri) {
		this.targetSvcNamespaceBaseUri = targetSvcNamespaceBaseUri;
	}

	/**
	 * 
	 * @return The methodName
	 */
	@JsonProperty("methodName")
	public String getMethodName() {
		return methodName;
	}

	/**
	 * 
	 * @param methodName
	 *            The methodName
	 */
	@JsonProperty("methodName")
	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	@Override
	public String toString() {
	return ToStringBuilder.reflectionToString(this);
	}

}
