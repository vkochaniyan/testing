package com.mulesoft.mule.boa.vo;

public class ValidationPolicyVO {
	
	private String valueKey;
	private String isGen4Validation;
	
	public String getValueKey() {
		return valueKey;
	}
	public void setValueKey(String valueKey) {
		this.valueKey = valueKey;
	}
	public String getIsGen4Validation() {
		return isGen4Validation;
	}
	public void setIsGen4Validation(String isGen4Validation) {
		this.isGen4Validation = isGen4Validation;
	}
}
