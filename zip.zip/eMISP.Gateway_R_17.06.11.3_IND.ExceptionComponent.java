package com.mulesoft.mule.boa.exceptions;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transport.PropertyScope;
import org.mule.message.DefaultExceptionPayload;

@SuppressWarnings("unused")
public class ExceptionComponent implements Callable 
{

	//final String SOAP_ACTION = "SOAPAction";
	final String OPERATION = "X-BOA-Provider-Operation";
	final String TRACE_ID = "X-BOA-Trace-Id";
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {

		MuleMessage message = eventContext.getMessage();
		
		String operation = message.getInboundProperty(OPERATION);
		String traceId = message.getInboundProperty(TRACE_ID);
		DefaultExceptionPayload exceptionPayload = (DefaultExceptionPayload)message.getExceptionPayload();
		
		if(exceptionPayload.getException() instanceof org.mule.component.ComponentException){
			org.mule.component.ComponentException componentException = (org.mule.component.ComponentException)exceptionPayload.getException();
			com.mulesoft.mule.boa.exceptions.GatewayValidationException gwException = (com.mulesoft.mule.boa.exceptions.GatewayValidationException)componentException.getCause().getCause();
			String errorMessage = gwException.getMessage();
			String errorCode = gwException.getErrorCode();
			message.setProperty("ResponseStatus", "failure", PropertyScope.INVOCATION);
			message.setProperty("ResponseFaultErrorMsg", errorMessage, PropertyScope.INVOCATION);
			message.setProperty("ResponseFaultCode", errorCode, PropertyScope.INVOCATION);
			message.setProperty("traceId", traceId, PropertyScope.INVOCATION);
		}
		else{
			String ResponseFaultErrorMsg = exceptionPayload.getRootException().getMessage();
			if(exceptionPayload.getRootException() instanceof com.mulesoft.mule.boa.exceptions.GatewayValidationException){
				com.mulesoft.mule.boa.exceptions.GatewayValidationException gwException = (com.mulesoft.mule.boa.exceptions.GatewayValidationException)exceptionPayload.getRootException();
				message.setProperty("ResponseFaultCode", gwException.getErrorCode(), PropertyScope.INVOCATION);
			}
			
			if(exceptionPayload!=null){
				if(traceId!=null && operation!=null){
					ResponseFaultErrorMsg = "Trace Id "+traceId+" Operation is "+operation+" and error is "+ResponseFaultErrorMsg;
				}
				else{
					ResponseFaultErrorMsg = "Error is "+ResponseFaultErrorMsg;
				}
				message.setProperty("ResponseFaultErrorMsg", ResponseFaultErrorMsg, PropertyScope.INVOCATION);
				message.setProperty("traceId", traceId, PropertyScope.INVOCATION);
			}
		}
		
		/**
		 * Construct the SOAP Fault response
		 */
		return message;
	}
}
