/**
 * 
 */
package com.bac.cache.framework;

import java.io.IOException;
import java.net.URISyntaxException;

/**
 * @author ZKWQBHO
 * @param <K>
 * @param <V>
 *
 */
public interface IObjectBuilder<T, t> {

		public abstract void build() throws IOException, URISyntaxException;
}
