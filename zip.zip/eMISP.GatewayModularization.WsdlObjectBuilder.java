package com.bac.cache.framework;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import javax.wsdl.Definition;
import javax.wsdl.Port;
import javax.wsdl.Service;
import javax.wsdl.extensions.soap.SOAPAddress;
import javax.wsdl.factory.WSDLFactory;
import javax.wsdl.xml.WSDLReader;
import javax.wsdl.xml.WSDLWriter;
import javax.xml.namespace.QName;
import org.apache.commons.io.IOUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.Cache;
import org.ehcache.spi.loaderwriter.CacheWritingException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.xml.sax.InputSource;

import com.ctc.wstx.util.StringUtil;

public class WsdlObjectBuilder {

	private static final Logger logger = LogManager.getLogger();

	private static String SERVICE_RESOURCES = "ServiceResources";
	private static String SERVICE_URI = "serviceUri";
	private static String WSDL_HTTP_PATH = "wsdlHttpPath";

	private String wsdlPath = null;
	private String wsdIndexPath = null;
	private CacheSSLConnector cacheSSLConnector = null;
	private String env = null;
	private Definition wsdlDefinition = null;

	public WsdlObjectBuilder(String wsdlPath, String wsdIndexPath, CacheSSLConnector cacheSSLConnector, String env) {
		this.wsdlPath = wsdlPath;
		this.wsdIndexPath = wsdIndexPath;
		this.cacheSSLConnector = cacheSSLConnector;
		this.env = env;
	}

	public void build(Cache<String, Object> ehCache) throws IOException, URISyntaxException {
		InputStream cacheStream = null;
		ReadWriteLock lock = new ReentrantReadWriteLock();

		try {

			cacheStream = cacheSSLConnector.readUrl(wsdIndexPath);
			
			if (cacheStream != null) {
				JSONObject jsonObject = new JSONObject(IOUtils.toString(cacheStream, StandardCharsets.UTF_8));
				
				JSONArray serviceArray = null;
				if(jsonObject.has(SERVICE_RESOURCES)){
				 serviceArray = jsonObject.getJSONArray(SERVICE_RESOURCES);
				}
				else{
					logger.error("Missing ServiceResources key on: "+wsdIndexPath);
				}
				for (int counter = 0; counter < serviceArray.length(); counter++) {
					try {
						JSONObject baseObj = serviceArray.getJSONObject(counter);
						
						String serviceUri = null;
						if(baseObj.has(SERVICE_URI)){
						serviceUri = baseObj.getString(SERVICE_URI);
						logger.debug("SERVICE URL ====> " + serviceUri);
						}
						else{
							logger.error("Missing serviceUri key on :"+wsdIndexPath);
						}

						String serviceName = null;
						if(StringUtils.isNotEmpty(serviceUri)){
						serviceName = serviceUri.substring(serviceUri.lastIndexOf("/") + 1);
						logger.debug("ServiceName: " + serviceName);
						}else{
							logger.error("serviceUri is null or empty on HTTP Server");
						}

						String wsdlHttpPathFull = null;
						String wsdlName = null;
						if (baseObj.has(WSDL_HTTP_PATH)) {
							wsdlHttpPathFull = baseObj.getString(WSDL_HTTP_PATH);
							logger.debug("WSDL HTTP Path ====> " + wsdlHttpPathFull);
							
							wsdlName = baseObj.getString(WSDL_HTTP_PATH) + ".wsdl";
							logger.debug("WSDL Name: " + wsdlName);
						}
			
						String wsdl = null;
						if (StringUtils.isNotBlank(wsdlPath) && StringUtils.isNotBlank(wsdlHttpPathFull)) {
							wsdlHttpPathFull = wsdlPath + wsdlHttpPathFull;
							logger.debug("wsdl HTTP Path: " + wsdlHttpPathFull);

							String locationAfterReplacing = getLocationAfterReplacingEnv(wsdlHttpPathFull);
							logger.debug("Location after replaced: " + locationAfterReplacing);

							WSDLWriter wsdlWriter = WSDLFactory.newInstance().newWSDLWriter();
							ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
							wsdlWriter.writeWSDL(wsdlDefinition, byteArrayOutputStream);
							wsdl = byteArrayOutputStream.toString();
							logger.debug("WSDL: " + wsdl);
							}else{
								logger.error("Wsdl path is null or empty for the service name: "+serviceName);
							}

						// store the values in cache
						if (wsdl != null) {
							logger.debug("  WsdlObjectBuilder->	WSDL IS NOT NULL	");

							try {
								lock.writeLock().lock();
								ehCache.put(serviceName, wsdl);
							} catch (CacheWritingException cwe) {
								logger.error(
										"  Exception in inserting same record in Cache, Doing the Refresh record in Cache!	");
								try {
									ehCache.remove(serviceName);
									ehCache.put(serviceName, wsdl);
								} catch (CacheWritingException e1) {
									logger.error("Error in refreshing Cache for following service " + serviceName);
								} finally {
									lock.writeLock().unlock();
								}
							}
							logger.debug(
									"WSDL OBJECT BUILDER JSON ====>  key: " + serviceName + ", value:" + ehCache.get(serviceName));
					
						}
					} catch (Exception e) {
						logger.error("WsdlObjectBuilder-> - CANNOT LOAD WSDL FILE : ERROR -> " + e.toString());
						e.printStackTrace();
					}
				}

			}
		} catch (Exception e) {
			logger.debug("ERROR  " + e);
			e.printStackTrace();
			throw new IOException(e);
		} finally {
			if (cacheStream != null) {
				cacheStream.close();
			}
		}
		logger.debug("WsdlObjectBuilder-> - WSDL FILES LOADED IN CACHE -> " + ehCache.toString());

	}

	/**
	 * @param wsdlFilePath
	 * @return locationAfterReplacing String
	 * @throws Exception
	 */
	public String getLocationAfterReplacingEnv(String wsdlHttpPath) throws Exception {

		  WSDLFactory wsdlFactory = WSDLFactory.newInstance();
		  WSDLReader wsdlReader = wsdlFactory.newWSDLReader();
		  InputStream inputStream = cacheSSLConnector.readUrl(wsdlHttpPath);
		  wsdlDefinition = wsdlReader.readWSDL(wsdlHttpPath, new InputSource(inputStream));
		  logger.debug("wsdl definition: "+wsdlDefinition);
		       

		QName qname = getFirstServiceQName(wsdlDefinition);
		logger.debug("QNAME==> " + qname.toString());
		logger.debug("QNAME local==> " + qname.getLocalPart());

		String locationAfterReplacing = parseWSDL(wsdlDefinition, qname, env);
		logger.debug("LOCATION AFTER REPLACING ==> " + locationAfterReplacing);
		return locationAfterReplacing;
	}

	/**
	 * @param wsdlDef Definition
	 * @return serviceQName QName
	 * @throws Exception
	 */
	public static QName getFirstServiceQName(Definition wsdlDef) throws Exception {
		Map servicesMap = wsdlDef.getServices();
		if (servicesMap == null || servicesMap.isEmpty()) {
			throw new Exception("No services defined in WSDL.");
		}
		QName serviceQName = null;
		Iterator keySetItr = servicesMap.keySet().iterator();
		while (keySetItr.hasNext()) {
			serviceQName = (QName) keySetItr.next();
			break;
		}
		return serviceQName;
	}

	/**
	 * @param wsdlDef Definition
	 * @param qname QName
	 * @return locationAfterReplacing String
	 * @throws Exception
	 */
	public static String parseWSDL(Definition wsdlDef, QName qname, String env) throws Exception {

		String portName = null;
		String location = "";
		String targetNamespace = wsdlDef.getTargetNamespace();
		logger.debug("targetNamespace ==> " + targetNamespace);
		Service serviceDef = wsdlDef.getService(qname);
		if (serviceDef != null) {
			Collection<Port> ports = serviceDef.getPorts().values();
			for (Port port : ports) {
				portName = port.getName();
				logger.debug("PORT NAME ===> " + portName);
				List extensionElements = port.getExtensibilityElements();
				for (Object extension : extensionElements) {
					if (extension instanceof SOAPAddress) {
						SOAPAddress address = (SOAPAddress) extension;
						location = address.getLocationURI();
						logger.debug("location before replacing env: " + location);

						String envFromLocation = location.replaceFirst(".*-(.*?):.*", "$1");
						logger.debug("env from location: " + envFromLocation);

						String locationAfterReplacing = location.replace(envFromLocation, env);
						logger.debug("Location after replacing Env: " + locationAfterReplacing);
						address.setLocationURI(locationAfterReplacing);

						return locationAfterReplacing;
					}
				}
			}

		}
		return location;
	}
}