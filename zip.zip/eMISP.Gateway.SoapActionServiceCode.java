package com.mulesoft.mule.boa;

public enum SoapActionServiceCode {
	
	LoanHistory("ILoanHistorySrvc"),
	CUSTOMER("IICustomer"),
	General("IIGeneral"),
	MACEPreferenceSearch("IMACEPreferenceSearchService"),
	DocSearch("IMaceDocSearchService"),
	NonPrivate("IINonPrivate"),
	ReAge("IReAge"),
	IILabels("IILabels");
	
	private String description;
	
	private SoapActionServiceCode(String description){
		this.description = description;
	}
	
	public String getDescription(){
		return description;
	}
	
	public static SoapActionServiceCode getSoapActionServiceCode(String valueStr) {
		for (SoapActionServiceCode code : SoapActionServiceCode.values()) {
	        if (code.getDescription().equals(valueStr)) {
	            return code;
	        }
	    }
	    return null;
	}
}
