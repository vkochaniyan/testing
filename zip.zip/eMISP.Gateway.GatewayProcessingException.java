package com.mulesoft.mule.boa.exceptions;

public class GatewayProcessingException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 302767469093019885L;

	public GatewayProcessingException(){
		
	}
	
	public GatewayProcessingException(Exception e){
		
	}
	
	
}
