package com.mulesoft.mule.boa.vo;

public class GatewayProcessingPolicy {

	private String uri;
	private String preprocessing;
	
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
	public String getPreprocessing() {
		return preprocessing;
	}
	public void setPreprocessing(String preprocessing) {
		this.preprocessing = preprocessing;
	}
	
}
