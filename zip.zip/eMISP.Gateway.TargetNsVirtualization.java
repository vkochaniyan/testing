package com.mulesoft.mule.boa;

import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.processor.MessageProcessor;

public class TargetNsVirtualization implements MessageProcessor {

	@Override
	public MuleEvent process(MuleEvent event) throws MuleException {
		try {
			
			String virtualizationTargetNSUri = event.getFlowVariable("virtualizationTargetNSUri");
			if (virtualizationTargetNSUri == null || virtualizationTargetNSUri.trim().length() == 0) {
				return event;
			}
			
			virtualizationTargetNSUri = virtualizationTargetNSUri.trim();
			
			String orgTargetNamespace = event.getFlowVariable("orgTargetNamespace");
			int colonIndex = orgTargetNamespace.indexOf(":");
			
			String searchVal = "xmlns=";
			if (colonIndex > 0) {
				String prefix = orgTargetNamespace.substring(0, colonIndex);
				searchVal = "xmlns:" + prefix + "=";
			}
			
			String spayload = event.getFlowVariable("Request");
			int nsIndex = spayload.indexOf(searchVal);
			String before = spayload.substring(0, nsIndex);
			String quote = spayload.substring(nsIndex + searchVal.length(), nsIndex + searchVal.length()+ 1);
			
			String fullAfter = spayload.substring(nsIndex + searchVal.length() + 1);
			int quoteIndex = fullAfter.indexOf(quote);
			String after = fullAfter.substring(quoteIndex+1);
			
			String updatedRequest = before + searchVal + quote + virtualizationTargetNSUri + quote + after;
			event.setFlowVariable("Request", updatedRequest);

		
			int i = 0;

			// event.setFlowVariable("SoapOprName", oprName);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return event;

	}

}