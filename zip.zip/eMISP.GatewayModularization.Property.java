package com.bac.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "@elementSvcName", "@elementNewValue", "@elementType" })
public class Property {

	@JsonProperty("@elementSvcName")
	private String elementSvcName;
	@JsonProperty("@elementNewValue")
	private String elementNewValue;
	@JsonProperty("@elementType")
	private String elementType;

	/**
	 * 
	 * @return The elementSvcName
	 */
	@JsonProperty("@elementSvcName")
	public String getElementSvcName() {
		return elementSvcName;
	}

	/**
	 * 
	 * @param elementSvcName
	 *            The @elementSvcName
	 */
	@JsonProperty("@elementSvcName")
	public void setElementSvcName(String elementSvcName) {
		this.elementSvcName = elementSvcName;
	}

	/**
	 * 
	 * @return The elementNewValue
	 */
	@JsonProperty("@elementNewValue")
	public String getElementNewValue() {
		return elementNewValue;
	}

	/**
	 * 
	 * @param elementNewValue
	 *            The @elementNewValue
	 */
	@JsonProperty("@elementNewValue")
	public void setElementNewValue(String elementNewValue) {
		this.elementNewValue = elementNewValue;
	}

	/**
	 * 
	 * @return The elementType
	 */
	@JsonProperty("@elementType")
	public String getElementType() {
		return elementType;
	}

	/**
	 * 
	 * @param elementType
	 *            The @elementType
	 */
	@JsonProperty("@elementType")
	public void setElementType(String elementType) {
		this.elementType = elementType;
	}

}