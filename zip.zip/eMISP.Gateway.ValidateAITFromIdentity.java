package com.mulesoft.mule.boa;
import java.util.HashMap;

import org.mule.api.MuleMessage;
import org.mule.api.routing.filter.Filter;
import java.io.File;

public class ValidateAITFromIdentity implements Filter {

	@Override
	public boolean accept(MuleMessage message) {		
		HashMap<String, String> map = message.getInvocationProperty("cMap");
		String ait= message.getInvocationProperty("AIT");
		if(ait == null){
	      File file = new File(ait + "-authorize.json");
	      if(!file.exists()){
			map.put("ErrMsg", "Authorize file missing for AIT " + ait);
			throw new IllegalArgumentException("Authorize file missing for AIT " + ait);
	      }
		}
		return true;
	}

}
