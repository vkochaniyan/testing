package com.mulesoft.mule.boa.vo;

import java.util.Map;

public class HttpToMqVO implements java.io.Serializable {
	
	private Map <String, String> mqHeaders;

	

	/**
	 * 
	 */
	private static final long serialVersionUID = 2059905916591900652L;
	
	public HttpToMqVO () {
		
	}
	
	public Map<String, String> getMqHeaders() {
		return mqHeaders;
	}

	public void setMqHeaders(Map<String, String> mqHeaders) {
		this.mqHeaders = mqHeaders;
	}

}
