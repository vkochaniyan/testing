package com.mulesoft.mule.boa;

import org.mule.api.MuleEvent;

import com.mulesoft.mule.cache.responsegenerator.DefaultResponseGenerator;

public class CachedConfigResponseGenerator extends DefaultResponseGenerator {

	@Override
	public MuleEvent create(MuleEvent request, MuleEvent cachedResponse) {
		// Modify the request to extract the cached GW-Identify configuration
		// from the cache and put it in the message...
		Object gwIdentifyCachedObj = cachedResponse
				.getFlowVariable("gw-identify-cached");
		request.setFlowVariable("gw-identify-cached", gwIdentifyCachedObj);

		return request;
	}

}
