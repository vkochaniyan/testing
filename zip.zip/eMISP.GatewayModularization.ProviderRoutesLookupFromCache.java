package com.bac.component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;
import javax.xml.bind.DatatypeConverter;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.Cache;
import org.ehcache.spi.loaderwriter.CacheWritingException;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.util.StringUtils;
import com.bac.cache.framework.ConfigCacheManager;

/**
 * @author ZKZBQ23 Lookup from ehCache
 *
 */
public class ProviderRoutesLookupFromCache implements Callable {

	private static final Logger logger = LogManager.getLogger();

	private static String HIPHEN_PROVIDER_ROUTES_DOT_JSON = "-provider-routes.json";
	private static String SERVICE_NAME = "serviceName";
	private static String PROVIDER_AIT = "providerAIT";
	private static String PROVIDER_ROUTE = "providerRoute";
	private static String SERVICE_AND_BASEURI = "serviceAndBaseUri";
	private static String ROUTE = "route";
	private static String ENV = "env";
	private static String PROTOCOL = "protocol";
	private static String DOMAIN = "domain";
	private static String PORT = "port";
	private static String BASE_URI = "baseUri";
	private static String SOURCE_APPLICATION_ID = "sourceApplicationId";
	private static String CREDENTIALS = "credentials";
	private static String PW_TYPE = "pwType";
	private static String TYPE = "type";
	private static String USER = "user";
	private static String PASSWORD = "password";

	private String provRoutesConfigMissing = null;
	private String provRoutesServiceNameMissing = null;
	private String provRoutesEnvMissing = null;
	
	private ConfigCacheManager configCacheManager;
	
	

	/**
	 * @param provRoutesConfigMissing String
	 * @param provRoutesServiceNameMissing String
	 * @param provRoutesEnvMissing String
	 */
	public ProviderRoutesLookupFromCache(String provRoutesConfigMissing, String provRoutesServiceNameMissing,
			String provRoutesEnvMissing) {
		this.provRoutesConfigMissing = provRoutesConfigMissing;
		this.provRoutesServiceNameMissing = provRoutesServiceNameMissing;
		this.provRoutesEnvMissing = provRoutesEnvMissing;
	}

	/**
	 * @param configCacheManager ConfigCacheManager
	 */
	public void setConfigCacheManager(ConfigCacheManager configCacheManager) {
		this.configCacheManager = configCacheManager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.mule.api.lifecycle.Callable#onCall(org.mule.api.MuleEventContext)
	 */
	@Override
	public String onCall(MuleEventContext eventContext) throws Exception {

		logger.debug("onCall start");
		String route = null;
		String domain = null;
		String port = null;
		String protocol = null;
		String baseUri = null;

		List<Map> providerRouteCollection = null;

		MuleMessage message = eventContext.getMessage();

		// Get a ReadLock on cache
		Cache<String, Object> ehCache = configCacheManager.getConfigCache();

		ReadWriteLock lock = new ReentrantReadWriteLock();

		try {
			lock.readLock().lock();
			String providerAIT = message.getOutboundProperty(PROVIDER_AIT);

			logger.debug("providerAIT:" + providerAIT);

			String fileName = providerAIT + HIPHEN_PROVIDER_ROUTES_DOT_JSON;

			logger.debug("fileName: " + fileName);

			providerRouteCollection = (List<Map>) ehCache.get(fileName);

			if (providerRouteCollection != null) {
				logger.debug("providerRouteCollection: " + providerRouteCollection);
			} else {
				logger.error("Provider Routes JSON file is not on HTTP server or is not available in Cache for the providerAIT: "+providerAIT);
				throw new Exception(
						provRoutesConfigMissing + ": "
								+ providerAIT);
			}

		} catch (CacheWritingException exception) {
			logger.error("ERROR IN GETTING VALUES FROM EHCACHE:  " + exception);
			exception.printStackTrace();
		} finally {
			lock.readLock().unlock();
		}

	   Object[] serviceAndBaseUriOpt = null;

		for (int i = 0; i < providerRouteCollection.size(); i++) {
			Map<String, Map> providerRouteMap = providerRouteCollection.get(i);
			
			Map providerRouteValue = null;
			if(providerRouteMap.containsKey(PROVIDER_ROUTE)){
			providerRouteValue = providerRouteMap.get(PROVIDER_ROUTE);
			}else{
				logger.error("Provider-routes configuration file doesnot contain providerRoute key");
			}
			
			List<Map> serviceAndBaseUriArray =  null;
			if(providerRouteValue.containsKey(SERVICE_AND_BASEURI)){
			serviceAndBaseUriArray = (List<Map>) providerRouteValue.get(SERVICE_AND_BASEURI);
			}else{
				logger.error("Provider-routes configuration file doesnot contain serviceAndBaseUri key");
			}
			
			String serviceName = message.getOutboundProperty(SERVICE_NAME);
			logger.debug("Request serviceName: " + serviceName);

			serviceAndBaseUriOpt = serviceAndBaseUriArray.stream().filter(s -> (s.get(SERVICE_NAME).equals(serviceName))).toArray();

			if (serviceAndBaseUriOpt != null && serviceAndBaseUriOpt.length != 0) {
				logger.debug("ServiceName matched");
				
				List<Map> routeArray = null;
				if(providerRouteValue.containsKey(ROUTE)){
				routeArray = (List<Map>) providerRouteValue.get(ROUTE);
				}
				else{
					logger.error(" Missing Route key in Provider-routes configuration file ");
				}

				logger.debug("Route Array: " + routeArray);

				// Route Array
				String envValue = System.getProperty(ENV);
				
				Object[] opt = routeArray.stream().filter(s -> s.get(ENV).equals(envValue)).toArray();
				
				if (opt != null && opt.length != 0) {
					logger.debug("Environment matched");
				} else {
					logger.error("ServiceName matched but environment didnt match to get the provider Route ");
					throw new Exception(provRoutesEnvMissing +":"+serviceName);
				}

				for (int j = 0; j < opt.length; j++) {
					Map<String, String> routeMap = (Map<String, String>) opt[j];

					// Source Application Id is present in Soap Request
					if (StringUtils.isNotEmpty(message.getOutboundProperty(SOURCE_APPLICATION_ID))) {
						// Check if Source Application Id is in JSON files
						if (routeMap.containsKey(SOURCE_APPLICATION_ID) && StringUtils.isNotEmpty(routeMap.get(SOURCE_APPLICATION_ID))) {
							String sourceApplicationId = routeMap.get(SOURCE_APPLICATION_ID);

							if (routeMap.get(SOURCE_APPLICATION_ID)
									.equals(message.getOutboundProperty(SOURCE_APPLICATION_ID))) {
								logger.debug("Source Application Id matched");

								getDomainPortProtocol(message, serviceName, routeMap);

								if (routeMap.get(SOURCE_APPLICATION_ID)
										.equals(message.getOutboundProperty(SOURCE_APPLICATION_ID))) {
									break;
								}

							}
						}
						// CBR but different domains not required
						else {
							getDomainPortProtocol(message, serviceName, routeMap);
							
							if (StringUtils.isNotBlank(domain) && StringUtils.isNotBlank(port)
									&& StringUtils.isNotBlank(protocol)) {
								break;
							}
						}
						// Not CBR
					} else {
						logger.debug("Source Application Id not passed in Soap request");

						getDomainPortProtocol(message, serviceName, routeMap);
						
						if (StringUtils.isNotBlank(domain) && StringUtils.isNotBlank(port)
								&& StringUtils.isNotBlank(protocol)) {
							break;
						}
					}

				} // end of routeArray
				
				Map<String, Object> serviceAndBaseUriMap = null;
				for (int k = 0; k < serviceAndBaseUriOpt.length; k++) {
					serviceAndBaseUriMap = (Map<String, Object>) serviceAndBaseUriOpt[k];

					// Source ApplicationId is passed in Soap request; CBR lookup
					if (StringUtils.isNotBlank(message.getOutboundProperty(SOURCE_APPLICATION_ID))) {

						// To check if Source Application Is present in JSON files
						if (serviceAndBaseUriMap.containsKey(SOURCE_APPLICATION_ID) && serviceAndBaseUriMap.get(SOURCE_APPLICATION_ID)!= null) {

							if (serviceAndBaseUriMap.get(SOURCE_APPLICATION_ID).equals(message.getOutboundProperty(SOURCE_APPLICATION_ID))) {
								baseUri = getBaseUri(baseUri, message, serviceName, serviceAndBaseUriMap);
							}
							if (serviceAndBaseUriMap.get(SOURCE_APPLICATION_ID).equals(message.getOutboundProperty(SOURCE_APPLICATION_ID))) {
								break;
							}
						}
						// CBR but different baseuri not required
						else {
							baseUri = getBaseUri(baseUri, message, serviceName, serviceAndBaseUriMap);
							if (StringUtils.isNotBlank(baseUri)) {
								break;
							}
						}
					}
					// Not CBR Routing or No Source Application in Soap Request since it
					// is optional
					else {
						baseUri = getBaseUri(baseUri, message, serviceName, serviceAndBaseUriMap);
						if (StringUtils.isNotBlank(baseUri)) {
							break;
						}
					}
				
				}//End of Base uri
				
				// WS-Security - username,password
				if (serviceAndBaseUriMap.containsKey(CREDENTIALS)) {
					Map<String, String> credentialsMap = (Map<String, String>) serviceAndBaseUriMap.get(CREDENTIALS);
					
					String type = null;
					if(credentialsMap.containsKey(TYPE)){
					type = credentialsMap.get(TYPE);
					message.setInvocationProperty("wsseType", type);
					}
					
					String pwType = null;
					if(credentialsMap.containsKey(PW_TYPE)){
						pwType = credentialsMap.get(PW_TYPE);
						message.setInvocationProperty("wssePwType", pwType);
					}
					
						if(credentialsMap.containsKey(USER)){
						String user = credentialsMap.get(USER);
						message.setInvocationProperty("wsseUser", user);
						}

						if(credentialsMap.containsKey(PASSWORD)){
						String encodedPassword = credentialsMap.get(PASSWORD);
						message.setInvocationProperty("wssePassword", encodedPassword);
					     
						// decode password using BASE64
						String decodedPassword = new String(DatatypeConverter.parseBase64Binary(encodedPassword));
					    message.setInvocationProperty("wssePasswordDecoded", decodedPassword);
						}
				
				} // End of WS-Security
				
				if (serviceAndBaseUriOpt != null && !serviceAndBaseUriOpt.toString().equalsIgnoreCase("Optional.empty")) {
					break;
				}
			} // end of serviceArray
		} // provider Route Collection

		if (serviceAndBaseUriOpt != null && !serviceAndBaseUriOpt.toString().equalsIgnoreCase("Optional.empty")) {
			logger.debug("Fetched Service Name");
		} else {
			logger.error(" ServiceName in Provider Routes mismatch or missing ");
			throw new Exception(provRoutesServiceNameMissing);
		}

		route = message.getOutboundProperty(PROTOCOL) + "://" + message.getOutboundProperty(DOMAIN) + ":"
				+ message.getOutboundProperty(PORT) + "/" + message.getOutboundProperty(BASE_URI);
		logger.debug("Route: " + route);
		logger.debug("onCall end");
		return route;

	}

	/**
	 * @param baseUri String
	 * @param message MuleMessage
	 * @param serviceName String
	 * @param serviceAndBaseUriMap Map<String, Object>
	 * @return baseUri String
	 */
	private String getBaseUri(String baseUri, MuleMessage message, String serviceName,
			Map<String, Object> serviceAndBaseUriMap) {
		if(serviceAndBaseUriMap.containsKey(BASE_URI)){
			baseUri = (String) serviceAndBaseUriMap.get(BASE_URI);
			message.setOutboundProperty("baseUri", baseUri);
			logger.debug("baseUri: " + baseUri);
			}
			else{
				logger.error("Missing baseUri key for the service: "+serviceName);
			}
		return baseUri;
	}

	/**
	 * @param message MuleMessage
	 * @param serviceName String
	 * @param routeMap Map<String, String>
	 */
	private void getDomainPortProtocol(MuleMessage message, String serviceName, Map<String, String> routeMap) {
		String domain = null;
		String port = null;
		String protocol = null;
		if(routeMap.containsKey(DOMAIN)){
		domain = routeMap.get(DOMAIN);
		message.setOutboundProperty(DOMAIN, domain);
		}
		else{
			logger.error("Missing domain key for the service: "+serviceName);
		}

		if(routeMap.containsKey(PORT)){
		port = routeMap.get(PORT);
		message.setOutboundProperty(PORT, port);
		}
		else{
			logger.error("Missing port key for the service: "+serviceName);
		}

		if(routeMap.containsKey(PROTOCOL)){
		protocol = routeMap.get(PROTOCOL);
		message.setOutboundProperty(PROTOCOL, protocol);
		}
		else{
			logger.error("Missing protocol key for the service: "+serviceName);
		}
	}
}
