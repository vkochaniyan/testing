package com.mulesoft.mule.boa;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.net.MalformedURLException;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPHeader;
import javax.xml.soap.SOAPMessage;
import javax.xml.soap.SOAPPart;
import javax.xml.transform.stream.StreamSource;

import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.MuleMessage;
import org.mule.api.processor.MessageProcessor;
import org.w3c.dom.NodeList;



import org.w3c.dom.Element;

import com.pingidentity.sts.clientapi.STSClient;
import com.pingidentity.sts.clientapi.STSClientConfiguration;
import com.pingidentity.sts.clientapi.STSClientException;
import com.pingidentity.sts.clientapi.SecurityTokenException;
import com.pingidentity.sts.clientapi.tokens.saml.Saml20Token;
import com.pingidentity.sts.clientapi.tokens.saml.Saml20TokenHandler;
import com.pingidentity.sts.clientapi.tokens.saml.SamlToken;
import com.pingidentity.sts.clientapi.utils.StringUtils;
import com.sun.syndication.io.impl.Base64;

public class ParseSAMLAssertion implements MessageProcessor {
    
	StringUtils utils = new StringUtils();
	MuleMessage mulmsg = null;
    @Override
	public MuleEvent process(MuleEvent event) throws MuleException {
		
		/** Set a default value**/
		
		InputStream is = null;
		
		mulmsg = event.getMessage();
		
		String b64Token = mulmsg.getInboundProperty("EIBToken");
		//String bdecodedToken = Base64.decode(b64Token);
		Boolean bValidToken = false;
		try 
		{
			if(b64Token !=null && b64Token.trim() != "" ){
				String bdecodedToken = Base64.decode(b64Token);
				String soapText = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\">"+
								   "<soapenv:Header>"+
								   "<wsse:Security xmlns:wsse=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd\" xmlns:wsu=\"http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd\">"+
								   bdecodedToken+
								   "</wsse:Security>"+
								   "</soapenv:Header>"+
								   "<soapenv:Body>"+     
								   "</soapenv:Body>"+
								"</soapenv:Envelope>";
				// Create SoapMessage
	            MessageFactory msgFactory     = MessageFactory.newInstance();
	            SOAPMessage message           = msgFactory.createMessage();
	            SOAPPart soapPart             = message.getSOAPPart();
	  
	            // Load the SOAP text into a stream source
	            byte[] buffer                 = soapText.getBytes();
	            ByteArrayInputStream stream   = new ByteArrayInputStream(buffer);
	            StreamSource source           = new StreamSource(stream);
	  
	            // Set contents of message 
	            soapPart.setContent(source);
	  
	            // -- Print	  
	            message.writeTo(System.out);
	            
	            bValidToken = ConnectToPingStsSP(message);
	            

			}else{
			
			String spayload = event.getMessage().getPayloadAsString();
			is = new ByteArrayInputStream(spayload.getBytes());
			try {
				SOAPMessage soapmsg = setSOAPServiceNameOperation(is, SOAPConstants.SOAP_1_1_PROTOCOL);
				bValidToken = ConnectToPingStsSP(soapmsg);
			} catch (Exception e1) {
				e1.printStackTrace();
				System.out.println(e1.getCause());
				System.out.println(e1.getMessage());
				
				//setSOAPServiceNameOperation(is, SOAPConstants.SOAP_1_2_PROTOCOL);
			}
			
			}
			
			
			
			return event;
			
			
			// others
			

		} catch (Exception e) {
			e.printStackTrace();
		}
		return event;

	}
    
    private SOAPMessage setSOAPServiceNameOperation(InputStream is, String SOAPVersion) throws Exception {    	
    	return MessageFactory.newInstance(SOAPVersion).createMessage(null, is);   	

    	
	}
	
	private boolean ConnectToPingStsSP(SOAPMessage soapMsg) {
		boolean valid = false;
		SOAPHeader header = null;
		try {
			header = soapMsg.getSOAPHeader();
		} catch (SOAPException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		if(header == null){
			return false;
		}
        NodeList secHeaders = header.getElementsByTagNameNS("http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-secext-1.0.xsd", "Security");

        if (secHeaders.getLength() == 0) {

            throw new RuntimeException("No Security Header");
        }
        Element securityHeader = (Element) secHeaders.item(0);
        
        String czHeader = utils.prettyPrint(securityHeader);
        System.out.println(czHeader);

        STSClientConfiguration stsClientConfiguration = new STSClientConfiguration();

        String pingEndpoint = mulmsg.getInvocationProperty("PingSTSEndPointURL");
        
        stsClientConfiguration.setStsEndpoint(pingEndpoint);
        // Ignoring SSL errors is helpful when using self-signed SSL certificates  
        stsClientConfiguration.setIgnoreSSLTrustErrors(true);        
        stsClientConfiguration.setInTokenType(STSClientConfiguration.TokenType.SAML2);

        STSClient client;
        try {
        	
            client = new STSClient(stsClientConfiguration);

        } catch (MalformedURLException e) {
            // deal with the exception.  
            // in case of a hardcoded endpoint this never happens

            throw new RuntimeException(e);
        }
        SamlToken token;

        try {
            token = client.extractTokenFromSecurityHeader(securityHeader);
            String cztoken = utils.prettyPrint(securityHeader);
            System.out.println(cztoken);
            System.out.println(token.getIssuer());
            System.out.println(token.getAudience());
            //System.out.println(token.get)
            System.out.println(token.getTokenType());
            System.out.println(token.toString());

        } catch (SecurityTokenException e) {
            throw new RuntimeException(e);

        }
        if (token == null) {

            throw new RuntimeException("No security token found");
        }
        

        try {
            valid = client.validateToken(token);

        } catch (STSClientException e) {
        	e.printStackTrace();
            //throw new RuntimeException(e);

        }
        if (!valid) {
            throw new RuntimeException("Security token invalid");

        }      
        return valid;
		  
	}
	
	
}
