package com.mulesoft.mule.boa.util;

import java.util.HashMap;
import java.util.Map;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transport.PropertyScope;

public class OutboundPropertySetter implements Callable {

	private static Map<String,String> headerMappings = new HashMap<String,String>();
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		
		String inboundMandatoryProperties = (String) eventContext.getMessage().getInvocationProperty("inboundMandatory");
		String inboundOptionalProperties = (String) eventContext.getMessage().getInvocationProperty("inboundOptional");
		String flowProperties = (String) eventContext.getMessage().getInvocationProperty("flow");
		String ignoreProperties = (String) eventContext.getMessage().getInvocationProperty("ignore");
		String sessionProperties = (String) eventContext.getMessage().getInvocationProperty("session");
		String cMapProperties = (String) eventContext.getMessage().getInvocationProperty("cMapProperties");
		
		MuleMessage message = eventContext.getMessage();
		
		if(inboundMandatoryProperties!=null){
			String[] inboundProperty = inboundMandatoryProperties.split(",");
			for(int counter=0;counter<inboundProperty.length;counter++){
				String key = inboundProperty[counter];
				if(message.getInboundProperty(key)!=null){
					if(headerMappings.get(key)!=null){
						key = (String)headerMappings.get(key);
					}
					message.setOutboundProperty(key, message.getInboundProperty(key));
				}
			}
		}
		
		if(inboundOptionalProperties!=null){
			String[] inboundProperty = inboundMandatoryProperties.split(",");
			for(int counter=0;counter<inboundProperty.length;counter++){
				if(message.getInboundProperty(inboundProperty[counter])!=null){
					message.setOutboundProperty(inboundProperty[counter], message.getInboundProperty(inboundProperty[counter]));
				}
			}
		}
		
		if(sessionProperties!=null){
			String[] sessionProperty = sessionProperties.split(",");
			for(int counter=0;counter<sessionProperty.length;counter++){
				message.setOutboundProperty(sessionProperty[counter], message.getProperty(sessionProperty[counter],PropertyScope.SESSION));
			}
		}
		
		if(cMapProperties!=null){
			String[] cMapProperty = cMapProperties.split(",");
			HashMap cMap = (HashMap)message.getInvocationProperty("cMap");
			if(cMap!=null){
				for(int counter=0;counter<cMapProperty.length;counter++){
					if(cMap.get(cMapProperty[counter])!=null){
						message.setOutboundProperty(cMapProperty[counter], cMap.get(cMapProperty[counter]));
					}
				}
			}
		}
		
		if(flowProperties!=null){
			String[] flowProperty = flowProperties.split(",");
			for(int counter=0;counter<flowProperty.length;counter++){
				message.setOutboundProperty(flowProperty[counter], message.getInvocationProperty(flowProperty[counter]));
			}
		}
		message.setOutboundProperty("ignoreProperties",ignoreProperties);
		return eventContext.getMessage().getPayload();
	}

	static{
		headerMappings.put("x-boa-provider-service", "X-BOA-Provider-Service");
		headerMappings.put("x-boa-provider-servicename", "X-BOA-Provider-ServiceName");
		headerMappings.put("x-boa-provider-operation", "X-BOA-Provider-Operation");
	}
}
