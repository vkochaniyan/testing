package com.mulesoft.mule.boa.vo;

public class LoggingRouteKeyVO implements java.io.Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6856753700039576337L;
	private String env;
	private String publishTopic;
	
	public LoggingRouteKeyVO(){
		
	}
	
    public LoggingRouteKeyVO(String publishTopic){
		this.publishTopic = publishTopic;
		
	}
	
	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}
	
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		
		result = prime * result + ((env == null) ? 0 : env.hashCode());
		result = prime * result + ((publishTopic == null) ? 0 : publishTopic.hashCode());
		
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		LoggingRouteKeyVO other = (LoggingRouteKeyVO) obj;
		
		if (env == null) {
			if (other.env != null)
				return false;
		} else if (!env.equals(other.env))
			return false;
		if (publishTopic == null) {
			if (other.publishTopic != null)
				return false;
		} else if (!publishTopic.equals(other.publishTopic))
			return false;
		
		return true;
	}

	public String getPublishTopic() {
		return publishTopic;
	}

	public void setPublishTopic(String publishTopic) {
		this.publishTopic = publishTopic;
	}

	
}
