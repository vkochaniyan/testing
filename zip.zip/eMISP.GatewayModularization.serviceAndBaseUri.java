package com.bac.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "serviceName" })
public class serviceAndBaseUri {

	@JsonProperty("serviceName")
	private String serviceName;
	
	@JsonProperty("sourceApplicationId")
	private String sourceApplicationId;
	
	@JsonProperty("baseUri")
	private String baseuri;
	  
	@JsonProperty("credentials")
	private Credentials credentials;

	/**
	 * 
	 * @return The serviceName
	 */
	@JsonProperty("serviceName")
	public String getServiceName() {
		return serviceName;
	}

	/**
	 * 
	 * @param serviceName
	 *            The serviceName
	 */
	@JsonProperty("serviceName")
	public void setName(String serviceName) {
		this.serviceName = serviceName;
	}

	/**
	 * @return the sourceApplicationId
	 */
	@JsonProperty("sourceApplicationId")
	public String getSourceApplicationId() {
		return sourceApplicationId;
	}

	/**
	 * @param sourceApplicationId the sourceApplicationId to set
	 */
	@JsonProperty("sourceApplicationId")
	public void setSourceApplicationId(String sourceApplicationId) {
		this.sourceApplicationId = sourceApplicationId;
	}

	/**
	 * @return the baseuri
	 */
	@JsonProperty("baseuri")
	public String getBaseuri() {
		return baseuri;
	}

	/**
	 * @param baseuri the baseuri to set
	 */
	@JsonProperty("baseuri")
	public void setBaseuri(String baseuri) {
		this.baseuri = baseuri;
	}

	/**
	 * @return the credentials
	 */
	@JsonProperty("credentials")
	public Credentials getCredentials() {
		return credentials;
	}

	/**
	 * @param credentials the credentials to set
	 */
	@JsonProperty("credentials")
	public void setCredentials(Credentials credentials) {
		this.credentials = credentials;
	}

}