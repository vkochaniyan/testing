package com.mulesoft.mule.boa;
import java.util.HashMap;

import org.mule.api.MuleMessage;
import org.mule.api.routing.filter.Filter;

public class ValidateAITFromIdentity implements Filter {

	@Override
	public boolean accept(MuleMessage message) {		
		HashMap<String, String> map = message.getInvocationProperty("cMap");
		if(message.getInvocationProperty("AIT") == null){
			map.put("ErrMsg", "AIT missing in Identity");
			throw new IllegalArgumentException("AIT missing in Identity");
		}
		return true;
	}

}
