package com.mulesoft.mule.boa.vo;

public class GatewayGenericKey {

	private String environmentName;
	private String uniquePathName;

	public GatewayGenericKey(String environmentName,String uniquePathName) {
		this.environmentName = environmentName;
		this.uniquePathName = uniquePathName;
	}

	public String getUniquePathName() {
		return uniquePathName;
	}

	public void setUniquePathName(String uniquePathName) {
		this.uniquePathName = uniquePathName;
	}

	public String getEnvironmentName() {
		return environmentName;
	}

	public void setEnvironmentName(String environmentName) {
		this.environmentName = environmentName;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((environmentName == null) ? 0 : environmentName.hashCode());
		result = prime * result
				+ ((uniquePathName == null) ? 0 : uniquePathName.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		GatewayGenericKey other = (GatewayGenericKey) obj;
		if (environmentName == null) {
			if (other.environmentName != null)
				return false;
		} else if (!environmentName.equals(other.environmentName))
			return false;
		if (uniquePathName == null) {
			if (other.uniquePathName != null)
				return false;
		} else if (!uniquePathName.equals(other.uniquePathName))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "GatewayGenericKey [environmentName=" + environmentName
				+ ", uniquePathName=" + uniquePathName + "]";
	}

	

}
