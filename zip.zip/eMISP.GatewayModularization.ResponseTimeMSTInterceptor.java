package com.bac.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

public class ResponseTimeMSTInterceptor implements Callable {
	
	private final String DATE_FORMAT =  "yyyy-MM-dd'T'HH:mm:ss.SSSZ";
	private final String START_TIME =  "startTime";
	private final String END_TIME =  "endTime";
	
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		
		MuleMessage message = eventContext.getMessage();
		
		String startTime = message.getInvocationProperty(START_TIME);
		String endTime = message.getInvocationProperty(END_TIME);
		
		if(startTime!=null && endTime!=null){
			
			SimpleDateFormat format = new SimpleDateFormat(DATE_FORMAT);
			Date d1 = format.parse(startTime.trim());
			
			SimpleDateFormat format2 = new SimpleDateFormat(DATE_FORMAT);
			Date d2 = format2.parse(endTime.trim());
			
			long diff = d2.getTime() - d1.getTime();
			message.setInvocationProperty("responseTime", diff);
		}
		return message;
		
	}
}
