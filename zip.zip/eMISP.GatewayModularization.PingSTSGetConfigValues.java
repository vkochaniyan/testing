package com.bac.util;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class PingSTSGetConfigValues {
	
	static String serviceID = null;
	InputStream inputStream;
	static private PingSTSGetConfigValues instance = null;
	static Properties prop = null;
	
	private static String ENV = "env";
	private static String  IGATEWAY_DOT = "igateway.";
	private static String  DOT_PROPERTIES = ".properties";
		
	
	static public PingSTSGetConfigValues getPingSTSGetConfigValues() throws IOException{
		if(instance == null){
		instance = new PingSTSGetConfigValues();
		}
		return instance;
		}

	private PingSTSGetConfigValues() throws IOException{
		try{
			prop = new Properties();
		
			String env = System.getProperty(ENV);
			
			String propFileName = IGATEWAY_DOT+env+DOT_PROPERTIES;
 
			inputStream = getClass().getClassLoader().getResourceAsStream(propFileName);
 
			if (inputStream != null) {
				prop.load(inputStream);
			} else {
				throw new FileNotFoundException("property file '" + propFileName + "' not found in the classpath");
			}
 
		}catch(IOException e){
		e.printStackTrace();
		}finally{inputStream.close();}
		}
	
	public static String tokenAppliesTo() throws IOException
    {
		PingSTSGetConfigValues.getPingSTSGetConfigValues();
        return prop.getProperty("tokenAppliesTo");
    }
	public static String pingStsUrl() throws IOException
    {
		PingSTSGetConfigValues.getPingSTSGetConfigValues();
        return prop.getProperty("pingStsUrl");
    }
	
	public static String filename() throws IOException
    {
		PingSTSGetConfigValues.getPingSTSGetConfigValues();
        return prop.getProperty("filename");
    }
	public static String keystorePwd() throws IOException
    {
		PingSTSGetConfigValues.getPingSTSGetConfigValues();
        return prop.getProperty("keystorePwd");
    }
	public static String keyAlias() throws IOException
    {
		PingSTSGetConfigValues.getPingSTSGetConfigValues();
        return prop.getProperty("keyAlias");
    }
	public static String certType() throws IOException
    {
		PingSTSGetConfigValues.getPingSTSGetConfigValues();
        return prop.getProperty("certType");
    }
	public static String serviceID() throws IOException
    {
		PingSTSGetConfigValues.getPingSTSGetConfigValues();
		if(serviceID == null)
			serviceID = prop.getProperty("serviceID");
        return serviceID;
    }
	public static String certProvider() throws IOException
    {
		PingSTSGetConfigValues.getPingSTSGetConfigValues();
        return prop.getProperty("certProvider");
    }
	public static String p8tokenAppliesTo() throws IOException
    {
		PingSTSGetConfigValues.getPingSTSGetConfigValues();
        return prop.getProperty("p8tokenAppliesTo");
    }

	
	
}
