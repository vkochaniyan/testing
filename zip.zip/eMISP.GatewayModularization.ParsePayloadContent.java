package com.bac.util;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.processor.MessageProcessor;
import org.w3c.dom.Document;
import org.w3c.dom.Node;

public class ParsePayloadContent
  implements MessageProcessor
{
  private static XPathExpression expression0 = null;
  
  public MuleEvent process(MuleEvent event)
    throws MuleException
  {
    InputStream is = null;
    try
    {
      String spayload = event.getMessage().getPayloadAsString();
      is = new ByteArrayInputStream(spayload.getBytes());
      if ((event.getFlowVariable("IsGen2Osa") != null) && (event.getFlowVariable("IsGen2Osa").equals("true")))
      {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        factory.setIgnoringComments(true);
        Document doc = null;
        
        doc = factory.newDocumentBuilder().parse(is);
        
        Object rulesBagINfo = expression0.evaluate(doc, XPathConstants.NODE);
        Node n = (Node)rulesBagINfo;
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty("omit-xml-declaration", "yes");
        transformer.setOutputProperty("indent", "yes");
        
        StreamResult res = new StreamResult(new StringWriter());
        DOMSource source = new DOMSource(n);
        transformer.transform(source, res);
        event.getMessage().setInvocationProperty("cbrAttribSet", res.getWriter().toString());
        
        return event;
      }
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
    return event;
  }
  
  static
  {
    try
    {
      XPathFactory xFactory = XPathFactory.newInstance();
      XPath xPath = xFactory.newXPath();
      expression0 = xPath.compile("//*[translate(local-name(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='rulesbag']");
    }
    catch (Exception e)
    {
      e.printStackTrace();
    }
  }
}

