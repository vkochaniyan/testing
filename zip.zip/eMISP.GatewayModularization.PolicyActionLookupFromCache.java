package com.bac.component;

import java.util.List;
import java.util.Map;
import java.util.concurrent.locks.ReadWriteLock;
import java.util.concurrent.locks.ReentrantReadWriteLock;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tools.ant.types.FileList.FileName;
import org.ehcache.Cache;
import org.ehcache.spi.loaderwriter.CacheWritingException;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.util.StringUtils;
import com.bac.cache.framework.ConfigCacheManager;

/**
 * @author ZKZBQ23 Lookup from ehCache
 *
 */
public class PolicyActionLookupFromCache implements Callable {

	private static final Logger logger = LogManager.getLogger();

	private static String HIPHEN_POLICYACTION_DOT_JSON = "-policy-action.json";
	private static String PROVIDER_AIT = "providerAIT";
	private static String SMSESSIONSPEC = "SMSessionSpec";
	private static String SMSESSION = "SMSession";
	private static String HEADER_NAME = "headerName";
	private static String SERVICE_NAME = "serviceName";
	private static String TOKEN = "token";
	private static String HEADER = "header";
	private static String TOKEN_NAME = "tokenName";

	private String samlServiceNameMissing = null;
	private String samlTokenNameInvalid = null;
	private String samlHeaderNameMissing = null;
	private ConfigCacheManager configCacheManager;

	/**
	 * @param samlServiceNameMissing
	 *            String
	 * @param samlTokenNameMissing
	 *            String
	 * @param samlHeaderNameMissing
	 *            String
	 */
	public PolicyActionLookupFromCache(String samlServiceNameMissing, String samlHeaderNameMissing,
			String samlTokenNameMissing) {
		this.samlServiceNameMissing = samlServiceNameMissing;
		this.samlHeaderNameMissing = samlHeaderNameMissing;
		this.samlTokenNameInvalid = samlTokenNameMissing;

	}

	public void setConfigCacheManager(ConfigCacheManager configCacheManager) {
		this.configCacheManager = configCacheManager;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * org.mule.api.lifecycle.Callable#onCall(org.mule.api.MuleEventContext)
	 */
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {

		logger.debug("onCall start");

		boolean isSAMLRequired = false;

		MuleMessage message = eventContext.getMessage();

		// Get a ReadLock on cache
		Cache<String, Object> ehCache = configCacheManager.getConfigCache();

		ReadWriteLock lock = new ReentrantReadWriteLock();
		List<Map<String, Object>> tokenCheckList = null;
		try {
			lock.readLock().lock();
			String providerAIT = message.getOutboundProperty(PROVIDER_AIT);

			logger.debug("providerAIT:" + providerAIT);

			String fileName = providerAIT + HIPHEN_POLICYACTION_DOT_JSON;

			logger.debug("fileName: " + fileName);

			tokenCheckList = (List<Map<String, Object>>) ehCache.get(fileName);

			logger.debug("Token Check Object got from Cache: " + tokenCheckList);
		} catch (CacheWritingException exception) {
			logger.error("ERROR IN GETTING VALUES FROM EHCACHE:  " + exception);
			exception.printStackTrace();
		} finally {
			lock.readLock().unlock();
		}

		boolean isServiceNameMatched = false;
		if (tokenCheckList != null && tokenCheckList.size() > 0) {
			for (int i = 0; i <= tokenCheckList.size(); i++) {
				Map<String, Object> map = tokenCheckList.get(i);
				List<String> serviceList = null;
				if(map.containsKey(SERVICE_NAME)){
				serviceList = (List<String>) map.get(SERVICE_NAME);
				}
				else{
					logger.error("Missing serviceName key in SAML token check configuration on HTTP server or in Cache");
				}
				for (int j = 0; j <= serviceList.size(); j++) {
					String name = serviceList.get(j);
			
					String serviceName = message.getOutboundProperty(SERVICE_NAME);
					logger.debug("Request serviceName: " + serviceName);

					if (name.equalsIgnoreCase(serviceName)) {
						logger.debug("Service Name matched");
						isServiceNameMatched = true;
						Map<String, Object> tokenMap = null;
						if(map.containsKey(TOKEN)){
						tokenMap = (Map<String, Object>) map.get(TOKEN);
						}
						else{
							logger.error("Missing token key on HTTP server or in cache for the service Name: " + serviceName);
						}
						String tokenName = null;
						if(tokenMap.containsKey(TOKEN_NAME)){
						tokenName = (String) tokenMap.get(TOKEN_NAME);
						}else{
							logger.error("Missing tokenName key on HTTP server or in cache for the service Name: " + serviceName);
						}
						message.setOutboundProperty("tokenName", tokenName);
						logger.debug("token Name: " + tokenName);
						if (tokenName.equalsIgnoreCase(SMSESSIONSPEC) || tokenName.equalsIgnoreCase(SMSESSION)) {
							logger.info("SAML token generation is required for the service: " + serviceName);
							isSAMLRequired = true;
							Map<String, Object> headerMap = null;
							if(tokenMap.containsKey(HEADER)){
							headerMap = (Map<String, Object>) tokenMap.get(HEADER);
							}else{
								logger.error("Missing header key on HTTP server or in cache for the serviceName: "+serviceName);
							}
							
							String headerName = null;
							if(headerMap.containsKey(HEADER_NAME)){
							headerName = (String) headerMap.get(HEADER_NAME);
							logger.info("header name: " + headerName);
							}else{
								logger.error("Misisng headerName key on HTTP server or in cache for the service name: "+serviceName);
							}
							
							if (StringUtils.isNotEmpty(headerName)) {
								message.setOutboundProperty("headerName", headerName);
							} else {
								logger.error(samlHeaderNameMissing);
								throw new Exception(samlHeaderNameMissing);
							}
						} else {
							logger.error(samlTokenNameInvalid);
							throw new Exception(samlTokenNameInvalid);
						}
					} else {
						logger.error(samlServiceNameMissing);
						throw new Exception(samlServiceNameMissing);
					}
					if (isServiceNameMatched == true) {
						break;
					}
				}
				if (isSAMLRequired == true) {
					break;
				}
			}
		}
		logger.debug("isSAMLRequired: " + isSAMLRequired);
		logger.debug("onCall end");
		return isSAMLRequired;
	}

}