package com.mulesoft.mule.boa.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;

public class InboundPropertySetter implements Callable {

	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		
		MuleMessage message = eventContext.getMessage();
		String[] ignoreProperties = null;
		List<String> ignorePropertyList = new ArrayList<String>();
		if(message.getInboundProperty("ignoreProperties")!=null){
			String ignoreProperty = (String)message.getInboundProperty("ignoreProperties");
			ignoreProperties = ignoreProperty.split(",");
			ignorePropertyList = Arrays.asList(ignoreProperties);
		}
		
		Set<String> inboundProperties = eventContext.getMessage().getInboundPropertyNames();
		Iterator<String> inboundPropertiesIterator = inboundProperties.iterator();
		while(inboundPropertiesIterator.hasNext()){
			String inboundProperty = (String)inboundPropertiesIterator.next();
			if(!ignorePropertyList.contains(inboundProperty)){
				message.setInvocationProperty(inboundProperty, message.getInboundProperty(inboundProperty));
			}
		}
		return eventContext.getMessage().getPayload();
	}

}
