package com.mulesoft.mule.boa.vo;

import java.util.List;

public class SorRecurrenceVO implements java.io.Serializable {

	public static final int  DAILY = 1;
	public static final int  WEEKLY = 2;
	
	private static final long serialVersionUID = -1318543358398776270L;
	
	private int type;
	private List<Integer> weeks;
	private String startTimeInGMT;
	private String endTimeInGMT;
	private String startDate;
	private String endDate;
	private String sor;
	

	
	public SorRecurrenceVO() {
		
	}
	
    public SorRecurrenceVO(int type, String startTime, String endTime, String startDate, String endDate,String sor, List<Integer> weeks) {
		this.type = type;
		this.startTimeInGMT = startTime;
		this.endTimeInGMT = endTime;
		this.startDate = startDate;
		this.endDate = endDate;
		this.sor = sor;
		this.weeks = weeks;
	}
	
    public SorRecurrenceVO(int type, String startTime, String endTime, String startDate, String endDate,String sor) {
    	this(type, startTime, endTime, startDate, endDate, sor, null);
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public List<Integer> getWeeks() {
		return weeks;
	}

	public void setWeeks(List<Integer> weeks) {
		this.weeks = weeks;
	}

	public String getStartTimeInGMT() {
		return startTimeInGMT;
	}

	public void setStartTimeInGMT(String startTime) {
		this.startTimeInGMT = startTime;
	}

	public String getEndTimeInGMT() {
		return endTimeInGMT;
	}

	public void setEndTimeInGMT(String endTime) {
		this.endTimeInGMT = endTime;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public String getEndDate() {
		return endDate;
	}

	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	public String getSor() {
		return sor;
	}

	public void setSor(String sor) {
		this.sor = sor;
	}
    
	@Override public String toString() {
		StringBuilder sb = new StringBuilder();
		sb.append(startTimeInGMT + " - " + endTimeInGMT + ", " + startDate + " - " + endDate);
		if (type == DAILY) {
			sb.append(" Daily");
		} else {
			sb.append(" Weekly");
		}
		return sb.toString();
	}
	
}
