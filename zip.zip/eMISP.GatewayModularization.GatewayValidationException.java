package com.bac.exceptions;

public class GatewayValidationException extends Exception 
{
	
	private static final long serialVersionUID = -1576249866275605227L;	
	
	private String message;
	private String errorCode;

	public GatewayValidationException(){
		
	}
	
	public GatewayValidationException(String message){
		
		if(message!=null && message.indexOf("~")!=-1){
			String[] messageContents = message.split("~");
			this.message = messageContents[0];
			this.errorCode = messageContents[1];
		}
		else{
			this.message = message;
		}
	}

	public String getMessage(){
		return message;
	}
	
	public String getErrorCode(){
		return errorCode;
	}
}
