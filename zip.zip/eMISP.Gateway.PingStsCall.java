package com.mulesoft.mule.boa;

import java.io.InputStream;
import java.io.StringWriter;
import java.security.Key;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.security.auth.x500.X500PrivateCredential;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transformer.TransformerException;
import org.mule.el.datetime.DateTime;
import org.w3c.dom.Element;

import com.pingidentity.sts.clientapi.STSClient;
import com.pingidentity.sts.clientapi.STSClientConfiguration;
import com.pingidentity.sts.clientapi.tokens.saml.Saml20Token;
import com.pingidentity.sts.clientapi.tokens.saml.SamlToken;
import com.pingidentity.sts.clientapi.utils.StringUtils;
import com.mulesoft.mule.boa.util.PingSTSGetConfigValues;
public class PingStsCall implements Callable{
	
	@Override
    public Object onCall(MuleEventContext eventContext) throws Exception {
		Element samlToken = null;
		StringUtils utils = new StringUtils();
		String returnPayload = null;
		
		InputStream cacheStream = null;
		
		try {	
			HashMap<String, String> map = eventContext.getMessage().getInvocationProperty("cMap");
			//String serviceID = map.get("ServiceID");
			String tokenappliesTo = PingSTSGetConfigValues.tokenAppliesTo();//"https://soa.bankofamerica.com/serviceonbehalf_v001";
			String stsFQDN = PingSTSGetConfigValues.pingStsUrl();//"https://sts-int-tt.bankofamerica.com/idp/sts.wst";
			String filename = PingSTSGetConfigValues.filename();//"src/main/resources/53561_nonprod_ICA_SHA2_exp72217.pfx";
			String keystorePwd = PingSTSGetConfigValues.keystorePwd();//"eibrul3s";
			String alias = PingSTSGetConfigValues.keyAlias();//"1";
			String certType = PingSTSGetConfigValues.certType();
			String serviceID= (map.get("ServiceID")==null)? PingSTSGetConfigValues.serviceID() : map.get("ServiceID"); //DMT59656
			String certProvider= PingSTSGetConfigValues.certProvider();//SunJSSE
			String p8TokenAppliesTo = PingSTSGetConfigValues.p8tokenAppliesTo();	
	        // Configure STS Client (IdP side / SP Connection)
	        STSClientConfiguration stsConfigurationToken = new STSClientConfiguration();
	        stsConfigurationToken.setIgnoreSSLTrustErrors(true);
	        stsConfigurationToken.setAppliesTo(tokenappliesTo);
	        stsConfigurationToken.setStsEndpoint(stsFQDN);
	        stsConfigurationToken.setInTokenType(STSClientConfiguration.TokenType.X509);
	        
	        Map<String,String> reqMap = new HashMap<String,String>();
	        reqMap.put("ait", serviceID);
	        stsConfigurationToken.setRequestParameters(reqMap);
	      
	        // Instantiate the STSClient
	        STSClient stsClient = new STSClient(stsConfigurationToken);        
	        //String type = "pkcs12";

	        KeyStore ks = KeyStore.getInstance(certType, certProvider);
	        cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(filename);
			ks.load(cacheStream, keystorePwd.toCharArray());
	
	        X509Certificate cc = (X509Certificate) ks.getCertificate(alias); 
        
	        Key privateKey = ks.getKey(alias, keystorePwd.toCharArray());
	        X500PrivateCredential privateCred = new X500PrivateCredential(cc, (PrivateKey) privateKey);       
	        HashMap<String, String> cMap = eventContext.getMessage().getInvocationProperty("cMap");
	        Date d1 = null;
	        Date d2 = null;
	        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	        String PingFirstReqEntryTime  = new org.mule.el.datetime.DateTime().format("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	        System.out.println("The PingFirstReqEntryTime is " +PingFirstReqEntryTime);
	       	cMap.put("PingFirstReqEntryTime", new org.mule.el.datetime.DateTime().format("yyyy-MM-dd'T'HH:mm:ss.SSSZ"));
	       	cMap.put("PingFirstReqStatus", "Success");	       	
	       	try{
	       		samlToken = stsClient.issueToken(privateCred);   // first response
	       	}catch(Exception e){
	       		cMap.put("PingFirstReqErrCode", "500");
	       		cMap.put("PingFirstReqErrMsg", e.getMessage());
	       		cMap.put("PingFirstReqStatus", "Failed");
	       		e.printStackTrace();
	       	}
	        String PingFirstResEntryTime  = new org.mule.el.datetime.DateTime().format("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	        System.out.println("The PingFirstResEntryTime is " +PingFirstResEntryTime);
	        d1 = format.parse(PingFirstReqEntryTime);
	        d2 = format.parse(PingFirstResEntryTime);
	        long diff = d2.getTime() - d1.getTime();
	        cMap.put("PingFirstResEntryTime", PingFirstResEntryTime);
	        cMap.put("PingFirstResDelta", String.valueOf(diff));
	        System.out.println("The response time is " +diff);
	        
	        cMap.put("PingCall1",stsFQDN);
	        STSClientConfiguration stsWSP = new STSClientConfiguration();
	        stsWSP.setStsEndpoint(stsFQDN);
	    	stsWSP.setAppliesTo(p8TokenAppliesTo);
	    	stsWSP.setOutTokenType(STSClientConfiguration.TokenType.SAML2);
	        stsWSP.setIgnoreSSLTrustErrors(true);
	        
	        STSClient provider = new STSClient(stsWSP);
	        SamlToken samltoken = new Saml20Token(samlToken);
	        Date d3 = null;
	        Date d4 = null;
	        Element smtoken = null;
	        String PingSecondReqEntryTime  = new org.mule.el.datetime.DateTime().format("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	        System.out.println("The PingSecondReqEntryTime is " +PingSecondReqEntryTime);
	        cMap.put("PingSecondReqEntryTime", new org.mule.el.datetime.DateTime().format("yyyy-MM-dd'T'HH:mm:ss.SSSZ"));
	        try{
	        smtoken = provider.issueToken(samltoken); // second response
	        }catch(Exception e){
	        	cMap.put("PingSecondReqErrCode", "500");
	       		cMap.put("PingSecondReqErrMsg", e.getMessage());
	       		cMap.put("PingSecondReqStatus", "Failed");	
	       		e.printStackTrace();
	        }
	        String PingSecondResEntryTime  = new org.mule.el.datetime.DateTime().format("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	        System.out.println("The PingSecondResEntryTime is " +PingSecondResEntryTime);
	        d3 = format.parse(PingSecondReqEntryTime);
	        d4 = format.parse(PingSecondResEntryTime);
	        long diff1 = d4.getTime() - d3.getTime();
	        System.out.println("The response time for second pingSTS is " +diff1);
	        cMap.put("PingSecondResEntryTime", PingSecondResEntryTime);
	        cMap.put("PingSecondResDelta", String.valueOf(diff1));
	        cMap.put("PingCall2",p8TokenAppliesTo);
	        returnPayload = utils.prettyPrint(smtoken);
		} 
		catch (Exception e){
			e.printStackTrace();
		}
		return returnPayload;
	}

	public static String getOuterXml(Element token)
	    throws TransformerConfigurationException, TransformerException
	{
	    Transformer transformer = TransformerFactory.newInstance().newTransformer();
	    transformer.setOutputProperty("omit-xml-declaration", "yes");

	    StringWriter writer = new StringWriter();
	    try {
			transformer.transform(new DOMSource(token), new StreamResult(writer));
		} catch (javax.xml.transform.TransformerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	    return writer.toString();         
	}
}