package com.bac.hli.ddis;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class SplunkReportObject {
	private String sourceIP, appID, traceId, sessionId, GUID, GSID;
	private Calendar startTS;
	private int HTTPstatusCode, responseLength, duration;
	private List<SysPerf> sysPerfList;

	class SysPerf {
		private String service, operation;
		private Calendar startTime;
		private int duration;

		public SysPerf() {
			service = "";
			operation = "";
			startTime = Calendar.getInstance();
			duration = 0;
		}

		public SysPerf(String service, String operation) {
			this.service = service;
			this.operation = operation;
			this.startTime = Calendar.getInstance();
			this.duration = 0;
		}

		public SysPerf(String service, String operation, Calendar startTime, int duration) {
			this.service = service;
			this.operation = operation;
			this.startTime = startTime;
			this.duration = duration;
		}

		public String getService() {
			return this.service;
		}

		public String getOperation() {
			return this.operation;
		}

		public void setDuration() {
			this.duration = (int)(System.currentTimeMillis() - this.startTime.getTimeInMillis());
		}

		public String toString() {
			return this.service+":"+this.operation+"="+this.startTime.getTimeInMillis()+":"+this.duration;
		}
	}

	public SplunkReportObject() {
		sourceIP = "";
		appID = "";
		traceId = "";
		sessionId = "";
		GUID = "";
		GSID = "";
		startTS = Calendar.getInstance();
		HTTPstatusCode = -1;
		responseLength = 0;
		duration = 0;
		sysPerfList = new ArrayList<SysPerf>();
	}

	public SplunkReportObject(String sourceIP, String appID, String traceId) {
		this.sourceIP = sourceIP;
		this.appID = appID;
		this.traceId = traceId;
		sessionId = "";
		GUID = "";
		GSID = "";
		startTS = Calendar.getInstance();
		HTTPstatusCode = -1;
		responseLength = 0;
		duration = 0;
		sysPerfList = new ArrayList<SysPerf>();
	}

	public void startSysPerf(String service, String operation) {
		SysPerf sp = new SysPerf(service, operation);
		sysPerfList.add(sp);
	}

	public void endSysPerf(String service, String operation) {
		for(SysPerf s:sysPerfList) {
			if ( service.equals(s.getService()) && operation.equals(s.getOperation()) ) 
				s.setDuration();
		}
	}

	public void setSysPerf(String service, String operation, Calendar startTime, int duration) {
		SysPerf sp = new SysPerf(service, operation, startTime, duration);
		sysPerfList.add(sp);
	}

	public void end() {
		this.HTTPstatusCode = 0;
		this.responseLength = 0;
		this.duration = (int)(System.currentTimeMillis() - this.startTS.getTimeInMillis());
	}

	public void end(int HTTPstatusCode, int responseLength) {
		this.HTTPstatusCode = HTTPstatusCode;
		this.responseLength = responseLength;
		this.duration = (int)(System.currentTimeMillis() - this.startTS.getTimeInMillis());
	}

	public String toString() {
		StringBuffer sb = new StringBuffer("");
		sb.append(this.sourceIP + "|");
		sb.append(this.appID + "|");
		sb.append(
				this.startTS.get(Calendar.YEAR)+"/"+
				(this.startTS.get(Calendar.MONTH)+1)+"/"+
				this.startTS.get(Calendar.DATE)+" "+
				this.startTS.get(Calendar.HOUR_OF_DAY)+"/"+
				this.startTS.get(Calendar.MINUTE)+"/"+
				this.startTS.get(Calendar.SECOND)+"/"+
				this.startTS.get(Calendar.MILLISECOND)+"|"
				);
		sb.append("|");
		sb.append(HTTPstatusCode+"|");
		sb.append(responseLength+"|");
		sb.append(duration+"|");
		sb.append(traceId+"|");
		sb.append(GUID+"|");
		sb.append(GSID+"|");
		for(SysPerf s:sysPerfList) {
			sb.append(s);
		}
		return sb.toString();
	}
}
