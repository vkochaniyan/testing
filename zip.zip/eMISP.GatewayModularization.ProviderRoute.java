package com.bac.vo;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "service", "route" })
public class ProviderRoute {

	@JsonProperty("serviceAndBaseUri")
	private List<serviceAndBaseUri> serviceAndBaseUri = new ArrayList<serviceAndBaseUri>();
	@JsonProperty("route")
	private List<Route> route = new ArrayList<Route>();

	/**
	 * 
	 * @return The service
	 */
	@JsonProperty("serviceAndBaseUri")
	public List<serviceAndBaseUri> getServiceAndBaseUri() {
		return serviceAndBaseUri;
	}

	/**
	 * 
	 * @param service
	 *            The service
	 */
	@JsonProperty("serviceAndBaseUri")
	public void setService(List<serviceAndBaseUri> serviceAndBaseUri) {
		this.serviceAndBaseUri = serviceAndBaseUri;
	}

	/**
	 * 
	 * @return The route
	 */
	@JsonProperty("route")
	public List<Route> getRoute() {
		return route;
	}

	/**
	 * 
	 * @param route
	 *            The route
	 */
	@JsonProperty("route")
	public void setRoute(List<Route> route) {
		this.route = route;
	}

}
