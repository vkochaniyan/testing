/**
 * 
 */
package com.bac.cache.framework;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.ehcache.Cache;
import org.ehcache.CacheManager;

/**
 * @author ZKWQBHO
 *
 */
public class WsdlCacheManager implements ICacheManager {

	private static final Logger logger = LogManager.getLogger();
	Cache<String, Object> ehCache;
	CacheManager ehCacheMgr;
	WsdlObjectBuilder wsdlObjectBuilder;

	String wsdlPath;
	String wsdlIndexPath;
	CacheSSLConnector cacheSSLConnector;
	String env;
	
	public WsdlCacheManager() {
	}
	
	public CacheSSLConnector getCacheSSLConnector() {
		return cacheSSLConnector;
	}

	public void setCacheSSLConnector(CacheSSLConnector cacheSSLConnector) {
		this.cacheSSLConnector = cacheSSLConnector;
	}

	@SuppressWarnings("unused")
	private String getWsdlIndexPath() {
		return wsdlIndexPath;
	}

	public void setWsdlIndexPath(String wsdlConfigPath) {
		this.wsdlIndexPath = wsdlConfigPath;
	}

	public void setWsdlPath(String wsdlPath) {
		this.wsdlPath = wsdlPath;
	}

	@SuppressWarnings("unused")
	private String getWsdlPath() {
		return wsdlPath;
	}

	public CacheManager getEhCacheMgr() {
		return ehCacheMgr;
	}

	public void setEhCacheMgr(CacheManager ehCacheMgr) {
		this.ehCacheMgr = ehCacheMgr;
	}

	public WsdlObjectBuilder getWsdlObjectBuilder() {
		return wsdlObjectBuilder;
	}

	public void setWsdlObjectBuilder(WsdlObjectBuilder wsdlObjectBuilder) {
		this.wsdlObjectBuilder = wsdlObjectBuilder;
	}

	public Cache<String, Object> getWsdlCache() {
		return ehCache;
	}

	public void setCache(Cache<String, Object> wsdlCache) {
		this.ehCache = wsdlCache;
	}
	
	public String getEnv() {
		return env;
	}

	public void setEnv(String env) {
		this.env = env;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bac.cache.framework.CacheManager#loadCache()
	 */
	@Override
	public void loadCache() throws Exception {
		logger.debug(" In LoadCache() ");
		ehCache = ehCacheMgr.getCache("wsdlCache", String.class, Object.class);
	
		WsdlObjectBuilder wsdlObjectBuilder = new WsdlObjectBuilder(wsdlPath, wsdlIndexPath, cacheSSLConnector, env);
		wsdlObjectBuilder.build(ehCache);
		setCache(ehCache);
		logger.debug(" WSDL CACHE STATUS --> " + ehCacheMgr.getStatus().toString());
		logger.debug("NEW CACHE CREATED");

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.bac.cache.framework.CacheManager#refreshCache()
	 */
	@Override
	public void refreshCache() throws Exception {
		logger.debug(" In RefreshCache() ");
		ehCache = ehCacheMgr.getCache("wsdlCache", String.class, Object.class);

		WsdlObjectBuilder wsdlObjectBuilder = new WsdlObjectBuilder(wsdlPath, wsdlIndexPath, cacheSSLConnector, env);
		wsdlObjectBuilder.build(ehCache);

		logger.debug("RefreshCache() -> SCHEMA CACHE STATUS -> " + ehCacheMgr.getStatus().toString());
		logger.debug("CACHE REFRESHED !!");

	}

}
