package com.bac.component;

import java.io.InputStream;
import java.security.Key;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.cert.X509Certificate;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.security.auth.x500.X500PrivateCredential;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.w3c.dom.Element;

import com.bac.util.PingSTSGetConfigValues;
import com.pingidentity.sts.clientapi.STSClient;
import com.pingidentity.sts.clientapi.STSClientConfiguration;
import com.pingidentity.sts.clientapi.tokens.saml.Saml20Token;
import com.pingidentity.sts.clientapi.tokens.saml.SamlToken;
import com.pingidentity.sts.clientapi.utils.StringUtils;
public class PingStsCall implements Callable{
	
	@Override
    public Object onCall(MuleEventContext eventContext) throws Exception {
		final Logger logger = LogManager.getLogger();

		Element samlToken = null;
		StringUtils utils = new StringUtils();
		String returnPayload = null;
		
		InputStream cacheStream = null;
		
		try {	
			String serviceID = PingSTSGetConfigValues.serviceID();//DMT59656
			String tokenappliesTo = PingSTSGetConfigValues.tokenAppliesTo();//"https://soa.bankofamerica.com/serviceonbehalf_v001";
			String stsFQDN = PingSTSGetConfigValues.pingStsUrl();//"https://sts-int-tt.bankofamerica.com/idp/sts.wst";
			String filename = PingSTSGetConfigValues.filename();//"src/main/resources/53561_nonprod_ICA_SHA2_exp72217.pfx";
			
			MuleMessage message = eventContext.getMessage();
			String keystorePwd = message.getInvocationProperty("keystorePwd");
			
			String alias = PingSTSGetConfigValues.keyAlias();//"1";
			String certType = PingSTSGetConfigValues.certType();
			String certProvider= PingSTSGetConfigValues.certProvider();//SunJSSE
			String p8TokenAppliesTo = PingSTSGetConfigValues.p8tokenAppliesTo();	
	       
			// Configure STS Client (IdP side / SP Connection)
	        STSClientConfiguration stsConfigurationToken = new STSClientConfiguration();
	        stsConfigurationToken.setIgnoreSSLTrustErrors(true);
	        stsConfigurationToken.setAppliesTo(tokenappliesTo);
	        stsConfigurationToken.setStsEndpoint(stsFQDN);
	        stsConfigurationToken.setInTokenType(STSClientConfiguration.TokenType.X509);
	        
	        Map<String,String> reqMap = new HashMap<String,String>();
	        reqMap.put("ait", serviceID);
	        stsConfigurationToken.setRequestParameters(reqMap);
	      
	        // Instantiate the STSClient
	        STSClient stsClient = new STSClient(stsConfigurationToken);        
	       
	        KeyStore ks = KeyStore.getInstance(certType, certProvider);
	        cacheStream = Thread.currentThread().getContextClassLoader().getResourceAsStream(filename);
			ks.load(cacheStream, keystorePwd.toCharArray());
	
	        X509Certificate cc = (X509Certificate) ks.getCertificate(alias); 
        
	        Key privateKey = ks.getKey(alias, keystorePwd.toCharArray());
	        X500PrivateCredential privateCred = new X500PrivateCredential(cc, (PrivateKey) privateKey);       
	        
	        Date d1 = null;
	        Date d2 = null;
	        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	        String PingFirstReqEntryTime  = new org.mule.el.datetime.DateTime().format("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	        logger.info("The PingFirstReqEntryTime is " +PingFirstReqEntryTime);
	        
	        try{
	       		samlToken = stsClient.issueToken(privateCred);   // first response
	       	}catch(Exception exc){
	       		logger.error("SAML Token first response exception:  " + exc);
	       		exc.printStackTrace();
	       	}
	        String PingFirstResEntryTime  = new org.mule.el.datetime.DateTime().format("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	        logger.info("The PingFirstResEntryTime is " +PingFirstResEntryTime);
	        d1 = format.parse(PingFirstReqEntryTime);
	        d2 = format.parse(PingFirstResEntryTime);
	        long diff = d2.getTime() - d1.getTime();
	        logger.info("The response time is " +diff);
	        
	        STSClientConfiguration stsWSP = new STSClientConfiguration();
	        stsWSP.setStsEndpoint(stsFQDN);
	    	stsWSP.setAppliesTo(p8TokenAppliesTo);
	    	stsWSP.setOutTokenType(STSClientConfiguration.TokenType.SAML2);
	        stsWSP.setIgnoreSSLTrustErrors(true);
	        
	        STSClient provider = new STSClient(stsWSP);
	        SamlToken samltoken = new Saml20Token(samlToken);
	        Date d3 = null;
	        Date d4 = null;
	        Element smtoken = null;
	        String PingSecondReqEntryTime  = new org.mule.el.datetime.DateTime().format("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	        logger.info("The PingSecondReqEntryTime is " +PingSecondReqEntryTime);
	     
	        try{
	        smtoken = provider.issueToken(samltoken); // second response
	        logger.info("smtoken: "+smtoken);
	        }catch(Exception exception){
	        	logger.error("SAML Token second response exception:  " + exception);
	        	exception.printStackTrace();
	        }
	        String PingSecondResEntryTime  = new org.mule.el.datetime.DateTime().format("yyyy-MM-dd'T'HH:mm:ss.SSSZ");
	        logger.info("The PingSecondResEntryTime is " +PingSecondResEntryTime);
	        d3 = format.parse(PingSecondReqEntryTime);
	        d4 = format.parse(PingSecondResEntryTime);
	        long diff1 = d4.getTime() - d3.getTime();
	        logger.info("The response time for second pingSTS is " +diff1);
	        returnPayload = utils.prettyPrint(smtoken);
	        logger.info("return Payload: "+returnPayload);
		} 
		catch (Exception e){
			e.printStackTrace();
		}
		return returnPayload;
	}
	
}