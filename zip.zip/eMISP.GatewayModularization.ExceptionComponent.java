package com.bac.exceptions;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transport.PropertyScope;
import org.mule.message.DefaultExceptionPayload;

@SuppressWarnings("unused")
public class ExceptionComponent implements Callable 
{

	//final String SOAP_ACTION = "SOAPAction";
	final String OPERATION = "X-BOA-Provider-Operation";
	final String TRACE_ID = "X-BOA-Trace-Id";
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {

		MuleMessage message = eventContext.getMessage();
		
		String operation = message.getInboundProperty(OPERATION);
		String traceId = message.getInboundProperty(TRACE_ID);
		DefaultExceptionPayload exceptionPayload = (DefaultExceptionPayload)message.getExceptionPayload();
		
		String exceptionMessage = exceptionPayload.getException().getCause().getMessage();
		String errorMessage = null;
		String errorCode = null;
		if(exceptionMessage!=null && exceptionMessage.indexOf("~")!=-1){
			String[] messageContents = exceptionMessage.split("~");
			errorMessage = messageContents[0];
			errorCode = messageContents[1];
		}else{
			errorMessage = exceptionMessage;
		}
		message.setProperty("ResponseFaultErrorMsg", errorMessage, PropertyScope.INVOCATION);
		message.setProperty("ResponseFaultCode", errorCode, PropertyScope.INVOCATION);
		
		return message;
	}
}
