/**
 * 
 */
package com.bac.cache.framework;

/**
 * @author ZKWQBHO
 *
 */
public interface ICommand {
	
	public void execute() throws Exception;

}
