package com.mulesoft.mule.boa;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Map;

import org.mule.api.MuleEventContext;
import org.mule.api.MuleMessage;
import org.mule.api.lifecycle.Callable;
import org.mule.api.transport.PropertyScope;

import com.mulesoft.mule.boa.vo.PolicyActionVO;
import com.mulesoft.mule.boa.vo.HttpToMqVO;


public class SetMqPubHeaders implements Callable {
	
	@Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
		
		/**
		 * Set MQ headers by the configuration in PolicyACtion file
		 */
		MuleMessage message = eventContext.getMessage();
		PolicyActionVO policyVO = (PolicyActionVO) message.getPayload();
		Map<String, String> mqHeaders = policyVO.getHttpToMqVO().getMqHeaders();
		
		message.clearProperties(PropertyScope.OUTBOUND);
		for (Map.Entry<String, String> entry : mqHeaders.entrySet()) {
			String headerName = entry.getKey();
			String headerValue = entry.getValue();
			if (headerName.equals("emitTimeStamp")) {
				SimpleDateFormat formatter = new SimpleDateFormat(headerValue); 
				String formattedTime = formatter.format(Calendar.getInstance().getTime());
				message.setOutboundProperty(headerName, formattedTime);
				
			} else {
				message.setOutboundProperty(headerName, headerValue);
			}
		}

		
	    // set OutBoundRoute as topic:DMT/CII/CAPTURE/NEWBATCH/EDY/SIT3
		String topic = (String) message.getProperty("mqTopic", PropertyScope.INVOCATION);
		message.setProperty("OutBoundRoute", "topic:" + topic, PropertyScope.INVOCATION);
		return eventContext.getMessage().getPayload();
	}
}
