package work;

import java.util.ArrayList;
import java.util.LinkedHashMap;

public class Util {
	public LinkedHashMap updateProvider(LinkedHashMap lhm, String key, ArrayList<LinkedHashMap> al) {
		boolean updated = false;
		ArrayList<LinkedHashMap> collection = (ArrayList)lhm.get("collection");
		for(LinkedHashMap a: collection) {
			if ( !updated ) {
				LinkedHashMap b = (LinkedHashMap)a.get("providerRouteMasterKey");
				ArrayList<LinkedHashMap> keys = (ArrayList)b.get("keys");
/*
				for(LinkedHashMap d:keys) {
					System.out.println(d.get("name"));
				}
*/
				ArrayList<LinkedHashMap> route = (ArrayList)b.get("route");
/*
				for(LinkedHashMap f:route) {
					System.out.println("\t"+f.get("env")+":"+f.get("domain"));
				}
*/
				boolean flag = true;
				if (route.size() != al.size())
					flag = false;
				else {
					for(LinkedHashMap i:route) {
						flag = flag & compare(i,al);
					}
					for(LinkedHashMap j:al) {
						flag = flag & compare(j,route);
					}
				}
				if ( flag ) {
					LinkedHashMap<String,String> newKey = new LinkedHashMap<String,String>();
					newKey.put("name", key);
					keys.add(newKey);
					updated=true;
				}
			}
		}
		if ( !updated ) {
			LinkedHashMap<String,String> k = new LinkedHashMap<String,String>();
			k.put("name", key);
			ArrayList<LinkedHashMap> keys = new ArrayList<LinkedHashMap>();
			keys.add(k);

			LinkedHashMap<String,ArrayList> providerRouteMasterKey = new LinkedHashMap<String,ArrayList>();
			providerRouteMasterKey.put("keys", keys);
			providerRouteMasterKey.put("route", al);
			
			LinkedHashMap<String,LinkedHashMap> prmk = new LinkedHashMap<String,LinkedHashMap>();
			prmk.put("providerRouteMasterKey", providerRouteMasterKey);
			collection.add(prmk);
		}
		return lhm;
	}

	public boolean compare(LinkedHashMap x, ArrayList<LinkedHashMap> y) {
		boolean flag = true;
		String env = (String)x.get("env");
		String domain = (String)x.get("domain");
		String protocol = (String)x.get("protocol");
		String port = (String)x.get("port");
		for(LinkedHashMap z:y) {
			if ( ((String)z.get("env")).equalsIgnoreCase(env) ) {
				flag = ((String)z.get("env")).equalsIgnoreCase(env) & 
						((String)z.get("domain")).equalsIgnoreCase(domain) &
						((String)z.get("protocol")).equalsIgnoreCase(protocol) &
						((String)z.get("port")).equalsIgnoreCase(port);
			}
		}
		return flag;
	}
}
