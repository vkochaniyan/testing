package com.mulesoft.mule.boa.vo;

public class CBRLookupKey implements java.io.Serializable {
	
	private static final long serialVersionUID = -4765863294277602347L;
	private String serviceName;
	private String operation;
	private String sourceApplicationId;
	
	public CBRLookupKey(){
	}
	
	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public CBRLookupKey(String serviceName,String operation){
		this.serviceName = serviceName;
		this.operation = operation;
	}
	
	public CBRLookupKey(String serviceName,String operation,String sourceApplicationId){
		this.serviceName = serviceName;
		this.operation = operation;
		this.sourceApplicationId = sourceApplicationId;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((operation == null) ? 0 : operation.hashCode());
		result = prime * result
				+ ((serviceName == null) ? 0 : serviceName.hashCode());
		result = prime * result
				+ ((sourceApplicationId == null) ? 0 : sourceApplicationId.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CBRLookupKey other = (CBRLookupKey) obj;
		if (operation == null) {
			if (other.operation != null)
				return false;
		} else if (!operation.equals(other.operation))
			return false;
		if (serviceName == null) {
			if (other.serviceName != null)
				return false;
		} else if (!serviceName.equals(other.serviceName))
			return false;
		
		if (sourceApplicationId == null) {
			if (other.sourceApplicationId != null)
				return false;
		} else if (!sourceApplicationId.equals(other.sourceApplicationId))
			return false;
		
		
		
		return true;
	}

}
