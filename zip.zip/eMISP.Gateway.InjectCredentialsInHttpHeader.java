package com.mulesoft.mule.boa;

import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.processor.MessageProcessor;

public class InjectCredentialsInHttpHeader implements MessageProcessor {

	@Override
	public MuleEvent process(MuleEvent event) throws MuleException {
		try {
			
			String credentials = event.getFlowVariable("wsseUser") + ":" + event.getFlowVariable("wssePassword");
			String base64Credentials = "Basic " + new sun.misc.BASE64Encoder().encode(credentials.getBytes());
			event.setSessionVariable("Authorization", base64Credentials);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return event;

	}

}