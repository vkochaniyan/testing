package com.mulesoft.mule.boa;

import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.management.RuntimeErrorException;

import org.mule.DefaultMuleEvent;
import org.mule.MessageExchangePattern;
import org.mule.api.MuleContext;
import org.mule.api.MuleEventContext;
import org.mule.api.MuleException;
import org.mule.api.MuleMessage;
import org.mule.api.construct.FlowConstruct;
import org.mule.api.lifecycle.Callable;
import org.mule.construct.Flow;


public class DynamicFlowInjection implements Callable {
	
	private String contextName;
    
    @Override
	public Object onCall(MuleEventContext eventContext) throws Exception {
    	String sequence = (String)eventContext.getMessage().getInvocationProperty("sequence");
    	Map<String,Object> validationData = new HashMap<String,Object>();
    	
    	Set<String> invocationProperties = eventContext.getMessage().getInvocationPropertyNames();
		Iterator<String> invocationIterator = invocationProperties.iterator();
		while(invocationIterator.hasNext()){
			String property = (String)invocationIterator.next();
			validationData.put(property, eventContext.getMessage().getInvocationProperty(property));
		}
		
		if(sequence!=null && !sequence.trim().equals("")){
			
    		String[] sequenceStep = sequence.split(",");
    		for(int counter=0;counter<sequenceStep.length;counter++){
    			Flow flow = (Flow)getFlowConstruct(sequenceStep[counter],eventContext);
    			run(flow, eventContext.getMuleContext(),contextName, sequenceStep[counter], eventContext.getMessage(),validationData);
    		}
    	}
    	return eventContext.getMessage().getPayload();
	}
    
	@SuppressWarnings("deprecation")
	private MuleMessage run(Flow construct,MuleContext context,String contextName, String flowName, MuleMessage message,Map<String,Object> validateData) throws MuleException {
        
		DefaultMuleEvent event = new DefaultMuleEvent(message, MessageExchangePattern.REQUEST_RESPONSE, construct);
		Iterator validationIterator = validateData.entrySet().iterator();
		while (validationIterator.hasNext()) {
			Map.Entry<String,Object> pair = (Map.Entry<String,Object>)validationIterator.next();
			event.setFlowVariable(pair.getKey(), pair.getValue());
		}
		return construct.process(event).getMessage();
	}
	
	
	private Flow getFlowConstruct(String flowName, MuleEventContext eventContext) {
		Flow returnFlow = null;
		Collection<FlowConstruct> flowIterator = eventContext.getMuleContext().getRegistry().lookupFlowConstructs();
		Iterator<FlowConstruct> aIterator = flowIterator.iterator();
		while(aIterator.hasNext()){
			Flow flow = (Flow)aIterator.next();
			if(flow.getName().equals(flowName)){
				returnFlow = flow;
				break;
			}
		}
		if (returnFlow == null) throw new RuntimeErrorException(new Error("flow does not exist"));
        return returnFlow;
	}
		
}
