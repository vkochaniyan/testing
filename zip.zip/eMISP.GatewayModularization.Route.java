package com.bac.vo;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "env", "protocol", "domain", "port","sourceApplicationId" })
public class Route {

	@JsonProperty("env")
	private String env;
	@JsonProperty("protocol")
	private String protocol;
	@JsonProperty("domain")
	private String domain;
	@JsonProperty("port")
	private String port;
	@JsonProperty("sourceApplicationId")
	private String sourceApplicationId;

	/**
	 * 
	 * @return The env
	 */
	@JsonProperty("env")
	public String getEnv() {
		return env;
	}

	/**
	 * 
	 * @param env
	 *            The env
	 */
	@JsonProperty("env")
	public void setEnv(String env) {
		this.env = env;
	}

	/**
	 * 
	 * @return The protocol
	 */
	@JsonProperty("protocol")
	public String getProtocol() {
		return protocol;
	}

	/**
	 * 
	 * @param protocol
	 *            The protocol
	 */
	@JsonProperty("protocol")
	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	/**
	 * 
	 * @return The domain
	 */
	@JsonProperty("domain")
	public String getDomain() {
		return domain;
	}

	/**
	 * 
	 * @param domain
	 *            The domain
	 */
	@JsonProperty("domain")
	public void setDomain(String domain) {
		this.domain = domain;
	}

	/**
	 * 
	 * @return The port
	 */
	@JsonProperty("port")
	public String getPort() {
		return port;
	}

	/**
	 * 
	 * @param port
	 *            The port
	 */
	@JsonProperty("port")
	public void setPort(String port) {
		this.port = port;
	}

	/**
	 * @return the sourceApplicationId
	 */
	@JsonProperty("sourceApplicationId")
	public String getSourceApplicationId() {
		return sourceApplicationId;
	}

	/**
	 * @param sourceApplicationId the sourceApplicationId to set
	 */
	@JsonProperty("sourceApplicationId")
	public void setSourceApplicationId(String sourceApplicationId) {
		this.sourceApplicationId = sourceApplicationId;
	}

}