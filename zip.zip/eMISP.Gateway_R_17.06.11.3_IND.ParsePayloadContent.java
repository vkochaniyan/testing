package com.mulesoft.mule.boa;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.StringWriter;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPConstants;
import javax.xml.soap.SOAPMessage;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathFactory;

import org.mule.api.MuleEvent;
import org.mule.api.MuleException;
import org.mule.api.processor.MessageProcessor;
import org.w3c.dom.NodeList;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;

import org.w3c.dom.Document;
import org.w3c.dom.Node;

public class ParsePayloadContent implements MessageProcessor {

	private static XPathExpression expression0 = null;
    private static XPathExpression expression1 = null;
    private static XPathExpression expression2 = null;
    private static XPathExpression expression3 = null;
    private static XPathExpression expression4 = null;
    private static XPathExpression expression5 = null;
    

    @Override
	public MuleEvent process(MuleEvent event) throws MuleException {
		
		/** Set a default value**/
		HashMap<String, String> map = event.getFlowVariable("cMap");
		InputStream is = null;
		
		// Initialize
		map.put("cltServiceName", "");
	    map.put("cltOperation", "");
		map.put("cltSourceApplicationId", "");
		
		try 
		{
			if (event.getFlowVariable("IsHttpOverMq") != null && event.getFlowVariable("IsHttpOverMq").equals("true")) {
				
				String servicename = map.get("Notification_Events");
				String operation = "publish";
				
				if(map.get("Notification_Events") != null){
					 servicename = map.get("Notification_Events");
				}
				else if(map.get("MISP_PublishTopic") != null){
					String tempServiceName=map.get("MISP_PublishTopic");
					
					String[] part=tempServiceName.split("/");
					int length=part.length;
					System.out.println("no of parts in topic : "+ length);
					String svcNm="";
					for(int i=0; i<length-1;i++){
						svcNm = svcNm.concat(part[i].toString());
						if(i<length-2){
							svcNm = svcNm + "/";
						}
					}
					servicename=svcNm;
					 System.out.println("service name : "+servicename);
				}
				
				
				map.put("cltServiceName", servicename);
				map.put("cltOperation", operation);
				map.put("operationName", map.get("cltServiceName") + "_" + operation);
				System.out.println("Unified HTTP Over MQ Route. servicename=" + map.get("cltServiceName") + ", operation=" + map.get("cltOperation"));	
				return event;
			}
			
            if (event.getFlowVariable("IsGen4") != null && event.getFlowVariable("IsGen4").equals("true")) {
				
				String servicename = map.get("X-BOA-Provider-Service");
				String operation = map.get("X-BOA-Provider-Operation");
				String version = map.get("X-BOA-Provider-Service-Version");
				String sourceapplicationid = map.get("X-BOA-sourceApplicationId");
				if (servicename == null) {
					servicename = "";
				}
				if (operation == null) {
					operation = "";
				}
				if (sourceapplicationid == null) {
					sourceapplicationid = "";
				}
				if (version != null && version.length() > 0) {
					map.put("cltServiceName", servicename + "_" + version);
				} else {
					map.put("cltServiceName", servicename);
				}
				
				map.put("cltOperation", operation);
				map.put("cltSourceApplicationId", sourceapplicationid);
				map.put("operationName", map.get("cltServiceName") + "_" + operation);
				System.out.println("Unified Gen4 Route. servicename=" + map.get("cltServiceName") + ", operation=" + map.get("cltOperation") + ", sourceApplicationId=" + map.get("cltSourceApplicationId"));	
				
				return event;
			}
			
			String spayload = event.getMessage().getPayloadAsString();
			is = new ByteArrayInputStream(spayload.getBytes());
			
			if (event.getFlowVariable("IsGen2Osa") != null	&& event.getFlowVariable("IsGen2Osa").equals("true")) {
				String cltServiceName = event.getFlowVariable("cltServiceName");
				String cltOperation = event.getFlowVariable("cltOperation");
				String cltSourceApplicationId = event.getFlowVariable("cltSourceApplicationId");
				System.out.println("Unified osaRequestHeader Route. servicename=" + cltServiceName + ", operation=" + cltOperation + ", sourceApplicationId=" + cltSourceApplicationId);	
				map.put("cltServiceName", cltServiceName);
				map.put("cltOperation", cltOperation);
				map.put("cltSourceApplicationId", cltSourceApplicationId);
				map.put("operationName", cltServiceName + "_" + cltOperation);
				return event;
			} 
			
			if (event.getFlowVariable("IsSoap") != null	&& event.getFlowVariable("IsSoap").equals("true")) {
			
				try {
					setSOAPServiceNameOperation(is, map, SOAPConstants.SOAP_1_1_PROTOCOL);
				} catch (Exception e1) {
					setSOAPServiceNameOperation(is, map, SOAPConstants.SOAP_1_2_PROTOCOL);
				}
				System.out.println("Unified SOAP Route. servicename=" + map.get("cltServiceName") + ", operation=" + map.get("cltOperation") + ", sourceApplicationId=" + map.get("cltSourceApplicationId"));	
				map.put("operationName", map.get("cltServiceName") + "_" + map.get("cltOperation"));
				return event;
			}	
			
			if (event.getFlowVariable("IsUriRouting") != null	&& event.getFlowVariable("IsUriRouting").equals("true")) {
				String targetpod = event.getFlowVariable("X-BOA-PROVIDER-TARGET-POD");
				try {
					setSOAPServiceNameOperation(is, map, SOAPConstants.SOAP_1_1_PROTOCOL);					
				} catch (Exception e1) {
					setSOAPServiceNameOperation(is, map, SOAPConstants.SOAP_1_2_PROTOCOL);
				}
				System.out.println("Unified SOAP Route & URI based routing. servicename=" + map.get("cltServiceName") + ", operation=" + map.get("cltOperation") + ", targetpod=" + targetpod);	
				map.put("cltSourceApplicationId", targetpod);
				map.put("operationName", map.get("cltServiceName") + "_" + map.get("cltOperation"));
				return event;
			}
			
			if (event.getFlowVariable("IsXml") != null	&& event.getFlowVariable("IsXml").equals("true")) {
				DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			    factory.setNamespaceAware(true);
					     
				DocumentBuilder loader = factory.newDocumentBuilder();
				Document document = loader.parse(is);
				Node oname = document.getDocumentElement();
					    
				map.put("cltServiceName", oname.getLocalName());
			    map.put("cltOperation", map.get("HttpMethod"));
				map.put("cltSourceApplicationId", "");
				System.out.println("Unified XML Route. servicename=" + map.get("cltServiceName") + ", operation=" + map.get("cltOperation") + ", sourceApplicationId=" + map.get("cltSourceApplicationId"));	
				map.put("operationName", map.get("cltServiceName") + "_" + map.get("cltOperation"));
				return event;
			}
			
			// others
			System.out.println("Not supported request Route!");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return event;

	}
    
    private void setSOAPServiceNameOperation(InputStream is, HashMap<String, String> map, String SOAPVersion) throws Exception {
    	SOAPMessage soapMsg = MessageFactory.newInstance(SOAPVersion).createMessage(null, is);

    	Node firstChild = soapMsg.getSOAPBody().getFirstChild();
		String oprName = firstChild.getLocalName();
		String namespace = "";
		
		if (oprName != null) {
			map.put("cltOperation", oprName);
			namespace = firstChild.getNamespaceURI();
			map.put("cltServiceName", firstChild.getNamespaceURI());
		} else {
			oprName = firstChild.getNextSibling().getLocalName();
			namespace = firstChild.getNextSibling().getNamespaceURI();
		    map.put("cltOperation", oprName);
		    map.put("cltServiceName", namespace);
		}
		 map.put("cltSourceApplicationId", "");
	}
	
	public static String removeXmlStringNamespaceAndPreamble(String xmlString) {
		  return xmlString.replaceAll("(<\\?[^<]*\\?>)?", ""). /* remove preamble */
		  replaceAll("xmlns.*?(\"|\').*?(\"|\')", "") /* remove xmlns declaration */
		  .replaceAll("(<)(\\w+:)(.*?>)", "$1$3") /* remove opening tag prefix */
		  .replaceAll("(</)(\\w+:)(.*?>)", "$1$3"); /* remove closing tags prefix */
	}
	
	static{
		try{
			XPathFactory xFactory = XPathFactory.newInstance();
            XPath xPath = xFactory.newXPath();
            expression0 = xPath.compile("//*[translate(local-name(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='rulesbag']");
            expression1 = xPath.compile("//*[translate(local-name(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='rulesbag']/*[translate(local-name(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='sets']/*[translate(local-name(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='set']");
            expression2 = xPath.compile(".//*[translate(local-name(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='name']");
            expression3 = xPath.compile(".//*[translate(local-name(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='attributes']/*[translate(local-name(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='attribute']");
            expression4 = xPath.compile(".//*[translate(local-name(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='name']");
            expression5 = xPath.compile(".//*[translate(local-name(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz')='value']");
        }
        catch(Exception e){
        	e.printStackTrace();
        }
	}
}
