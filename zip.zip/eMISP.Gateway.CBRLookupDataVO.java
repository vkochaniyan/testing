package com.mulesoft.mule.boa.vo;

public class CBRLookupDataVO implements java.io.Serializable {
	
	private static final long serialVersionUID = -8638915377769314333L;
	private String routeName;
	private String targetNamespaceURI;
	private String orchestrationHeader;
	private String contentType;
	
	public CBRLookupDataVO(){
	}
	
	public CBRLookupDataVO(String targetNamespaceURI, String routeName, String orchestrationHeader){
		this.targetNamespaceURI = targetNamespaceURI;
		this.routeName = routeName;
		this.orchestrationHeader = orchestrationHeader;
	}
	
	public String getContentType() {
		return contentType;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	
	public String getOrchestrationHeader() {
		return orchestrationHeader;
	}

	public void setOrchestrationHeader(String orchestrationHeader) {
		this.orchestrationHeader = orchestrationHeader;
	}

	public String getRouteName() {
		return routeName;
	}
	public void setRouteName(String routeName) {
		this.routeName = routeName;
	}
	public String getTargetNamespaceURI() {
		return targetNamespaceURI;
	}
	public void setTargetNamespaceURI(String targetNamespaceURI) {
		this.targetNamespaceURI = targetNamespaceURI;
	}
	
	
	
}
