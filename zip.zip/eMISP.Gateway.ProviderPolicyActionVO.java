package com.mulesoft.mule.boa.vo;

public class ProviderPolicyActionVO {
	
	private String valueKey;
	private String tokenName;
	private String injectMethod;
	private String injectHeaderProtocol;
	private String injectHeaderType;
	private String injectHeaderProperty;
	private HttpToMqVO httpToMqVO;
	private LogEventsToMq logEventsToMq;
	
	public LogEventsToMq getLogEventsToMq(){
		return logEventsToMq;
	}
	public void setLogEventsToMq(LogEventsToMq logEventsToMq)
	{
		this.logEventsToMq = logEventsToMq;
	}
	public HttpToMqVO getHttpToMqVO() {
		return httpToMqVO;
	}
	public void setHttpToMqVO(HttpToMqVO httpToMqVO) {
		this.httpToMqVO = httpToMqVO;
	}
	public String getValueKey() {
		return valueKey;
	}
	public void setValueKey(String valueKey) {
		this.valueKey = valueKey;
	}
	public String getTokenName() {
		return tokenName;
	}
	public void setTokenName(String tokenName) {
		this.tokenName = tokenName;
	}
	public String getInjectMethod() {
		return injectMethod;
	}
	public void setInjectMethod(String injectMethod) {
		this.injectMethod = injectMethod;
	}
	public String getInjectHeaderProtocol() {
		return injectHeaderProtocol;
	}
	public void setInjectHeaderProtocol(String injectHeaderProtocol) {
		this.injectHeaderProtocol = injectHeaderProtocol;
	}
	public String getInjectHeaderType() {
		return injectHeaderType;
	}
	public void setInjectHeaderType(String injectHeaderType) {
		this.injectHeaderType = injectHeaderType;
	}
	public String getInjectHeaderProperty() {
		return injectHeaderProperty;
	}
	public void setInjectHeaderProperty(String injectHeaderProperty) {
		this.injectHeaderProperty = injectHeaderProperty;
	}
	
		
	
	
}
